# Generated for the Project #3 download — do not edit.
set(EDUDBMS_PROJ proj3)
set(EDUDBMS_SOURCES
	src/index/bptree.cpp
)
set(EDUDBMS_REF_LIB libref_upto_proj2.a)
