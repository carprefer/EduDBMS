#include "engine/engine.h"

#include <stdexcept>

#include "execution/expression_eval.hpp"
#include "execution/filter_exec.hpp"
#include "execution/hash_join_exec.hpp"
#include "execution/index_scan_exec.h"
#include "execution/nested_loop_join_exec.hpp"
#include "execution/project_exec.hpp"

namespace minidb {

Engine::Engine(const std::string& db_path) : db_path_(db_path) {
	disk_manager_ = std::make_unique<DiskManager>(db_path);
	buffer_manager_ = std::make_unique<BufferManager>(disk_manager_.get(), 256);
	object_manager_ = std::make_unique<ObjectManager>(buffer_manager_.get());
}

Engine::~Engine() = default;

void Engine::CreateTable(const std::string& name, const Schema& schema) {
	catalog_.CreateTable(name, schema);

	// Allocate a heap page for this table
	Page* page = buffer_manager_->NewPage();
	page_id_t pid = page->GetPageId();
	ObjectManager::InitPage(page);
	buffer_manager_->UnpinPage(pid, true);

	table_heaps_[name] = std::make_unique<TableHeap>(
		buffer_manager_.get(), object_manager_.get(), schema, pid);
}

void Engine::Insert(const std::string& table_name, const Row& row) {
	auto it = table_heaps_.find(table_name);
	if (it == table_heaps_.end()) {
		throw std::runtime_error("Table not found: " + table_name);
	}
	it->second->InsertRecord(row);
}

std::vector<Row> Engine::Execute(const std::string& sql) {
	Parser parser(sql);
	auto stmt = parser.Parse();

	Planner planner(catalog_);
	auto logical_plan = planner.Plan(*stmt);

	auto stats_map = BuildStatsMap();
	DPOptimizer optimizer(stats_map);
	auto physical_plan = optimizer.Optimize(logical_plan.get());

	auto executor = BuildExecutor(physical_plan.get());
	executor->Open();

	std::vector<Row> results;
	while (auto row = executor->Next()) {
		results.push_back(*row);
	}
	executor->Close();
	return results;
}

std::string Engine::Explain(const std::string& sql) {
	Parser parser(sql);
	auto stmt = parser.Parse();

	Planner planner(catalog_);
	auto logical_plan = planner.Plan(*stmt);

	auto stats_map = BuildStatsMap();
	DPOptimizer optimizer(stats_map);
	auto physical_plan = optimizer.Optimize(logical_plan.get());

	return physical_plan->ToString();
}

std::unordered_map<std::string, TableStats> Engine::BuildStatsMap() {
	std::unordered_map<std::string, TableStats> stats_map;
	for (const auto& name : catalog_.GetTableNames()) {
		auto it = table_heaps_.find(name);
		if (it != table_heaps_.end()) {
			auto rows = it->second->ScanAll();
			TableStats stats;
			const auto& schema = catalog_.GetSchema(name);
			for (const auto& col : schema.GetColumns()) {
				ColumnStats cs;
				cs.row_count = rows.size();
				std::set<std::string> distinct_vals;
				for (const auto& row : rows) {
					auto rit = row.find(col.GetName());
					if (rit != row.end()) {
						distinct_vals.insert(rit->second.ToString());
						if (!cs.num_distinct || rit->second < cs.min_val) cs.min_val = rit->second;
						if (!cs.num_distinct || rit->second > cs.max_val) cs.max_val = rit->second;
					}
				}
				cs.num_distinct = distinct_vals.size();
				stats.SetColumnStats(col.GetName(), cs);
			}
			stats_map[name] = stats;
		}
	}
	return stats_map;
}

// ============================================================
// SeqScanExec wrapper that qualifies column names with table name
// ============================================================

class QualifiedSeqScanExec : public Executor {
public:
	QualifiedSeqScanExec(std::string table_name, std::vector<Row> rows, const Schema& schema)
		: table_name_(std::move(table_name)), rows_(std::move(rows)), schema_(schema), idx_(0) {}

	void Open() override { idx_ = 0; }

	std::optional<Row> Next() override {
		if (idx_ >= rows_.size()) return std::nullopt;
		Row qualified;
		for (const auto& [col, val] : rows_[idx_]) {
			qualified[col] = val;
			qualified[table_name_ + "." + col] = val;
		}
		++idx_;
		return qualified;
	}

	void Close() override {}

private:
	std::string table_name_;
	std::vector<Row> rows_;
	Schema schema_;
	size_t idx_;
};

std::unique_ptr<Executor> Engine::BuildExecutor(const PhysicalPlanNode* plan) {
	if (auto* scan = dynamic_cast<const PhysicalSeqScan*>(plan)) {
		auto it = table_heaps_.find(scan->GetTableName());
		if (it == table_heaps_.end()) {
			throw std::runtime_error("Table not found: " + scan->GetTableName());
		}
		auto rows = it->second->ScanAll();
		return std::make_unique<QualifiedSeqScanExec>(
			scan->GetTableName(), std::move(rows), catalog_.GetSchema(scan->GetTableName()));
	}

	if (auto* filter = dynamic_cast<const PhysicalFilter*>(plan)) {
		auto child = BuildExecutor(filter->GetChild());
		return std::make_unique<FilterExec>(CloneExpression(filter->GetPredicate()), std::move(child));
	}

	if (auto* project = dynamic_cast<const PhysicalProject*>(plan)) {
		auto child = BuildExecutor(project->GetChild());
		std::vector<std::unique_ptr<Expression>> cols;
		if (!project->IsSelectAll()) {
			for (const auto& e : project->GetColumns()) {
				cols.push_back(CloneExpression(e.get()));
			}
		}
		return std::make_unique<ProjectExec>(std::move(cols), project->IsSelectAll(), std::move(child));
	}

	if (auto* hj = dynamic_cast<const PhysicalHashJoin*>(plan)) {
		auto left = BuildExecutor(hj->GetLeft());
		auto right = BuildExecutor(hj->GetRight());
		return std::make_unique<HashJoinExec>(CloneExpression(hj->GetCondition()), std::move(left), std::move(right));
	}

	if (auto* nlj = dynamic_cast<const PhysicalNestedLoopJoin*>(plan)) {
		auto left = BuildExecutor(nlj->GetLeft());
		auto right = BuildExecutor(nlj->GetRight());
		return std::make_unique<NestedLoopJoinExec>(CloneExpression(nlj->GetCondition()), std::move(left), std::move(right));
	}

	if (auto* sort = dynamic_cast<const PhysicalSort*>(plan)) {
		auto child = BuildExecutor(sort->GetChild());
		std::vector<SortExec::SortKey> keys;
		for (size_t i = 0; i < sort->GetSortKeys().size(); ++i) {
			auto* col = dynamic_cast<const ColumnRef*>(sort->GetSortKeys()[i].get());
			if (col) {
				keys.push_back({col->GetColumnName(), sort->GetAscending()[i]});
			}
		}
		return std::make_unique<SortExec>(std::move(keys), std::move(child));
	}

	if (auto* agg = dynamic_cast<const PhysicalAggregate*>(plan)) {
		auto child = BuildExecutor(agg->GetChild());

		std::vector<std::string> group_cols;
		for (const auto& e : agg->GetGroupByKeys()) {
			if (auto* col = dynamic_cast<const ColumnRef*>(e.get())) {
				group_cols.push_back(col->GetColumnName());
			}
		}

		std::vector<AggregateExec::AggregateSpec> specs;
		for (const auto& e : agg->GetAggregateExprs()) {
			if (auto* ae = dynamic_cast<const AggregateExpr*>(e.get())) {
				AggregateExec::AggregateSpec spec;
				spec.func = ae->GetFunc();
				spec.is_count_star = ae->IsCountStar();
				spec.output_name = ae->ToString();
				if (!spec.is_count_star && ae->GetArgument()) {
					if (auto* col = dynamic_cast<const ColumnRef*>(ae->GetArgument())) {
						spec.column_name = col->GetColumnName();
					}
				}
				specs.push_back(std::move(spec));
			}
		}

		return std::make_unique<AggregateExec>(std::move(group_cols), std::move(specs), std::move(child));
	}

	throw std::runtime_error("Unknown physical plan node");
}

std::unique_ptr<Expression> Engine::CloneExpression(const Expression* expr) {
	if (!expr) return nullptr;
	if (auto* col = dynamic_cast<const ColumnRef*>(expr))
		return std::make_unique<ColumnRef>(col->GetColumnName(), col->GetTableName());
	if (auto* lit = dynamic_cast<const Literal*>(expr))
		return std::make_unique<Literal>(lit->GetLiteralType(), lit->GetValue());
	if (auto* binop = dynamic_cast<const BinaryOp*>(expr))
		return std::make_unique<BinaryOp>(binop->GetOp(),
			CloneExpression(binop->GetLeft()), CloneExpression(binop->GetRight()));
	if (auto* agg = dynamic_cast<const AggregateExpr*>(expr))
		return std::make_unique<AggregateExpr>(agg->GetFunc(),
			CloneExpression(agg->GetArgument()), agg->IsCountStar());
	throw std::runtime_error("Unknown expression type in clone");
}

} // namespace minidb
