#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "buffer/buffer_manager.h"
#include "catalog/catalog.h"
#include "catalog/table_heap.h"
#include "common/types.h"
#include "disk/disk_manager.h"
#include "execution/aggregate_exec.h"
#include "execution/executor.h"
#include "execution/sort_exec.h"
#include "index/bptree.h"
#include "object/object_manager.h"
#include "optimizer/cost_estimator.hpp"
#include "optimizer/dp_optimizer.hpp"
#include "optimizer/physical_plan.hpp"
#include "parser/parser.h"
#include "planner/planner.h"

namespace minidb {

/**
 * Engine facade — orchestrates the full query pipeline:
 *   SQL → Parse → Plan → Optimize → Execute
 *
 * Supports disk-backed storage via DiskManager → BufferManager → ObjectManager.
 */
class Engine {
public:
	explicit Engine(const std::string& db_path);
	~Engine();

	void CreateTable(const std::string& name, const Schema& schema);
	void Insert(const std::string& table_name, const Row& row);
	std::vector<Row> Execute(const std::string& sql);
	std::string Explain(const std::string& sql);

	const Catalog& GetCatalog() const { return catalog_; }

private:
	std::string db_path_;
	std::unique_ptr<DiskManager> disk_manager_;
	std::unique_ptr<BufferManager> buffer_manager_;
	std::unique_ptr<ObjectManager> object_manager_;
	Catalog catalog_;
	std::unordered_map<std::string, std::unique_ptr<TableHeap>> table_heaps_;

	// Build executor tree from physical plan
	std::unique_ptr<Executor> BuildExecutor(const PhysicalPlanNode* plan);

	// Build stats map for optimizer
	std::unordered_map<std::string, TableStats> BuildStatsMap();

	// Clone expression (for executor construction from plan)
	std::unique_ptr<Expression> CloneExpression(const Expression* expr);
};

} // namespace minidb
