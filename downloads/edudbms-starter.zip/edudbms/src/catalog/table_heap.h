#pragma once

#include <vector>

#include "buffer/buffer_manager.h"
#include "common/config.h"
#include "common/types.h"
#include "object/object_manager.h"

namespace minidb {

/**
 * TableHeap provides a record-level interface over disk-based slotted pages.
 * It wraps ObjectManager + BufferManager to support sequential scan and insert.
 */
class TableHeap {
public:
	TableHeap(BufferManager* buffer_manager, ObjectManager* object_manager,
	          const Schema& schema, page_id_t first_page_id)
		: buffer_manager_(buffer_manager),
		  object_manager_(object_manager),
		  schema_(schema),
		  first_page_id_(first_page_id) {}

	RecordID InsertRecord(const Row& row) {
		auto bytes = ObjectManager::SerializeRow(row, schema_);

		// Try to insert into the last known page
		page_id_t pid = first_page_id_;
		slot_id_t slot = object_manager_->InsertRecord(pid, bytes);

		if (slot == INVALID_SLOT_ID) {
			// Current page full, allocate new page
			Page* new_page = buffer_manager_->NewPage();
			pid = new_page->GetPageId();
			ObjectManager::InitPage(new_page);
			buffer_manager_->UnpinPage(pid, true);

			slot = object_manager_->InsertRecord(pid, bytes);
		}

		return RecordID{pid, slot};
	}

	Row GetRecord(const RecordID& rid) {
		auto bytes = object_manager_->GetRecord(rid.page_id, rid.slot_id);
		return ObjectManager::DeserializeRow(bytes, schema_);
	}

	const Schema& GetSchema() const { return schema_; }
	page_id_t GetFirstPageId() const { return first_page_id_; }

	/**
	 * Simple sequential scan: collects all records from first_page_id_.
	 * For a real DBMS this would be an iterator; here we materialize for simplicity.
	 */
	std::vector<Row> ScanAll() {
		std::vector<Row> rows;
		page_id_t pid = first_page_id_;

		Page* page = buffer_manager_->FetchPage(pid);
		if (!page) return rows;

		const char* data = page->GetData();
		uint16_t num_slots;
		std::memcpy(&num_slots, data, sizeof(uint16_t));
		buffer_manager_->UnpinPage(pid, false);

		for (uint16_t i = 0; i < num_slots; ++i) {
			try {
				auto bytes = object_manager_->GetRecord(pid, i);
				rows.push_back(ObjectManager::DeserializeRow(bytes, schema_));
			} catch (...) {
				// Deleted slot, skip
			}
		}

		return rows;
	}

private:
	BufferManager* buffer_manager_;
	ObjectManager* object_manager_;
	Schema schema_;
	page_id_t first_page_id_;
};

} // namespace minidb
