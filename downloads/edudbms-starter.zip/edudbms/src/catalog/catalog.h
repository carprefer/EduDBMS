#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "common/config.h"
#include "common/types.h"

namespace minidb {

/**
 * Lightweight catalog for table metadata.
 * Supports both in-memory mode (for testing parser/planner)
 * and disk mode (with heap page ids).
 */
class Catalog {
public:
	Catalog() = default;

	void CreateTable(const std::string& table_name, const Schema& schema) {
		if (tables_.count(table_name)) {
			throw std::runtime_error("Table already exists: " + table_name);
		}
		tables_[table_name] = schema;
	}

	bool HasTable(const std::string& table_name) const {
		return tables_.count(table_name) > 0;
	}

	const Schema& GetSchema(const std::string& table_name) const {
		auto it = tables_.find(table_name);
		if (it == tables_.end()) {
			throw std::runtime_error("Table not found: " + table_name);
		}
		return it->second;
	}

	std::vector<std::string> GetTableNames() const {
		std::vector<std::string> names;
		for (const auto& [name, _] : tables_) {
			names.push_back(name);
		}
		return names;
	}

private:
	std::unordered_map<std::string, Schema> tables_;
};

} // namespace minidb
