#pragma once

#include <list>
#include <unordered_map>

#include "common/config.h"

namespace minidb {

/**
 * LRUReplacer tracks buffer pool frames that are candidates for eviction.
 *
 * Only unpinned frames (pin_count == 0) are tracked here.
 * When a frame is pinned, it is removed from the replacer.
 * When a frame is unpinned, it is added to the back of the LRU list.
 * Victim() removes the least-recently-used (front of list) frame.
 *
 * Internal data structure:
 *   - lru_list_: doubly-linked list of frame_ids, front = LRU, back = MRU
 *   - lru_map_:  frame_id -> iterator into lru_list_ for O(1) lookup
 */
class LRUReplacer {
public:
	explicit LRUReplacer(size_t capacity) : capacity_(capacity) {}

	/**
	 * [Project #1 TODO] Remove the least-recently-used frame from the replacer.
	 *
	 * @param[out] frame_id  Set to the evicted frame's ID.
	 * @return true if a victim was found, false if replacer is empty.
	 *
	 * Hints:
	 *   - The victim is at the front of lru_list_.
	 *   - Remove it from both lru_list_ and lru_map_.
	 *
	 * Expected: ~10 lines
	 */
	bool Victim(frame_id_t* frame_id);

	/**
	 * [Project #1 TODO] Pin a frame — remove it from the replacer (not evictable).
	 *
	 * @param frame_id  The frame to pin.
	 *
	 * Hints:
	 *   - If frame_id is in lru_map_, erase it from both map and list.
	 *   - If not present, do nothing.
	 *
	 * Expected: ~5 lines
	 */
	void Pin(frame_id_t frame_id);

	/**
	 * [Project #1 TODO] Unpin a frame — add it to the replacer (now evictable).
	 *
	 * @param frame_id  The frame to unpin.
	 *
	 * Hints:
	 *   - If already present, do nothing (don't move it).
	 *   - Otherwise, push_back to lru_list_ and record in lru_map_.
	 *
	 * Expected: ~5 lines
	 */
	void Unpin(frame_id_t frame_id);

	/** Number of frames currently in the replacer. */
	size_t Size() const { return lru_list_.size(); }

private:
	size_t capacity_;
	std::list<frame_id_t> lru_list_;
	std::unordered_map<frame_id_t, std::list<frame_id_t>::iterator> lru_map_;
};

} // namespace minidb
