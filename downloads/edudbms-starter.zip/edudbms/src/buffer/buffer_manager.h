#pragma once

#include <list>
#include <unordered_map>
#include <vector>

#include "buffer/page.h"
#include "buffer/replacer.h"
#include "common/config.h"
#include "disk/disk_manager.h"

namespace minidb {

/**
 * BufferManager manages a fixed-size pool of in-memory pages.
 *
 * Pages are loaded from disk on demand (FetchPage) and written back
 * when dirty (FlushPage). The LRUReplacer decides which frame to
 * evict when the pool is full.
 *
 * Terminology:
 *   - frame: a slot in the buffer pool (indexed 0..pool_size-1)
 *   - page:  a DB_PAGE_SIZE block on disk (indexed by page_id)
 *   - page_table_: maps page_id -> frame_id for pages currently in pool
 */
class BufferManager {
public:
	BufferManager(DiskManager* disk_manager, size_t pool_size);
	~BufferManager();

	/**
	 * [Project #1 TODO] Fetch a page from the buffer pool.
	 *
	 * @param page_id  The page to fetch.
	 * @return Pointer to the Page in the pool, or nullptr if all frames
	 *         are pinned and no eviction is possible.
	 *
	 * Hints:
	 *   1. Check page_table_ — if page_id is already in pool, increment
	 *      pin count, Pin() in replacer, return the page.
	 *   2. Otherwise, find a free frame from free_list_, or call
	 *      replacer_.Victim() to evict one.
	 *   3. If the evicted frame is dirty, flush it to disk first.
	 *   4. Read the new page from disk into the frame.
	 *   5. Update page_table_, set page metadata, return the page.
	 *
	 * Expected: ~30 lines
	 */
	Page* FetchPage(page_id_t page_id);

	/**
	 * [Project #1 TODO] Unpin a page — decrease its pin count.
	 *
	 * @param page_id   The page to unpin.
	 * @param is_dirty  If true, mark the page as dirty.
	 * @return true if the page was found and unpinned, false otherwise.
	 *
	 * Hints:
	 *   - Find the frame via page_table_.
	 *   - If pin_count is already 0, return false.
	 *   - Decrement pin_count. If it reaches 0, Unpin() in replacer.
	 *   - If is_dirty, set the page's dirty flag.
	 *
	 * Expected: ~15 lines
	 */
	bool UnpinPage(page_id_t page_id, bool is_dirty);

	/**
	 * [Project #1 TODO] Flush a specific page to disk.
	 *
	 * @param page_id  The page to flush.
	 * @return true if the page was found and flushed, false otherwise.
	 *
	 * Hints:
	 *   - Find the frame via page_table_.
	 *   - Write page data to disk via disk_manager_.
	 *   - Clear the dirty flag.
	 *
	 * Expected: ~10 lines
	 */
	bool FlushPage(page_id_t page_id);

	/**
	 * [Project #1 TODO] Allocate a new page in the buffer pool.
	 *
	 * @return Pointer to the new Page, or nullptr if no frame available.
	 *
	 * Hints:
	 *   - Call disk_manager_->AllocatePage() to get a new page_id.
	 *   - Find a free frame (free_list_ or victim).
	 *   - Initialize the frame for the new page.
	 *   - Pin count starts at 1.
	 *
	 * Expected: ~25 lines
	 */
	Page* NewPage();

	/**
	 * [Project #1 TODO] Flush all dirty pages in the buffer pool to disk.
	 *
	 * Hints:
	 *   - Iterate through page_table_.
	 *   - For each dirty page, call disk_manager_->WritePage() and clear dirty flag.
	 *
	 * Expected: ~10 lines
	 */
	void FlushAllPages();

	/**
	 * [Project #1 TODO] Delete a page from the buffer pool.
	 *
	 * @param page_id  The page to delete.
	 * @return true if the page was deleted, false if not found or still pinned.
	 *
	 * Hints:
	 *   - Find in page_table_. If not found, return true (already gone).
	 *   - If pin_count > 0, return false (still in use).
	 *   - Remove from page_table_, reset the frame, add frame to free_list_.
	 *   - Remove from replacer via Pin().
	 *
	 * Expected: ~15 lines
	 */
	bool DeletePage(page_id_t page_id);

	/** Get the pool size. */
	size_t GetPoolSize() const { return pool_size_; }

private:
	DiskManager* disk_manager_;
	size_t pool_size_;
	std::vector<Page> pages_;               // buffer pool frames
	std::unordered_map<page_id_t, frame_id_t> page_table_;  // page_id -> frame_id
	std::list<frame_id_t> free_list_;       // available frames
	LRUReplacer replacer_;
};

} // namespace minidb
