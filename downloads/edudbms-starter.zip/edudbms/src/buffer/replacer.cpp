#include "buffer/replacer.h"

namespace minidb {

// ============================================================
// [Project #1 TODO] Implement the following three functions.
// ============================================================

#ifndef REFERENCE_IMPL

bool LRUReplacer::Victim(frame_id_t* frame_id) {
	// TODO: Pop the front of lru_list_ (LRU frame).
	(void)frame_id;
	return false;
}

void LRUReplacer::Pin(frame_id_t frame_id) {
	// TODO: Remove frame_id from the replacer if present.
	(void)frame_id;
}

void LRUReplacer::Unpin(frame_id_t frame_id) {
	// TODO: Add frame_id to the back of lru_list_ if not already present.
	(void)frame_id;
}

#endif // REFERENCE_IMPL

} // namespace minidb
