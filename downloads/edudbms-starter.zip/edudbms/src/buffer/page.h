#pragma once

#include <cstring>

#include "common/config.h"

namespace minidb {

/**
 * Page is the unit of storage managed by the BufferManager.
 * Each page has DB_PAGE_SIZE bytes of data plus metadata for buffer management.
 */
class Page {
public:
	Page() : page_id_(INVALID_PAGE_ID), is_dirty_(false), pin_count_(0) {
		std::memset(data_, 0, DB_PAGE_SIZE);
	}

	// Data access
	char* GetData() { return data_; }
	const char* GetData() const { return data_; }

	// Metadata access
	page_id_t GetPageId() const { return page_id_; }
	void SetPageId(page_id_t page_id) { page_id_ = page_id; }

	lsn_t GetPageLSN() const { return page_lsn_; }
	void SetPageLSN(lsn_t lsn) { page_lsn_ = lsn; }

	bool IsDirty() const { return is_dirty_; }
	void SetDirty(bool dirty) { is_dirty_ = dirty; }

	int GetPinCount() const { return pin_count_; }
	void IncrementPinCount() { ++pin_count_; }
	void DecrementPinCount() { --pin_count_; }

	/** Reset page to initial state. */
	void Reset() {
		page_id_ = INVALID_PAGE_ID;
		page_lsn_ = INVALID_LSN;
		is_dirty_ = false;
		pin_count_ = 0;
		std::memset(data_, 0, DB_PAGE_SIZE);
	}

private:
	char data_[DB_PAGE_SIZE];
	page_id_t page_id_;
	lsn_t page_lsn_ = INVALID_LSN;
	bool is_dirty_;
	int pin_count_;
};

} // namespace minidb
