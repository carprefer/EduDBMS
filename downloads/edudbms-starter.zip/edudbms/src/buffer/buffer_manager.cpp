#include "buffer/buffer_manager.h"

namespace minidb {

BufferManager::BufferManager(DiskManager* disk_manager, size_t pool_size)
	: disk_manager_(disk_manager),
	  pool_size_(pool_size),
	  pages_(pool_size),
	  replacer_(pool_size) {
	// All frames start as free
	for (size_t i = 0; i < pool_size_; ++i) {
		free_list_.push_back(static_cast<frame_id_t>(i));
	}
}

BufferManager::~BufferManager() {
	FlushAllPages();
}

// ============================================================
// [Project #1 TODO] Implement the following four functions.
// ============================================================

#ifndef REFERENCE_IMPL

Page* BufferManager::FetchPage(page_id_t page_id) {
	// TODO: See header comments for step-by-step hints.
	(void)page_id;
	return nullptr;
}

bool BufferManager::UnpinPage(page_id_t page_id, bool is_dirty) {
	// TODO: See header comments for step-by-step hints.
	(void)page_id;
	(void)is_dirty;
	return false;
}

bool BufferManager::FlushPage(page_id_t page_id) {
	// TODO: See header comments for step-by-step hints.
	(void)page_id;
	return false;
}

Page* BufferManager::NewPage() {
	// TODO: See header comments for step-by-step hints.
	return nullptr;
}

#endif // REFERENCE_IMPL

#ifndef REFERENCE_IMPL

void BufferManager::FlushAllPages() {
	// TODO: Iterate page_table_, write dirty pages to disk, clear dirty flags.
}

bool BufferManager::DeletePage(page_id_t page_id) {
	// TODO: Remove page from pool. Return false if still pinned.
	(void)page_id;
	return false;
}

#endif // REFERENCE_IMPL

} // namespace minidb
