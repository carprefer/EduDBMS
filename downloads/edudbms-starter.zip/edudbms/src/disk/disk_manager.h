#pragma once

#include <fstream>
#include <string>

#include "common/config.h"

namespace minidb {

/**
 * DiskManager manages raw page-level I/O to a database file.
 * Each page is DB_PAGE_SIZE (4096) bytes, addressed by page_id.
 *
 * File layout:
 *   [Page 0][Page 1][Page 2]...
 *   Each page occupies exactly DB_PAGE_SIZE bytes at offset page_id * DB_PAGE_SIZE.
 */
class DiskManager {
public:
	explicit DiskManager(const std::string& db_file_path);
	~DiskManager();

	/**
	 * [Project #1 TODO] Read the contents of the specified page from disk into the data buffer.
	 *
	 * @param page_id  The page to read (0-indexed).
	 * @param data     Output buffer of at least DB_PAGE_SIZE bytes.
	 *
	 * Hints:
	 *   - Seek to offset page_id * DB_PAGE_SIZE in the file.
	 *   - Read exactly DB_PAGE_SIZE bytes into data.
	 *   - If the page is beyond the current file size, zero-fill data.
	 *
	 * Expected: ~10 lines
	 */
	void ReadPage(page_id_t page_id, char* data);

	/**
	 * [Project #1 TODO] Write the contents of the data buffer to the specified page on disk.
	 *
	 * @param page_id  The page to write (0-indexed).
	 * @param data     Input buffer of at least DB_PAGE_SIZE bytes.
	 *
	 * Hints:
	 *   - Seek to offset page_id * DB_PAGE_SIZE in the file.
	 *   - Write exactly DB_PAGE_SIZE bytes from data.
	 *   - Flush the write to ensure durability.
	 *
	 * Expected: ~10 lines
	 */
	void WritePage(page_id_t page_id, const char* data);

	/**
	 * [Project #1 TODO] Allocate a new page and return its page_id.
	 *
	 * Hints:
	 *   - Simply return the current num_pages_ and then increment it.
	 *   - The actual file space will be allocated on first WritePage.
	 *
	 * Expected: ~3 lines
	 */
	page_id_t AllocatePage();

	/** Get the number of pages currently allocated. */
	page_id_t GetNumPages() const { return num_pages_; }

private:
	std::string db_file_path_;
	std::fstream db_file_;
	page_id_t num_pages_;
};

} // namespace minidb
