#include "disk/disk_manager.h"

#include <cstring>
#include <filesystem>

namespace minidb {

DiskManager::DiskManager(const std::string& db_file_path)
	: db_file_path_(db_file_path), num_pages_(0) {
	// Open existing file or create new one
	db_file_.open(db_file_path_, std::ios::binary | std::ios::in | std::ios::out);
	if (!db_file_.is_open()) {
		// File doesn't exist — create it
		db_file_.open(db_file_path_, std::ios::binary | std::ios::trunc | std::ios::in | std::ios::out);
	}
	if (!db_file_.is_open()) {
		throw std::runtime_error("Cannot open database file: " + db_file_path_);
	}

	// Determine existing page count from file size
	db_file_.seekg(0, std::ios::end);
	auto file_size = db_file_.tellg();
	if (file_size > 0) {
		num_pages_ = static_cast<page_id_t>(file_size) / DB_PAGE_SIZE;
	}
}

DiskManager::~DiskManager() {
	if (db_file_.is_open()) {
		db_file_.close();
	}
}

// ============================================================
// [Project #1 TODO] Implement the following three functions.
// The stub implementations below allow the project to compile
// but do not perform real I/O.
// ============================================================

#ifndef REFERENCE_IMPL

void DiskManager::ReadPage(page_id_t page_id, char* data) {
	// TODO: Seek to page_id * DB_PAGE_SIZE and read DB_PAGE_SIZE bytes.
	//       If page_id >= num_pages_, zero-fill data instead.
	std::memset(data, 0, DB_PAGE_SIZE);
}

void DiskManager::WritePage(page_id_t page_id, const char* data) {
	// TODO: Seek to page_id * DB_PAGE_SIZE and write DB_PAGE_SIZE bytes.
	//       Flush the stream afterwards.
	(void)page_id;
	(void)data;
}

page_id_t DiskManager::AllocatePage() {
	// TODO: Return current num_pages_ and increment it.
	return 0;
}

#endif // REFERENCE_IMPL

} // namespace minidb
