#pragma once

#include <cstdint>
#include <vector>

#include "buffer/buffer_manager.h"
#include "common/config.h"
#include "common/types.h"

namespace minidb {

/**
 * Slotted Page Layout (within a DB_PAGE_SIZE page):
 *
 * ┌──────────────────────────────────────────────┐  offset 0
 * │ PageHeader: num_slots (2B) | free_off (2B)   │
 * ├──────────────────────────────────────────────┤  offset 4
 * │ SlotInfo[0]: offset (2B) | length (2B)        │
 * │ SlotInfo[1]: offset (2B) | length (2B)        │
 * │ ...                                           │
 * ├──────────────────────────────────────────────┤
 * │              Free Space                       │
 * ├──────────────────────────────────────────────┤
 * │ Records (grow downward from end of page)      │
 * │   record_N ... record_1 ... record_0          │
 * └──────────────────────────────────────────────┘  offset DB_PAGE_SIZE
 *
 * SlotInfo with offset=0 and length=0 means the slot is deleted.
 */

struct PageHeader {
	uint16_t num_slots;
	uint16_t free_space_offset;  // where the next record will end (grows downward)
};

struct SlotInfo {
	uint16_t offset;  // byte offset of record within page data
	uint16_t length;  // byte length of record (0 = deleted)
};

static constexpr size_t PAGE_HEADER_SIZE = sizeof(PageHeader);
static constexpr size_t SLOT_INFO_SIZE = sizeof(SlotInfo);

/**
 * ObjectManager manages variable-length records within slotted pages.
 * It uses a BufferManager to access pages.
 */
class ObjectManager {
public:
	explicit ObjectManager(BufferManager* buffer_manager);

	/**
	 * [Project #2 TODO] Insert a record into the specified page.
	 *
	 * @param page_id  The page to insert into.
	 * @param record   The serialized record bytes.
	 * @return The slot_id of the new record, or INVALID_SLOT_ID if page is full.
	 *
	 * Hints:
	 *   1. Fetch the page via buffer_manager_.
	 *   2. Read the PageHeader from the beginning of page data.
	 *   3. Calculate available space:
	 *      free_space = header.free_space_offset - PAGE_HEADER_SIZE
	 *                   - (header.num_slots * SLOT_INFO_SIZE)
	 *   4. Check if record.size() + SLOT_INFO_SIZE fits in free_space.
	 *   5. Write the record at (header.free_space_offset - record.size()).
	 *   6. Add a new SlotInfo entry. Update num_slots and free_space_offset.
	 *   7. Write updated header back. Unpin page as dirty.
	 *
	 * Expected: ~30 lines
	 */
	slot_id_t InsertRecord(page_id_t page_id, const std::vector<uint8_t>& record);

	/**
	 * [Project #2 TODO] Delete a record by invalidating its slot.
	 *
	 * @param page_id  The page containing the record.
	 * @param slot_id  The slot to delete.
	 *
	 * Hints:
	 *   - Read the SlotInfo at slot_id and set offset=0, length=0.
	 *   - No compaction needed — space is "leaked" until page is reclaimed.
	 *   - Unpin page as dirty.
	 *
	 * Expected: ~15 lines
	 */
	void DeleteRecord(page_id_t page_id, slot_id_t slot_id);

	/**
	 * [Project #2 TODO] Retrieve a record from the specified page and slot.
	 *
	 * @param page_id  The page containing the record.
	 * @param slot_id  The slot to read.
	 * @return The serialized record bytes.
	 * @throws RecordNotFoundException if slot is invalid or deleted.
	 *
	 * Hints:
	 *   - Read SlotInfo at slot_id. If length==0, the record is deleted.
	 *   - Copy `length` bytes starting at `offset` from page data.
	 *   - Unpin the page (not dirty).
	 *
	 * Expected: ~15 lines
	 */
	std::vector<uint8_t> GetRecord(page_id_t page_id, slot_id_t slot_id);

	/**
	 * [Project #2 TODO] Serialize a Row into a byte array using the given schema.
	 *
	 * Format: for each column in schema order:
	 *   [type_tag: 1 byte] [data: variable]
	 *   - INTEGER: 4 bytes (int32_t)
	 *   - FLOAT:   8 bytes (double)
	 *   - BOOLEAN: 1 byte
	 *   - STRING:  4 bytes (uint32_t length) + N bytes (chars)
	 *
	 * @param row     The row to serialize.
	 * @param schema  Column order and types.
	 * @return Serialized byte array.
	 *
	 * Expected: ~20 lines
	 */
	static std::vector<uint8_t> SerializeRow(const Row& row, const Schema& schema);

	/**
	 * [Project #2 TODO] Deserialize a byte array back into a Row.
	 *
	 * Reverses the format described in SerializeRow.
	 *
	 * @param data    Serialized bytes.
	 * @param schema  Column order and types.
	 * @return The reconstructed Row.
	 *
	 * Expected: ~20 lines
	 */
	static Row DeserializeRow(const std::vector<uint8_t>& data, const Schema& schema);

	/**
	 * [Project #2 TODO] Return the number of valid (non-deleted) records in a page.
	 *
	 * @param page_id  The page to inspect.
	 * @return Number of records with length > 0.
	 *
	 * Hints:
	 *   - Fetch page, read header to get num_slots.
	 *   - Count slots where length > 0.
	 *   - Unpin page (not dirty).
	 *
	 * Expected: ~10 lines
	 */
	uint16_t GetRecordCount(page_id_t page_id);

	/**
	 * [Project #2 TODO] Return the free space available in a page (in bytes).
	 *
	 * @param page_id  The page to inspect.
	 * @return Free space in bytes.
	 *
	 * Expected: ~8 lines
	 */
	uint16_t GetFreeSpace(page_id_t page_id);

	/**
	 * Initialize a fresh page with an empty slotted page header.
	 * Sets num_slots=0, free_space_offset=DB_PAGE_SIZE.
	 */
	static void InitPage(Page* page);

private:
	BufferManager* buffer_manager_;

	// Helper: read PageHeader from page data
	static PageHeader ReadHeader(const char* data);
	// Helper: write PageHeader to page data
	static void WriteHeader(char* data, const PageHeader& header);
	// Helper: read SlotInfo at index from page data
	static SlotInfo ReadSlot(const char* data, uint16_t slot_index);
	// Helper: write SlotInfo at index to page data
	static void WriteSlot(char* data, uint16_t slot_index, const SlotInfo& slot);
};

} // namespace minidb
