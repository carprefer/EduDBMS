#include "object/object_manager.h"

#include <cstring>

#include "common/exceptions.h"

namespace minidb {

ObjectManager::ObjectManager(BufferManager* buffer_manager)
	: buffer_manager_(buffer_manager) {}

void ObjectManager::InitPage(Page* page) {
	PageHeader header;
	header.num_slots = 0;
	header.free_space_offset = static_cast<uint16_t>(DB_PAGE_SIZE);
	WriteHeader(page->GetData(), header);
}

// ============================================================
// Helpers (provided — not TODO)
// ============================================================

PageHeader ObjectManager::ReadHeader(const char* data) {
	PageHeader h;
	std::memcpy(&h, data, sizeof(PageHeader));
	return h;
}

void ObjectManager::WriteHeader(char* data, const PageHeader& header) {
	std::memcpy(data, &header, sizeof(PageHeader));
}

SlotInfo ObjectManager::ReadSlot(const char* data, uint16_t slot_index) {
	SlotInfo s;
	size_t offset = PAGE_HEADER_SIZE + slot_index * SLOT_INFO_SIZE;
	std::memcpy(&s, data + offset, sizeof(SlotInfo));
	return s;
}

void ObjectManager::WriteSlot(char* data, uint16_t slot_index, const SlotInfo& slot) {
	size_t offset = PAGE_HEADER_SIZE + slot_index * SLOT_INFO_SIZE;
	std::memcpy(data + offset, &slot, sizeof(SlotInfo));
}

// ============================================================
// [Project #2 TODO] Implement the following five functions.
// ============================================================

#ifndef REFERENCE_IMPL

slot_id_t ObjectManager::InsertRecord(page_id_t page_id,
                                      const std::vector<uint8_t>& record) {
	// TODO: Insert record into slotted page. Return slot_id or INVALID_SLOT_ID.
	(void)page_id;
	(void)record;
	return INVALID_SLOT_ID;
}

void ObjectManager::DeleteRecord(page_id_t page_id, slot_id_t slot_id) {
	// TODO: Invalidate the slot (offset=0, length=0).
	(void)page_id;
	(void)slot_id;
}

std::vector<uint8_t> ObjectManager::GetRecord(page_id_t page_id, slot_id_t slot_id) {
	// TODO: Read record bytes from the page. Throw RecordNotFoundException if deleted.
	(void)page_id;
	(void)slot_id;
	return {};
}

std::vector<uint8_t> ObjectManager::SerializeRow(const Row& row, const Schema& schema) {
	// TODO: Serialize row in schema column order. See header for format.
	(void)row;
	(void)schema;
	return {};
}

Row ObjectManager::DeserializeRow(const std::vector<uint8_t>& data, const Schema& schema) {
	// TODO: Deserialize bytes back to Row. See header for format.
	(void)data;
	(void)schema;
	return {};
}

uint16_t ObjectManager::GetRecordCount(page_id_t page_id) {
	// TODO: Count non-deleted records in page.
	(void)page_id;
	return 0;
}

uint16_t ObjectManager::GetFreeSpace(page_id_t page_id) {
	// TODO: Calculate free space in page.
	(void)page_id;
	return 0;
}

#endif // REFERENCE_IMPL

} // namespace minidb
