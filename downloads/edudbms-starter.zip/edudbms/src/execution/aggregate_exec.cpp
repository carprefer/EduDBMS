#include "execution/aggregate_exec.h"

namespace minidb {

#ifndef REFERENCE_IMPL

void AggregateExec::Open() {
	// TODO: Pull all rows, bucket by group, compute aggregates.
	child_->Open();
	result_rows_.clear();
	idx_ = 0;
}

std::optional<Row> AggregateExec::Next() {
	if (idx_ >= result_rows_.size()) return std::nullopt;
	return result_rows_[idx_++];
}

#endif // REFERENCE_IMPL

} // namespace minidb
