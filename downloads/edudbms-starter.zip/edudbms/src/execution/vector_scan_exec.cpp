#include "execution/vector_scan_exec.h"

namespace minidb {

#ifndef REFERENCE_IMPL

void VectorScanExec::Open() {
	// TODO: Call index_->Search and store result node_ids.
	idx_ = 0;
}

std::optional<Row> VectorScanExec::Next() {
	// TODO: Return rows in order of similarity.
	return std::nullopt;
}

#endif // REFERENCE_IMPL

} // namespace minidb
