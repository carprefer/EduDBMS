#pragma once

#include <memory>
#include <string>
#include <vector>

#include "execution/executor.h"

namespace minidb {

/**
 * SortExec sorts all rows from its child according to a list of sort keys.
 * Follows the Volcano model: Open() materializes and sorts, Next() returns
 * rows one at a time.
 */
class SortExec : public Executor {
public:
	struct SortKey {
		std::string column_name;
		bool ascending;
	};

	SortExec(std::vector<SortKey> sort_keys, std::unique_ptr<Executor> child)
		: sort_keys_(std::move(sort_keys)), child_(std::move(child)), idx_(0) {}

	/**
	 * [Project #5 TODO] Pull all rows from child, then sort them.
	 *
	 * Hints:
	 *   1. child_->Open().
	 *   2. Loop: auto row = child_->Next(); if nullopt, break; else push to sorted_rows_.
	 *   3. Sort sorted_rows_ using std::sort with a lambda comparator.
	 *   4. The comparator should iterate through sort_keys_, comparing row[key.column_name].
	 *      If ascending: return a < b; if descending: return a > b.
	 *      If equal, move to next key.
	 *   5. child_->Close() is optional here.
	 *
	 * Expected: ~20 lines
	 */
	void Open() override;

	/**
	 * [Project #5 TODO] Return the next sorted row, or nullopt if exhausted.
	 * Expected: ~5 lines
	 */
	std::optional<Row> Next() override;

	void Close() override { child_->Close(); }

private:
	std::vector<SortKey> sort_keys_;
	std::unique_ptr<Executor> child_;
	std::vector<Row> sorted_rows_;
	size_t idx_;
};

} // namespace minidb
