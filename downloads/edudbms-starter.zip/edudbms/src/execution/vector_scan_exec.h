#pragma once

#include <memory>
#include <vector>

#include "execution/executor.h"
#include "vector/diskann_index.h"
#include "vector/vector_types.h"

namespace minidb {

/**
 * VectorScanExec uses a DiskANN index to find the K nearest neighbors
 * of a query vector and returns matching rows.
 *
 * This executor replaces the normal SeqScan → Sort → Project pipeline
 * for queries like: SELECT * FROM items ORDER BY embedding <-> [1,2,3] LIMIT 5
 */
class VectorScanExec : public Executor {
public:
	VectorScanExec(DiskANNIndex* index, const std::vector<Row>* table_rows,
	               const Vector& query_vector, int limit)
		: index_(index), table_rows_(table_rows),
		  query_vector_(query_vector), limit_(limit), idx_(0) {}

	/**
	 * [Project #7 TODO] Search the DiskANN index for nearest neighbors.
	 *
	 * Hints:
	 *   - Call index_->Search(query_vector_, limit_) to get (node_id, distance) pairs.
	 *   - Store node_ids in result_ids_ for Next() to iterate.
	 *
	 * Expected: ~5 lines
	 */
	void Open() override;

	/**
	 * [Project #7 TODO] Return the next matching row from the table.
	 *
	 * Hints:
	 *   - If idx_ >= result_ids_.size(), return nullopt.
	 *   - Get node_id = result_ids_[idx_++].
	 *   - Return (*table_rows_)[node_id].
	 *
	 * Expected: ~5 lines
	 */
	std::optional<Row> Next() override;

	void Close() override {}

private:
	DiskANNIndex* index_;
	const std::vector<Row>* table_rows_;
	Vector query_vector_;
	int limit_;
	std::vector<uint32_t> result_ids_;
	size_t idx_;
};

} // namespace minidb
