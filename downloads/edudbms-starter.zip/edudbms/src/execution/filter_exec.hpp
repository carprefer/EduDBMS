#pragma once

#include <memory>

#include "execution/executor.h"
#include "execution/expression_eval.hpp"

namespace minidb {

class FilterExec : public Executor {
public:
	FilterExec(std::unique_ptr<Expression> predicate,
	           std::unique_ptr<Executor> child)
		: predicate_(std::move(predicate)), child_(std::move(child)) {}

	void Open() override {
		child_->Open();
	}

	std::optional<Row> Next() override {
		while (auto row = child_->Next()) {
			Value result = EvalExpression(predicate_.get(), *row);
			if (result.AsBool()) {
				return row;
			}
		}
		return std::nullopt;
	}

	void Close() override {
		child_->Close();
	}

	std::string ToString(int indent = 0) const override {
		std::string s = std::string(indent * 2, ' ') + "Filter(" +
		                predicate_->ToString() + ")\n";
		s += child_->ToString(indent + 1);
		return s;
	}

private:
	std::unique_ptr<Expression> predicate_;
	std::unique_ptr<Executor> child_;
};

} // namespace minidb
