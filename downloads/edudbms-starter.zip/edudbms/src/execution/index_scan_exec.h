#pragma once

#include <memory>
#include <vector>

#include "buffer/buffer_manager.h"
#include "execution/executor.h"
#include "index/bptree.h"
#include "object/object_manager.h"

namespace minidb {

/**
 * IndexScanExec uses a B+-Tree index to retrieve records in a key range,
 * then fetches each record via the ObjectManager.
 *
 * The index stores: key -> page_id (where the record lives).
 * For simplicity, each record is assumed to be in slot 0 of its page.
 */
class IndexScanExec : public Executor {
public:
	IndexScanExec(BPTree* index, ObjectManager* object_manager,
	              int32_t begin_key, int32_t end_key, Schema schema)
		: index_(index), object_manager_(object_manager),
		  begin_key_(begin_key), end_key_(end_key),
		  schema_(std::move(schema)), idx_(0) {}

	/**
	 * [Project #5 TODO] Use the index to find matching records.
	 *
	 * Hints:
	 *   1. Call index_->RangeScan(begin_key_, end_key_) to get (key, page_id) pairs.
	 *   2. Store them in results_.
	 *
	 * Expected: ~5 lines
	 */
	void Open() override;

	/**
	 * [Project #5 TODO] Fetch the next record from the object manager.
	 *
	 * Hints:
	 *   1. If idx_ >= results_.size(), return nullopt.
	 *   2. Otherwise, get the next (key, page_id) from results_.
	 *   3. Use object_manager_->GetRecord(page_id, 0) to fetch the bytes.
	 *   4. Deserialize with ObjectManager::DeserializeRow(bytes, schema_).
	 *   5. Return the row.
	 *
	 * Expected: ~10 lines
	 */
	std::optional<Row> Next() override;

	void Close() override {}

private:
	BPTree* index_;
	ObjectManager* object_manager_;
	int32_t begin_key_;
	int32_t end_key_;
	Schema schema_;
	std::vector<std::pair<int32_t, page_id_t>> results_;
	size_t idx_;
};

} // namespace minidb
