#pragma once

#include <memory>
#include <vector>

#include "execution/executor.h"
#include "execution/expression_eval.hpp"

namespace minidb {

class NestedLoopJoinExec : public Executor {
public:
	NestedLoopJoinExec(std::unique_ptr<Expression> condition,
	                   std::unique_ptr<Executor> left,
	                   std::unique_ptr<Executor> right)
		: condition_(std::move(condition)),
		  left_(std::move(left)),
		  right_(std::move(right)) {}

	void Open() override {
		left_->Open();
		right_->Open();

		// Materialize right side for repeated scanning
		right_rows_.clear();
		while (auto row = right_->Next()) {
			right_rows_.push_back(*row);
		}
		right_->Close();

		current_left_ = left_->Next();
		right_idx_ = 0;
	}

	std::optional<Row> Next() override {
		while (current_left_.has_value()) {
			while (right_idx_ < right_rows_.size()) {
				// Merge left + right into combined row
				Row merged = *current_left_;
				for (const auto& [k, v] : right_rows_[right_idx_]) {
					merged[k] = v;
				}
				++right_idx_;

				// Evaluate condition
				Value result = EvalExpression(condition_.get(), merged);
				if (result.AsBool()) {
					return merged;
				}
			}

			// Move to next left row, reset right scan
			current_left_ = left_->Next();
			right_idx_ = 0;
		}

		return std::nullopt;
	}

	void Close() override {
		left_->Close();
		right_rows_.clear();
	}

	std::string ToString(int indent = 0) const override {
		std::string s = std::string(indent * 2, ' ') + "NestedLoopJoin(";
		if (condition_) s += condition_->ToString();
		s += ")\n";
		s += left_->ToString(indent + 1) + "\n";
		s += right_->ToString(indent + 1);
		return s;
	}

private:
	std::unique_ptr<Expression> condition_;
	std::unique_ptr<Executor> left_;
	std::unique_ptr<Executor> right_;
	std::vector<Row> right_rows_;
	std::optional<Row> current_left_;
	size_t right_idx_ = 0;
};

} // namespace minidb
