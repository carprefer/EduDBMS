#include "execution/sort_exec.h"

#include <algorithm>

namespace minidb {

#ifndef REFERENCE_IMPL

void SortExec::Open() {
	// TODO: Pull all rows from child, sort by sort_keys_.
	child_->Open();
	sorted_rows_.clear();
	idx_ = 0;
}

std::optional<Row> SortExec::Next() {
	// TODO: Return sorted_rows_[idx_++] or nullopt.
	return std::nullopt;
}

#endif // REFERENCE_IMPL

} // namespace minidb
