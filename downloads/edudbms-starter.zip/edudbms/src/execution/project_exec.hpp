#pragma once

#include <memory>
#include <vector>

#include "execution/executor.h"
#include "parser/ast.h"

namespace minidb {

class ProjectExec : public Executor {
public:
	ProjectExec(std::vector<std::unique_ptr<Expression>> columns,
	            bool select_all,
	            std::unique_ptr<Executor> child)
		: columns_(std::move(columns)),
		  select_all_(select_all),
		  child_(std::move(child)) {}

	void Open() override {
		child_->Open();
	}

	std::optional<Row> Next() override {
		auto row = child_->Next();
		if (!row) return std::nullopt;

		if (select_all_) {
			return row;  // pass through all columns
		}

		Row projected;
		for (const auto& expr : columns_) {
			if (auto* col = dynamic_cast<ColumnRef*>(expr.get())) {
				if (!col->GetTableName().empty()) {
					std::string qualified = col->GetTableName() + "." + col->GetColumnName();
					auto it = row->find(qualified);
					if (it != row->end()) {
						projected[qualified] = it->second;
						continue;
					}
				}
				auto it = row->find(col->GetColumnName());
				if (it != row->end()) {
					projected[col->GetColumnName()] = it->second;
				}
			} else if (auto* agg = dynamic_cast<AggregateExpr*>(expr.get())) {
				std::string key = agg->ToString();
				auto it = row->find(key);
				if (it != row->end()) {
					projected[key] = it->second;
				}
			}
		}
		return projected;
	}

	void Close() override {
		child_->Close();
	}

	std::string ToString(int indent = 0) const override {
		std::string s = std::string(indent * 2, ' ') + "Project(";
		if (select_all_) {
			s += "*";
		} else {
			for (size_t i = 0; i < columns_.size(); ++i) {
				if (i > 0) s += ", ";
				s += columns_[i]->ToString();
			}
		}
		s += ")\n";
		s += child_->ToString(indent + 1);
		return s;
	}

private:
	std::vector<std::unique_ptr<Expression>> columns_;
	bool select_all_;
	std::unique_ptr<Executor> child_;
};

} // namespace minidb
