#include "execution/index_scan_exec.h"

namespace minidb {

#ifndef REFERENCE_IMPL

void IndexScanExec::Open() {
	// TODO: Populate results_ via index_->RangeScan.
}

std::optional<Row> IndexScanExec::Next() {
	// TODO: Get next (key, page_id) from results_, fetch record, deserialize.
	return std::nullopt;
}

#endif // REFERENCE_IMPL

} // namespace minidb
