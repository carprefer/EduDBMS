#pragma once

#include <stdexcept>

#include "parser/ast.h"
#include "common/types.h"

namespace minidb {

// Evaluate an expression against a row, returning a Value
inline Value EvalExpression(const Expression* expr, const Row& row) {
	if (auto* col = dynamic_cast<const ColumnRef*>(expr)) {
		// Try table.column first, then just column
		if (!col->GetTableName().empty()) {
			std::string qualified = col->GetTableName() + "." + col->GetColumnName();
			auto it = row.find(qualified);
			if (it != row.end()) return it->second;
		}
		auto it = row.find(col->GetColumnName());
		if (it != row.end()) return it->second;
		throw std::runtime_error("Column not found in row: " + col->GetColumnName());
	}

	if (auto* lit = dynamic_cast<const Literal*>(expr)) {
		switch (lit->GetLiteralType()) {
			case Literal::LiteralType::INTEGER:
				return Value(std::stoi(lit->GetValue()));
			case Literal::LiteralType::FLOAT:
				return Value(std::stod(lit->GetValue()));
			case Literal::LiteralType::STRING:
				return Value(lit->GetValue());
			case Literal::LiteralType::BOOLEAN:
				return Value(lit->GetValue() == "TRUE" || lit->GetValue() == "true");
		}
	}

	if (auto* binop = dynamic_cast<const BinaryOp*>(expr)) {
		// Logical operators
		if (binop->GetOp() == BinaryOpType::AND) {
			Value left = EvalExpression(binop->GetLeft(), row);
			if (!left.AsBool()) return Value(false);
			return EvalExpression(binop->GetRight(), row);
		}
		if (binop->GetOp() == BinaryOpType::OR) {
			Value left = EvalExpression(binop->GetLeft(), row);
			if (left.AsBool()) return Value(true);
			return EvalExpression(binop->GetRight(), row);
		}

		// Comparison operators
		Value left = EvalExpression(binop->GetLeft(), row);
		Value right = EvalExpression(binop->GetRight(), row);

		switch (binop->GetOp()) {
			case BinaryOpType::EQ: return Value(left == right);
			case BinaryOpType::NE: return Value(left != right);
			case BinaryOpType::LT: return Value(left < right);
			case BinaryOpType::GT: return Value(left > right);
			case BinaryOpType::LE: return Value(left <= right);
			case BinaryOpType::GE: return Value(left >= right);
			default: break;
		}
	}

	throw std::runtime_error("Cannot evaluate expression");
}

} // namespace minidb
