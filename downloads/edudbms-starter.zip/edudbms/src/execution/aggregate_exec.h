#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "execution/executor.h"
#include "parser/ast.h"

namespace minidb {

/**
 * AggregateExec groups rows by group-by keys and computes aggregate functions
 * for each group. Uses a hash-based group-by strategy.
 */
class AggregateExec : public Executor {
public:
	struct AggregateSpec {
		AggFunc func;
		std::string column_name;   // empty for COUNT(*)
		std::string output_name;   // name in result row (e.g. "SUM(salary)")
		bool is_count_star;
	};

	AggregateExec(std::vector<std::string> group_by_cols,
	              std::vector<AggregateSpec> agg_specs,
	              std::unique_ptr<Executor> child)
		: group_by_cols_(std::move(group_by_cols)),
		  agg_specs_(std::move(agg_specs)),
		  child_(std::move(child)),
		  idx_(0) {}

	/**
	 * [Project #5 TODO] Pull all rows, bucket by group-by key, compute aggregates.
	 *
	 * Hints:
	 *   1. Build a key string from the group-by columns for each row
	 *      (e.g., "dept=sales,region=us").
	 *   2. For each group, maintain accumulator state per aggregate:
	 *      - COUNT(*): count of rows
	 *      - COUNT(col): count of non-null (we don't have nulls, so = row count)
	 *      - SUM(col):   sum of values
	 *      - AVG(col):   track sum and count, divide at end
	 *      - MIN/MAX:    track current min/max
	 *   3. After processing all input rows, build result rows with group columns
	 *      + aggregate values. Store in result_rows_.
	 *   4. If there are no group-by columns, there's exactly one result row
	 *      (even if the input is empty — COUNT returns 0).
	 *
	 * Expected: ~35 lines
	 */
	void Open() override;

	/**
	 * [Project #5 TODO] Return the next result row, or nullopt if exhausted.
	 * Expected: ~5 lines
	 */
	std::optional<Row> Next() override;

	void Close() override { child_->Close(); }

private:
	std::vector<std::string> group_by_cols_;
	std::vector<AggregateSpec> agg_specs_;
	std::unique_ptr<Executor> child_;
	std::vector<Row> result_rows_;
	size_t idx_;
};

} // namespace minidb
