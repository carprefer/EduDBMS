#pragma once

#include <memory>
#include <vector>
#include <map>

#include "execution/executor.h"
#include "execution/expression_eval.hpp"
#include "common/types.h"

namespace minidb {

class HashJoinExec : public Executor {
public:
	HashJoinExec(std::unique_ptr<Expression> condition,
	             std::unique_ptr<Executor> left,
	             std::unique_ptr<Executor> right)
		: condition_(std::move(condition)),
		  left_(std::move(left)),
		  right_(std::move(right)) {
		auto* binop = dynamic_cast<BinaryOp*>(condition_.get());
		if (binop) {
			cond_left_key_ = dynamic_cast<ColumnRef*>(binop->GetLeft());
			cond_right_key_ = dynamic_cast<ColumnRef*>(binop->GetRight());
		}
	}

	void Open() override {
		hash_table_.clear();
		left_->Open();

		// Peek first left row to detect key alignment
		auto first = left_->Next();
		if (first) {
			DetectKeyAlignment(*first);
			Value key = EvalExpression(build_key_, *first);
			hash_table_[key.GetVariant()].push_back(*first);
		}

		// Build phase: hash remaining left rows
		while (auto row = left_->Next()) {
			Value key = EvalExpression(build_key_, *row);
			hash_table_[key.GetVariant()].push_back(*row);
		}
		left_->Close();

		// Prepare probe side
		right_->Open();
		match_idx_ = 0;
		current_matches_ = nullptr;
	}

	std::optional<Row> Next() override {
		while (true) {
			if (current_matches_ && match_idx_ < current_matches_->size()) {
				Row merged = (*current_matches_)[match_idx_];
				for (const auto& [k, v] : current_right_row_) {
					merged[k] = v;
				}
				++match_idx_;
				return merged;
			}

			auto right_row = right_->Next();
			if (!right_row) return std::nullopt;

			current_right_row_ = *right_row;
			Value probe_key = EvalExpression(probe_key_, current_right_row_);

			auto it = hash_table_.find(probe_key.GetVariant());
			if (it != hash_table_.end()) {
				current_matches_ = &it->second;
				match_idx_ = 0;
			} else {
				current_matches_ = nullptr;
			}
		}
	}

	void Close() override {
		right_->Close();
		hash_table_.clear();
		current_matches_ = nullptr;
	}

	std::string ToString(int indent = 0) const override {
		std::string s = std::string(indent * 2, ' ') + "HashJoin(";
		if (condition_) s += condition_->ToString();
		s += ")\n";
		s += left_->ToString(indent + 1) + "\n";
		s += right_->ToString(indent + 1);
		return s;
	}

private:
	// Detect which condition key matches the left (build) side
	// Uses qualified name (table.column) to avoid ambiguity
	void DetectKeyAlignment(const Row& left_row) {
		if (HasQualifiedColumn(cond_left_key_, left_row)) {
			build_key_ = cond_left_key_;
			probe_key_ = cond_right_key_;
		} else {
			build_key_ = cond_right_key_;
			probe_key_ = cond_left_key_;
		}
	}

	bool HasQualifiedColumn(const ColumnRef* key, const Row& row) {
		if (!key) return false;
		if (!key->GetTableName().empty()) {
			std::string qualified = key->GetTableName() + "." + key->GetColumnName();
			return row.count(qualified) > 0;
		}
		return row.count(key->GetColumnName()) > 0;
	}

	std::unique_ptr<Expression> condition_;
	std::unique_ptr<Executor> left_;
	std::unique_ptr<Executor> right_;

	// Condition keys (from AST)
	ColumnRef* cond_left_key_ = nullptr;
	ColumnRef* cond_right_key_ = nullptr;

	// Resolved keys after alignment detection
	const ColumnRef* build_key_ = nullptr;
	const ColumnRef* probe_key_ = nullptr;

	// Build phase: hash table
	std::map<Value::Variant, std::vector<Row>> hash_table_;

	// Probe phase state
	Row current_right_row_;
	const std::vector<Row>* current_matches_ = nullptr;
	size_t match_idx_ = 0;
};

} // namespace minidb
