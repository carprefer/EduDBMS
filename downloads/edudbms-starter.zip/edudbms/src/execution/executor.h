#pragma once

#include <memory>
#include <optional>

#include "common/types.h"

namespace minidb {

/**
 * Volcano iterator model: Open/Next/Close.
 * All physical executors inherit from this abstract base class.
 */
class Executor {
public:
	virtual ~Executor() = default;

	/** Prepare the executor for execution. */
	virtual void Open() = 0;

	/** Get the next row, or nullopt at end of stream. */
	virtual std::optional<Row> Next() = 0;

	/** Release resources. */
	virtual void Close() = 0;

	/** Debug string representation. */
	virtual std::string ToString(int indent = 0) const { (void)indent; return ""; }
};

/**
 * Mock executor that emits a predefined sequence of rows.
 * Useful for testing executors in isolation.
 */
class MockExecutor : public Executor {
public:
	explicit MockExecutor(std::vector<Row> rows) : rows_(std::move(rows)), idx_(0) {}

	void Open() override { idx_ = 0; }

	std::optional<Row> Next() override {
		if (idx_ >= rows_.size()) return std::nullopt;
		return rows_[idx_++];
	}

	void Close() override {}

private:
	std::vector<Row> rows_;
	size_t idx_;
};

} // namespace minidb
