#pragma once

#include <cstdint>
#include <optional>
#include <utility>
#include <vector>

#include "buffer/buffer_manager.h"
#include "common/config.h"

namespace minidb {

/**
 * B+-Tree on-disk index for INTEGER keys.
 *
 * Node layout on a page:
 *   [is_leaf: 1B] [num_keys: 2B] [next_leaf: 4B (leaf only)]
 *   [keys: num_keys * 4B]
 *   [children/values: (num_keys+1) * 4B (internal) or num_keys * 4B (leaf)]
 *
 * Leaf node:   keys[i] -> values[i] (page_id of the record's page)
 * Internal:    children[i] points to subtree with keys < keys[i]
 *              children[num_keys] points to subtree with keys >= keys[num_keys-1]
 */

// Node header size: is_leaf(1) + num_keys(2) + next_leaf(4) = 7
static constexpr size_t BPTREE_HEADER_SIZE = 7;
// Key size = sizeof(int32_t) = 4, pointer size = sizeof(page_id_t) = 4
static constexpr size_t KEY_SIZE = sizeof(int32_t);
static constexpr size_t PTR_SIZE = sizeof(page_id_t);

// Max keys for leaf: (DB_PAGE_SIZE - HEADER) / (KEY + PTR)
static constexpr size_t BPTREE_LEAF_MAX_KEYS =
	(DB_PAGE_SIZE - BPTREE_HEADER_SIZE) / (KEY_SIZE + PTR_SIZE);
// Max keys for internal: (DB_PAGE_SIZE - HEADER - one extra PTR) / (KEY + PTR)
static constexpr size_t BPTREE_INTERNAL_MAX_KEYS =
	(DB_PAGE_SIZE - BPTREE_HEADER_SIZE - PTR_SIZE) / (KEY_SIZE + PTR_SIZE);

struct BPTreeNode {
	bool is_leaf = true;
	std::vector<int32_t> keys;
	std::vector<page_id_t> children;   // internal: child pointers (keys.size()+1)
	std::vector<page_id_t> values;     // leaf: record page_ids (same size as keys)
	page_id_t next_leaf = INVALID_PAGE_ID;  // leaf: sibling pointer

	size_t MaxKeys() const {
		return is_leaf ? BPTREE_LEAF_MAX_KEYS : BPTREE_INTERNAL_MAX_KEYS;
	}
};

class BPTree {
public:
	BPTree(BufferManager* buffer_manager, page_id_t root_page_id);

	/**
	 * [Project #3 TODO] Search for a key in the B+-Tree.
	 *
	 * @param key  The key to search for.
	 * @return The associated value (page_id), or nullopt if not found.
	 *
	 * Hints:
	 *   1. Start at root_page_id_. Load the node.
	 *   2. If internal node: find the correct child pointer using
	 *      upper_bound on keys, then iterate into that child.
	 *   3. If leaf node: binary search keys for exact match.
	 *
	 * Expected: ~25 lines
	 */
	std::optional<page_id_t> Search(int32_t key);

	/**
	 * [Project #3 TODO] Insert a key-value pair into the B+-Tree.
	 *
	 * @param key    The key to insert.
	 * @param value  The associated value (page_id).
	 *
	 * Hints:
	 *   1. Find the correct leaf node (like Search).
	 *   2. Insert key/value in sorted order into the in-memory node.
	 *   3. If the node fits (keys.size() <= MaxKeys()), save it to disk.
	 *   4. If it overflows, split it in memory FIRST (do NOT serialize the
	 *      overflowed node — it exceeds DB_PAGE_SIZE), then save both halves.
	 *   5. Propagate the split key up to the parent. If the parent also
	 *      overflows, split it too.
	 *   6. If the root splits, create a new root.
	 *
	 * Expected: ~60 lines (including helper calls)
	 */
	void Insert(int32_t key, page_id_t value);

	/**
	 * [Project #3 TODO] Range scan: return all (key, value) pairs where
	 * begin_key <= key <= end_key.
	 *
	 * @param begin_key  Inclusive lower bound.
	 * @param end_key    Inclusive upper bound.
	 * @return Vector of (key, value) pairs in ascending key order.
	 *
	 * Hints:
	 *   1. Search down to the leaf containing begin_key.
	 *   2. Scan forward through leaf nodes using next_leaf pointers.
	 *   3. Collect entries until key > end_key.
	 *
	 * Expected: ~20 lines
	 */
	std::vector<std::pair<int32_t, page_id_t>> RangeScan(int32_t begin_key,
	                                                      int32_t end_key);

	/**
	 * [Project #3 TODO] Delete a key from the B+-Tree.
	 *
	 * @param key  The key to delete.
	 * @return true if the key was found and deleted, false if not found.
	 *
	 * Hints:
	 *   1. Navigate to the leaf containing the key (like Search).
	 *   2. Find the key in the leaf using binary search.
	 *   3. If not found, return false.
	 *   4. Remove the key and its associated value from the leaf.
	 *   5. Save the modified leaf.
	 *   6. No merge/redistribute needed — underflow is allowed.
	 *
	 * Expected: ~20 lines
	 */
	bool Delete(int32_t key);

	/** Get the current root page id. */
	page_id_t GetRootPageId() const { return root_page_id_; }

	// ============================================================
	// Provided: Node serialization/deserialization (not TODO)
	// ============================================================

	/** Serialize a BPTreeNode into a page's data buffer. */
	static void SerializeNode(char* data, const BPTreeNode& node);

	/** Deserialize a BPTreeNode from a page's data buffer. */
	static BPTreeNode DeserializeNode(const char* data);

private:
	BufferManager* buffer_manager_;
	page_id_t root_page_id_;

	/**
	 * [Project #3 TODO] Insert a key and new child pointer into an internal node.
	 * If the node overflows, split it and propagate upward.
	 *
	 * @param node_page_id  The internal node to insert into.
	 * @param key           The key to insert (pushed up from child split).
	 * @param right_child   The new child page to the right of key.
	 * @param parent_path   Stack of (page_id, child_index) from root to this node.
	 *
	 * Expected: ~30 lines
	 */
	void InsertIntoInternal(page_id_t node_page_id, int32_t key,
	                        page_id_t right_child,
	                        std::vector<std::pair<page_id_t, int>>& parent_path);

	// Helper: load a node from buffer pool
	BPTreeNode LoadNode(page_id_t page_id);
	// Helper: save a node to buffer pool
	void SaveNode(page_id_t page_id, const BPTreeNode& node);
	// Helper: allocate a new page and initialize it as a node
	page_id_t AllocateNode(const BPTreeNode& node);
	// Helper: find child index for key in internal node (uses upper_bound)
	static int FindChildIndex(const BPTreeNode& node, int32_t key);
};

} // namespace minidb
