#include "index/bptree.h"

#include <algorithm>
#include <cstring>

namespace minidb {

BPTree::BPTree(BufferManager* buffer_manager, page_id_t root_page_id)
	: buffer_manager_(buffer_manager), root_page_id_(root_page_id) {}

// ============================================================
// Provided: Serialization / Deserialization (not TODO)
// ============================================================

void BPTree::SerializeNode(char* data, const BPTreeNode& node) {
	size_t pos = 0;

	// is_leaf (1 byte)
	data[pos++] = node.is_leaf ? 1 : 0;

	// num_keys (2 bytes)
	uint16_t num_keys = static_cast<uint16_t>(node.keys.size());
	std::memcpy(data + pos, &num_keys, sizeof(uint16_t));
	pos += sizeof(uint16_t);

	// next_leaf (4 bytes)
	std::memcpy(data + pos, &node.next_leaf, sizeof(page_id_t));
	pos += sizeof(page_id_t);

	// keys
	for (auto k : node.keys) {
		std::memcpy(data + pos, &k, KEY_SIZE);
		pos += KEY_SIZE;
	}

	// children (internal) or values (leaf)
	if (node.is_leaf) {
		for (auto v : node.values) {
			std::memcpy(data + pos, &v, PTR_SIZE);
			pos += PTR_SIZE;
		}
	} else {
		for (auto c : node.children) {
			std::memcpy(data + pos, &c, PTR_SIZE);
			pos += PTR_SIZE;
		}
	}
}

BPTreeNode BPTree::DeserializeNode(const char* data) {
	BPTreeNode node;
	size_t pos = 0;

	node.is_leaf = (data[pos++] != 0);

	uint16_t num_keys;
	std::memcpy(&num_keys, data + pos, sizeof(uint16_t));
	pos += sizeof(uint16_t);

	std::memcpy(&node.next_leaf, data + pos, sizeof(page_id_t));
	pos += sizeof(page_id_t);

	node.keys.resize(num_keys);
	for (uint16_t i = 0; i < num_keys; ++i) {
		std::memcpy(&node.keys[i], data + pos, KEY_SIZE);
		pos += KEY_SIZE;
	}

	if (node.is_leaf) {
		node.values.resize(num_keys);
		for (uint16_t i = 0; i < num_keys; ++i) {
			std::memcpy(&node.values[i], data + pos, PTR_SIZE);
			pos += PTR_SIZE;
		}
	} else {
		node.children.resize(num_keys + 1);
		for (uint16_t i = 0; i <= num_keys; ++i) {
			std::memcpy(&node.children[i], data + pos, PTR_SIZE);
			pos += PTR_SIZE;
		}
	}

	return node;
}

// ============================================================
// Provided: Helper functions (not TODO)
// ============================================================

BPTreeNode BPTree::LoadNode(page_id_t page_id) {
	Page* page = buffer_manager_->FetchPage(page_id);
	BPTreeNode node = DeserializeNode(page->GetData());
	buffer_manager_->UnpinPage(page_id, false);
	return node;
}

void BPTree::SaveNode(page_id_t page_id, const BPTreeNode& node) {
	Page* page = buffer_manager_->FetchPage(page_id);
	SerializeNode(page->GetData(), node);
	buffer_manager_->UnpinPage(page_id, true);
}

page_id_t BPTree::AllocateNode(const BPTreeNode& node) {
	Page* page = buffer_manager_->NewPage();
	page_id_t pid = page->GetPageId();
	SerializeNode(page->GetData(), node);
	buffer_manager_->UnpinPage(pid, true);
	return pid;
}

int BPTree::FindChildIndex(const BPTreeNode& node, int32_t key) {
	// upper_bound: children[i] handles keys <= keys[i-1], children[i+1] handles keys > keys[i]
	// For key == keys[i], we go to children[i+1] (the right subtree).
	auto it = std::upper_bound(node.keys.begin(), node.keys.end(), key);
	return static_cast<int>(it - node.keys.begin());
}

// ============================================================
// [Project #3 TODO] Implement the following five functions.
// ============================================================

#ifndef REFERENCE_IMPL

std::optional<page_id_t> BPTree::Search(int32_t key) {
	// TODO: Traverse from root to leaf, binary search for key.
	(void)key;
	return std::nullopt;
}

void BPTree::Insert(int32_t key, page_id_t value) {
	// TODO: Find leaf, insert in memory, split if overflow, then save.
	(void)key;
	(void)value;
}

std::vector<std::pair<int32_t, page_id_t>> BPTree::RangeScan(int32_t begin_key,
                                                              int32_t end_key) {
	// TODO: Find leaf for begin_key, scan forward via next_leaf until end_key.
	(void)begin_key;
	(void)end_key;
	return {};
}

bool BPTree::Delete(int32_t key) {
	// TODO: Navigate to leaf, remove key if found, save leaf.
	(void)key;
	return false;
}

void BPTree::InsertIntoInternal(page_id_t node_page_id, int32_t key,
                                page_id_t right_child,
                                std::vector<std::pair<page_id_t, int>>& parent_path) {
	// TODO: Insert key + right_child into internal node. Split if overflow.
	(void)node_page_id;
	(void)key;
	(void)right_child;
	(void)parent_path;
}

#endif // REFERENCE_IMPL

} // namespace minidb
