#pragma once

#include <cmath>
#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

namespace minidb {

/**
 * Fixed-dimension float vector for similarity search.
 */
struct Vector {
	std::vector<float> data;

	uint32_t Dim() const { return static_cast<uint32_t>(data.size()); }

	std::string ToString() const {
		std::ostringstream oss;
		oss << "[";
		for (size_t i = 0; i < data.size(); ++i) {
			if (i > 0) oss << ", ";
			oss << data[i];
		}
		oss << "]";
		return oss.str();
	}

	bool operator==(const Vector& other) const { return data == other.data; }
};

/**
 * [Project #7 TODO] Compute L2 (Euclidean) distance between two vectors.
 *
 * @param a  First vector.
 * @param b  Second vector (must have same dimension).
 * @return   L2 distance (NOT squared — take the sqrt).
 *
 * Hints:
 *   - Sum of (a[i] - b[i])^2 for all dimensions, then sqrt.
 *   - Assume a.Dim() == b.Dim().
 *
 * Expected: ~8 lines
 */
float L2Distance(const Vector& a, const Vector& b);

/**
 * Parse a vector literal string like "[1.0, 2.0, 3.0]" into a Vector.
 */
inline Vector ParseVectorLiteral(const std::string& s) {
	Vector v;
	std::string inner = s;
	// Remove brackets
	if (!inner.empty() && inner.front() == '[') inner = inner.substr(1);
	if (!inner.empty() && inner.back() == ']') inner.pop_back();
	std::istringstream iss(inner);
	std::string token;
	while (std::getline(iss, token, ',')) {
		v.data.push_back(std::stof(token));
	}
	return v;
}

} // namespace minidb
