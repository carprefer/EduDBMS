#include "vector/diskann_index.h"

#include <algorithm>
#include <numeric>
#include <random>

namespace minidb {

DiskANNIndex::DiskANNIndex(uint32_t max_degree, uint32_t beam_width)
	: max_degree_(max_degree), beam_width_(beam_width) {}

// ============================================================
// [Project #7 TODO] Implement the following four functions.
// ============================================================

#ifndef REFERENCE_IMPL

float L2Distance(const Vector& a, const Vector& b) {
	// TODO: Compute L2 (Euclidean) distance.
	(void)a; (void)b;
	return 0.0f;
}

void DiskANNIndex::Build(const std::vector<Vector>& vectors) {
	// TODO: Vamana construction — greedy search + robust prune for each node.
	vectors_ = vectors;
	adjacency_.resize(vectors.size());
	entry_point_ = 0;
}

std::vector<std::pair<uint32_t, float>> DiskANNIndex::Search(
		const Vector& query, uint32_t k) {
	// TODO: Greedy beam search from entry_point_.
	(void)query; (void)k;
	return {};
}

void DiskANNIndex::RobustPrune(uint32_t node_id,
                                std::vector<std::pair<uint32_t, float>>& candidates) {
	// TODO: Select up to max_degree_ neighbors with diversity.
	(void)node_id; (void)candidates;
}

#endif // REFERENCE_IMPL

} // namespace minidb
