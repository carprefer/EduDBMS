#pragma once

#include <cstdint>
#include <functional>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "vector/vector_types.h"

namespace minidb {

/**
 * DiskANN-style graph index for approximate nearest neighbor search.
 *
 * Each node in the graph stores a vector and a list of neighbor node IDs.
 * The graph is constructed using a simplified Vamana algorithm:
 *   1. Start with a random graph
 *   2. For each vector, find approximate nearest neighbors via greedy search
 *   3. Add edges to those neighbors (with max degree R)
 *
 * Search uses greedy beam search:
 *   1. Start from an entry point
 *   2. Explore neighbors of the closest unvisited node
 *   3. Maintain a candidate list of size L (beam width)
 *   4. Return top-K results when search converges
 *
 * In a real DiskANN, nodes are stored on disk pages. Here we use an
 * in-memory adjacency list for simplicity, but the algorithm is the same.
 */
class DiskANNIndex {
public:
	/**
	 * @param max_degree  Maximum number of neighbors per node (R).
	 * @param beam_width  Search beam width (L). Must be >= K for queries.
	 */
	explicit DiskANNIndex(uint32_t max_degree = 32, uint32_t beam_width = 64);

	/**
	 * [Project #7 TODO] Build the index from a set of vectors.
	 *
	 * Simplified Vamana construction:
	 *   1. Add all vectors as nodes (node_id = index in vector).
	 *   2. Set entry_point_ = 0 (first node).
	 *   3. For each node i (in random order):
	 *      a. Run GreedySearch(vectors[i], beam_width) to find L candidates.
	 *      b. Call RobustPrune(i, candidates) to select up to R neighbors.
	 *      c. For each selected neighbor j, add reverse edge j→i
	 *         (also prune j's neighbor list if it exceeds R).
	 *
	 * @param vectors  The dataset of vectors to index.
	 *
	 * Expected: ~40 lines
	 */
	void Build(const std::vector<Vector>& vectors);

	/**
	 * [Project #7 TODO] Search for the K nearest neighbors of a query vector.
	 *
	 * Greedy beam search:
	 *   1. Start with entry_point_ in the candidate set.
	 *   2. While there are unvisited candidates:
	 *      a. Pick the closest unvisited candidate.
	 *      b. Mark it as visited.
	 *      c. For each of its neighbors:
	 *         - Compute distance to query.
	 *         - Add to candidate set if closer than the farthest candidate
	 *           (or if candidate set has < L entries).
	 *      d. Keep candidate set size <= L (remove farthest if needed).
	 *   3. Return the top K candidates sorted by distance.
	 *
	 * @param query  The query vector.
	 * @param k      Number of nearest neighbors to return.
	 * @return Vector of (node_id, distance) pairs, sorted by distance.
	 *
	 * Expected: ~45 lines
	 */
	std::vector<std::pair<uint32_t, float>> Search(const Vector& query, uint32_t k);

	/**
	 * [Project #7 TODO] Robust pruning: select up to R neighbors from candidates.
	 *
	 * Greedy selection that balances proximity and diversity:
	 *   1. Sort candidates by distance to node.
	 *   2. Greedily add the closest candidate to the neighbor list.
	 *   3. For remaining candidates, skip if the candidate is closer to
	 *      any already-selected neighbor than to the node (alpha pruning
	 *      with alpha=1.0 for simplicity).
	 *   4. Stop when R neighbors are selected or candidates exhausted.
	 *
	 * @param node_id     The node to prune neighbors for.
	 * @param candidates  Candidate neighbors with distances.
	 *
	 * Expected: ~25 lines
	 */
	void RobustPrune(uint32_t node_id,
	                 std::vector<std::pair<uint32_t, float>>& candidates);

	/** Get the number of indexed vectors. */
	uint32_t Size() const { return static_cast<uint32_t>(vectors_.size()); }

	/** Get a vector by node ID. */
	const Vector& GetVector(uint32_t node_id) const { return vectors_[node_id]; }

private:
	uint32_t max_degree_;   // R
	uint32_t beam_width_;   // L
	uint32_t entry_point_ = 0;

	std::vector<Vector> vectors_;
	std::vector<std::vector<uint32_t>> adjacency_;  // neighbor lists
};

} // namespace minidb
