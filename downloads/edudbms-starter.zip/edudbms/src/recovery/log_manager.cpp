#include "recovery/log_manager.h"

#include <cstring>
#include <stdexcept>
#include <vector>

namespace minidb {

LogManager::LogManager(const std::string& log_file_path)
	: log_file_path_(log_file_path) {
	log_file_.open(log_file_path_, std::ios::binary | std::ios::in | std::ios::out | std::ios::app);
	if (!log_file_.is_open()) {
		log_file_.open(log_file_path_, std::ios::binary | std::ios::trunc | std::ios::in | std::ios::out);
	}

	// A log that already holds records — a restart after a crash — goes on
	// from the LSN after its last one. Starting again at 1 would give the
	// records recovery appends (CLRs, ABORTs) LSNs the log already used, below
	// every recLSN, and the next recovery's Redo would skip them.
	log_file_.seekg(0, std::ios::end);
	auto file_size = log_file_.tellg();
	if (file_size > 0) {
		std::vector<uint8_t> data(static_cast<size_t>(file_size));
		log_file_.seekg(0, std::ios::beg);
		log_file_.read(reinterpret_cast<char*>(data.data()), file_size);
		size_t pos = 0;
		uint32_t len = 0;
		while (pos + sizeof(len) <= data.size()) {
			std::memcpy(&len, data.data() + pos, sizeof(len));
			pos += sizeof(len);
			if (pos + len > data.size()) break;
			LogRecord rec;
			LogRecord::Deserialize(data.data() + pos, len, rec);
			if (rec.lsn >= next_lsn_) next_lsn_ = rec.lsn + 1;
			pos += len;
		}
		flushed_lsn_ = next_lsn_ - 1;
	}
	log_file_.clear();
}

LogManager::~LogManager() {
	if (!log_buffer_.empty()) {
		FlushLog(next_lsn_ - 1);
	}
	if (log_file_.is_open()) log_file_.close();
}

lsn_t LogManager::GetLastLSN(txn_id_t txn_id) const {
	auto it = last_lsn_.find(txn_id);
	return it != last_lsn_.end() ? it->second : INVALID_LSN;
}

// ============================================================
// [Project #6 TODO] Implement the following three functions.
// ============================================================

#ifndef REFERENCE_IMPL

lsn_t LogManager::AppendLog(LogRecord& record) {
	// TODO: Assign LSN, set prev_lsn, serialize, buffer, force on COMMIT.
	(void)record;
	return 0;
}

void LogManager::FlushLog(lsn_t up_to_lsn) {
	// TODO: Write buffer to file, update flushed_lsn_, clear buffer.
	(void)up_to_lsn;
}

std::vector<LogRecord> LogManager::ReadAllLogs() {
	// TODO: Read log file, deserialize all records.
	return {};
}

#endif // REFERENCE_IMPL

} // namespace minidb
