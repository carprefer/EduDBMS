#include "recovery/log_manager.h"

#include <stdexcept>

namespace minidb {

LogManager::LogManager(const std::string& log_file_path)
	: log_file_path_(log_file_path) {
	log_file_.open(log_file_path_, std::ios::binary | std::ios::in | std::ios::out | std::ios::app);
	if (!log_file_.is_open()) {
		log_file_.open(log_file_path_, std::ios::binary | std::ios::trunc | std::ios::in | std::ios::out);
	}
}

LogManager::~LogManager() {
	if (!log_buffer_.empty()) {
		FlushLog(next_lsn_ - 1);
	}
	if (log_file_.is_open()) log_file_.close();
}

lsn_t LogManager::GetLastLSN(txn_id_t txn_id) const {
	auto it = last_lsn_.find(txn_id);
	return it != last_lsn_.end() ? it->second : INVALID_LSN;
}

// ============================================================
// [Project #6 TODO] Implement the following three functions.
// ============================================================

#ifndef REFERENCE_IMPL

lsn_t LogManager::AppendLog(LogRecord& record) {
	// TODO: Assign LSN, set prev_lsn, serialize, buffer, force on COMMIT.
	(void)record;
	return 0;
}

void LogManager::FlushLog(lsn_t up_to_lsn) {
	// TODO: Write buffer to file, update flushed_lsn_, clear buffer.
	(void)up_to_lsn;
}

std::vector<LogRecord> LogManager::ReadAllLogs() {
	// TODO: Read log file, deserialize all records.
	return {};
}

#endif // REFERENCE_IMPL

} // namespace minidb
