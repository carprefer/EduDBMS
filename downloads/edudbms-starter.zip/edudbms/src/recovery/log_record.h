#pragma once

#include <cstring>
#include <string>
#include <vector>

#include "common/config.h"

namespace minidb {

enum class LogRecordType : uint8_t {
	BEGIN,
	COMMIT,
	ABORT,
	UPDATE,      // page modification with before/after images
	CLR,         // compensation log record (undo of an update)
	CHECKPOINT,  // fuzzy checkpoint
};

inline std::string LogRecordTypeToString(LogRecordType type) {
	switch (type) {
		case LogRecordType::BEGIN:      return "BEGIN";
		case LogRecordType::COMMIT:     return "COMMIT";
		case LogRecordType::ABORT:      return "ABORT";
		case LogRecordType::UPDATE:     return "UPDATE";
		case LogRecordType::CLR:        return "CLR";
		case LogRecordType::CHECKPOINT: return "CHECKPOINT";
	}
	return "?";
}

/**
 * Log record layout (simplified ARIES):
 *
 * All records:    [lsn] [txn_id] [prev_lsn] [type]
 * UPDATE/CLR:     + [page_id] [offset] [length] [before_image] [after_image]
 * CLR:            + [undo_next_lsn]
 * CHECKPOINT:     + [active_txn_count] [dirty_page_count]
 *                 + [txn_id, last_lsn] * active_txn_count
 *                 + [page_id, rec_lsn] * dirty_page_count
 */
struct LogRecord {
	lsn_t lsn = INVALID_LSN;
	txn_id_t txn_id = INVALID_TXN_ID;
	lsn_t prev_lsn = INVALID_LSN;  // previous LSN for same transaction
	LogRecordType type = LogRecordType::BEGIN;

	// UPDATE / CLR fields
	page_id_t page_id = INVALID_PAGE_ID;
	uint16_t offset = 0;
	uint16_t length = 0;
	std::vector<uint8_t> before_image;
	std::vector<uint8_t> after_image;

	// CLR: the LSN of the next record to undo for this txn
	lsn_t undo_next_lsn = INVALID_LSN;

	// CHECKPOINT fields
	std::vector<std::pair<txn_id_t, lsn_t>> active_txns;   // (txn_id, last_lsn)
	std::vector<std::pair<page_id_t, lsn_t>> dirty_pages;  // (page_id, rec_lsn)

	std::string ToString() const {
		std::string s = "LSN=" + std::to_string(lsn) +
			" TXN=" + std::to_string(txn_id) +
			" " + LogRecordTypeToString(type);
		if (type == LogRecordType::UPDATE || type == LogRecordType::CLR) {
			s += " page=" + std::to_string(page_id) +
				" off=" + std::to_string(offset) +
				" len=" + std::to_string(length);
		}
		if (type == LogRecordType::CLR) {
			s += " undo_next=" + std::to_string(undo_next_lsn);
		}
		return s;
	}

	/** Serialize to bytes for writing to log file. */
	std::vector<uint8_t> Serialize() const;

	/** Deserialize from bytes. Returns number of bytes consumed. */
	static size_t Deserialize(const uint8_t* data, size_t data_len, LogRecord& out);
};

} // namespace minidb
