#include "recovery/log_record.h"

#include <cstring>
#include <stdexcept>

namespace minidb {

std::vector<uint8_t> LogRecord::Serialize() const {
	std::vector<uint8_t> buf;
	auto append = [&](const void* p, size_t n) {
		auto* bytes = reinterpret_cast<const uint8_t*>(p);
		buf.insert(buf.end(), bytes, bytes + n);
	};

	append(&lsn, sizeof(lsn));
	append(&txn_id, sizeof(txn_id));
	append(&prev_lsn, sizeof(prev_lsn));
	uint8_t t = static_cast<uint8_t>(type);
	append(&t, 1);

	if (type == LogRecordType::UPDATE || type == LogRecordType::CLR) {
		append(&page_id, sizeof(page_id));
		append(&offset, sizeof(offset));
		append(&length, sizeof(length));
		append(before_image.data(), length);
		append(after_image.data(), length);
		if (type == LogRecordType::CLR) {
			append(&undo_next_lsn, sizeof(undo_next_lsn));
		}
	}

	if (type == LogRecordType::CHECKPOINT) {
		uint32_t atc = static_cast<uint32_t>(active_txns.size());
		uint32_t dpc = static_cast<uint32_t>(dirty_pages.size());
		append(&atc, sizeof(atc));
		append(&dpc, sizeof(dpc));
		for (const auto& [tid, lsn_val] : active_txns) {
			append(&tid, sizeof(tid));
			append(&lsn_val, sizeof(lsn_val));
		}
		for (const auto& [pid, rlsn] : dirty_pages) {
			append(&pid, sizeof(pid));
			append(&rlsn, sizeof(rlsn));
		}
	}

	return buf;
}

size_t LogRecord::Deserialize(const uint8_t* data, size_t data_len, LogRecord& out) {
	size_t pos = 0;
	auto read = [&](void* p, size_t n) {
		if (pos + n > data_len) throw std::runtime_error("Log record truncated");
		std::memcpy(p, data + pos, n);
		pos += n;
	};

	read(&out.lsn, sizeof(out.lsn));
	read(&out.txn_id, sizeof(out.txn_id));
	read(&out.prev_lsn, sizeof(out.prev_lsn));
	uint8_t t;
	read(&t, 1);
	out.type = static_cast<LogRecordType>(t);

	if (out.type == LogRecordType::UPDATE || out.type == LogRecordType::CLR) {
		read(&out.page_id, sizeof(out.page_id));
		read(&out.offset, sizeof(out.offset));
		read(&out.length, sizeof(out.length));
		out.before_image.resize(out.length);
		read(out.before_image.data(), out.length);
		out.after_image.resize(out.length);
		read(out.after_image.data(), out.length);
		if (out.type == LogRecordType::CLR) {
			read(&out.undo_next_lsn, sizeof(out.undo_next_lsn));
		}
	}

	if (out.type == LogRecordType::CHECKPOINT) {
		uint32_t atc, dpc;
		read(&atc, sizeof(atc));
		read(&dpc, sizeof(dpc));
		out.active_txns.resize(atc);
		for (uint32_t i = 0; i < atc; ++i) {
			read(&out.active_txns[i].first, sizeof(txn_id_t));
			read(&out.active_txns[i].second, sizeof(lsn_t));
		}
		out.dirty_pages.resize(dpc);
		for (uint32_t i = 0; i < dpc; ++i) {
			read(&out.dirty_pages[i].first, sizeof(page_id_t));
			read(&out.dirty_pages[i].second, sizeof(lsn_t));
		}
	}

	return pos;
}

} // namespace minidb
