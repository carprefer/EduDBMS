#include "recovery/recovery_manager.h"

#include <algorithm>
#include <queue>

namespace minidb {

RecoveryManager::RecoveryManager(LogManager* log_manager,
                                 BufferManager* buffer_manager,
                                 DiskManager* disk_manager)
	: log_manager_(log_manager),
	  buffer_manager_(buffer_manager),
	  disk_manager_(disk_manager) {}

// ============================================================
// Normal operation (provided, not TODO)
// ============================================================

txn_id_t RecoveryManager::Begin() {
	txn_id_t txn_id = next_txn_id_++;
	LogRecord rec;
	rec.txn_id = txn_id;
	rec.type = LogRecordType::BEGIN;
	log_manager_->AppendLog(rec);
	att_[txn_id] = rec.lsn;
	return txn_id;
}

void RecoveryManager::Commit(txn_id_t txn_id) {
	LogRecord rec;
	rec.txn_id = txn_id;
	rec.type = LogRecordType::COMMIT;
	log_manager_->AppendLog(rec);
	att_.erase(txn_id);
}

void RecoveryManager::Abort(txn_id_t txn_id) {
	// Flush log so ReadAllLogs sees everything
	log_manager_->FlushLog(log_manager_->GetNextLSN() - 1);
	auto logs = log_manager_->ReadAllLogs();
	std::unordered_map<lsn_t, size_t> lsn_to_idx;
	for (size_t i = 0; i < logs.size(); ++i) lsn_to_idx[logs[i].lsn] = i;

	lsn_t current_lsn = att_.count(txn_id) ? att_[txn_id] : INVALID_LSN;

	while (current_lsn != INVALID_LSN) {
		auto it = lsn_to_idx.find(current_lsn);
		if (it == lsn_to_idx.end()) break;
		const LogRecord& rec = logs[it->second];

		if (rec.type == LogRecordType::UPDATE) {
			// Write CLR
			LogRecord clr;
			clr.txn_id = txn_id;
			clr.type = LogRecordType::CLR;
			clr.page_id = rec.page_id;
			clr.offset = rec.offset;
			clr.length = rec.length;
			clr.before_image = rec.after_image;
			clr.after_image = rec.before_image;
			clr.undo_next_lsn = rec.prev_lsn;
			log_manager_->AppendLog(clr);

			ApplyImage(rec.page_id, rec.offset, rec.length, rec.before_image, clr.lsn);
		}

		current_lsn = rec.prev_lsn;
	}

	LogRecord abort_rec;
	abort_rec.txn_id = txn_id;
	abort_rec.type = LogRecordType::ABORT;
	log_manager_->AppendLog(abort_rec);
	att_.erase(txn_id);
}

lsn_t RecoveryManager::LogUpdate(txn_id_t txn_id, page_id_t page_id,
                                  uint16_t offset, uint16_t length,
                                  const uint8_t* before_image,
                                  const uint8_t* after_image) {
	LogRecord rec;
	rec.txn_id = txn_id;
	rec.type = LogRecordType::UPDATE;
	rec.page_id = page_id;
	rec.offset = offset;
	rec.length = length;
	rec.before_image.assign(before_image, before_image + length);
	rec.after_image.assign(after_image, after_image + length);
	lsn_t lsn = log_manager_->AppendLog(rec);
	att_[txn_id] = lsn;

	if (dpt_.find(page_id) == dpt_.end()) {
		dpt_[page_id] = lsn;
	}

	return lsn;
}

void RecoveryManager::Checkpoint() {
	LogRecord rec;
	rec.txn_id = INVALID_TXN_ID;
	rec.type = LogRecordType::CHECKPOINT;
	for (const auto& [tid, last_lsn] : att_) {
		rec.active_txns.push_back({tid, last_lsn});
	}
	for (const auto& [pid, rec_lsn] : dpt_) {
		rec.dirty_pages.push_back({pid, rec_lsn});
	}
	log_manager_->AppendLog(rec);
}

void RecoveryManager::ApplyImage(page_id_t page_id, uint16_t offset,
                                  uint16_t length,
                                  const std::vector<uint8_t>& image, lsn_t lsn) {
	Page* page = buffer_manager_->FetchPage(page_id);
	if (!page) return;
	std::memcpy(page->GetData() + offset, image.data(), length);
	page->SetPageLSN(lsn);
	buffer_manager_->UnpinPage(page_id, true);
}

// ============================================================
// [Project #6 TODO] Recovery: Analyze, Redo, Undo
// ============================================================

#ifndef REFERENCE_IMPL

void RecoveryManager::Recover() {
	// TODO: Read logs, then call Analyze, Redo, Undo.
}

void RecoveryManager::Analyze(const std::vector<LogRecord>& logs) {
	// TODO: Build ATT and DPT from log records.
	(void)logs;
}

void RecoveryManager::Redo(const std::vector<LogRecord>& logs) {
	// TODO: Re-apply changes for dirty pages.
	(void)logs;
}

void RecoveryManager::Undo(const std::vector<LogRecord>& logs) {
	// TODO: Roll back uncommitted transactions.
	(void)logs;
}

#endif // REFERENCE_IMPL

} // namespace minidb
