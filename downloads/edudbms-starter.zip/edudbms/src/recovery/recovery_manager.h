#pragma once

#include <set>
#include <unordered_map>

#include "buffer/buffer_manager.h"
#include "common/config.h"
#include "disk/disk_manager.h"
#include "recovery/log_manager.h"

namespace minidb {

/**
 * RecoveryManager implements the ARIES recovery algorithm.
 *
 * ARIES recovery has three phases:
 *
 * 1. **Analysis**: Scan the log from the last checkpoint to reconstruct:
 *    - Active Transaction Table (ATT): txns that were running at crash
 *    - Dirty Page Table (DPT): pages that may need redo
 *
 * 2. **Redo**: Replay log from the earliest recLSN in DPT forward.
 *    Re-apply all UPDATE/CLR records to bring pages to their
 *    pre-crash state. Skip if pageLSN >= record LSN (already applied).
 *
 * 3. **Undo**: Roll back all uncommitted transactions by following
 *    prev_lsn chains backward, writing CLR records for each undo.
 */
class RecoveryManager {
public:
	RecoveryManager(LogManager* log_manager, BufferManager* buffer_manager,
	                DiskManager* disk_manager);

	// ============================================================
	// Normal operation: called by the engine during execution
	// ============================================================

	/** Begin a new transaction. */
	txn_id_t Begin();

	/** Commit a transaction (force log to disk). */
	void Commit(txn_id_t txn_id);

	/** Abort a transaction (undo its changes). */
	void Abort(txn_id_t txn_id);

	/** Log a page update (called by buffer manager before modifying a page). */
	lsn_t LogUpdate(txn_id_t txn_id, page_id_t page_id,
	                uint16_t offset, uint16_t length,
	                const uint8_t* before_image, const uint8_t* after_image);

	/** Write a checkpoint record. */
	void Checkpoint();

	// ============================================================
	// Recovery: called on startup after a crash
	// ============================================================

	/**
	 * [Project #6 TODO] Run the full ARIES recovery algorithm.
	 *
	 * Calls Analyze(), Redo(), Undo() in sequence.
	 *
	 * Expected: ~5 lines
	 */
	void Recover();

	/**
	 * [Project #6 TODO] Analysis phase: scan log to build ATT and DPT.
	 *
	 * Start from the last CHECKPOINT (or beginning if none).
	 * For each log record:
	 *   - BEGIN: add txn to ATT
	 *   - COMMIT/ABORT: remove txn from ATT
	 *   - UPDATE/CLR: add txn to ATT, update lastLSN;
	 *     if page not in DPT, add with recLSN = record.lsn
	 *   - CHECKPOINT: initialize ATT and DPT from checkpoint data
	 *
	 * @param logs  All log records in order.
	 *
	 * Expected: ~40 lines
	 */
	void Analyze(const std::vector<LogRecord>& logs);

	/**
	 * [Project #6 TODO] Redo phase: re-apply all changes from DPT's min recLSN.
	 *
	 * For each UPDATE/CLR record with LSN >= min(recLSN in DPT):
	 *   - Skip if page not in DPT
	 *   - Skip if record.lsn < DPT[page].recLSN
	 *   - Skip if page's current pageLSN >= record.lsn (already applied)
	 *   - Otherwise: apply the after_image to the page, set pageLSN
	 *
	 * @param logs  All log records in order.
	 *
	 * Expected: ~35 lines
	 */
	void Redo(const std::vector<LogRecord>& logs);

	/**
	 * [Project #6 TODO] Undo phase: roll back all uncommitted transactions.
	 *
	 * Collect the lastLSN of each transaction in ATT.
	 * Use a max-heap (priority queue) to process in reverse LSN order.
	 * For each record:
	 *   - If UPDATE: write a CLR with undo_next = record.prev_lsn,
	 *     apply the before_image to the page.
	 *   - If CLR: follow undo_next_lsn (skip the already-undone record).
	 *   - If undo_next_lsn == INVALID_LSN, transaction is fully undone;
	 *     write an ABORT record.
	 *
	 * @param logs  All log records (used to look up records by LSN).
	 *
	 * Expected: ~50 lines
	 */
	void Undo(const std::vector<LogRecord>& logs);

private:
	LogManager* log_manager_;
	BufferManager* buffer_manager_;
	DiskManager* disk_manager_;
	txn_id_t next_txn_id_ = 1;

	// Active Transaction Table: txn_id -> lastLSN
	std::unordered_map<txn_id_t, lsn_t> att_;
	// Dirty Page Table: page_id -> recLSN (first LSN that dirtied the page)
	std::unordered_map<page_id_t, lsn_t> dpt_;

	// Helper: apply image to a page at given offset
	void ApplyImage(page_id_t page_id, uint16_t offset, uint16_t length,
	                const std::vector<uint8_t>& image, lsn_t lsn);
};

} // namespace minidb
