#pragma once

#include <fstream>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "common/config.h"
#include "recovery/log_record.h"

namespace minidb {

/**
 * LogManager handles writing log records to a WAL (Write-Ahead Log) file
 * and reading them back for recovery.
 *
 * WAL protocol: log records must be flushed to disk BEFORE the corresponding
 * dirty page is written to disk. This is enforced by the buffer manager
 * calling FlushLog(page_lsn) before flushing a page.
 */
class LogManager {
public:
	explicit LogManager(const std::string& log_file_path);
	~LogManager();

	/**
	 * [Project #6 TODO] Append a log record to the WAL. Assign it an LSN.
	 *
	 * @param record  The log record to append (lsn will be set).
	 * @return The assigned LSN.
	 *
	 * Hints:
	 *   - Assign lsn = next_lsn_++
	 *   - If the record has a txn_id, update last_lsn_[txn_id] and set prev_lsn.
	 *   - Serialize the record and append to log_buffer_.
	 *   - For COMMIT and CHECKPOINT, flush immediately (force to disk).
	 *
	 * Expected: ~20 lines
	 */
	lsn_t AppendLog(LogRecord& record);

	/**
	 * [Project #6 TODO] Flush all buffered log records up to the given LSN to disk.
	 *
	 * @param up_to_lsn  Flush logs with LSN <= this value.
	 *
	 * Hints:
	 *   - Write log_buffer_ to the log file.
	 *   - Update flushed_lsn_.
	 *   - Clear the buffer.
	 *
	 * Expected: ~10 lines
	 */
	void FlushLog(lsn_t up_to_lsn);

	/**
	 * [Project #6 TODO] Read all log records from the log file.
	 *
	 * @return Vector of all log records in order.
	 *
	 * Hints:
	 *   - Read entire log file into memory.
	 *   - Deserialize records one by one using LogRecord::Deserialize.
	 *
	 * Expected: ~15 lines
	 */
	std::vector<LogRecord> ReadAllLogs();

	lsn_t GetNextLSN() const { return next_lsn_; }
	lsn_t GetFlushedLSN() const { return flushed_lsn_; }
	lsn_t GetLastLSN(txn_id_t txn_id) const;

private:
	std::string log_file_path_;
	std::fstream log_file_;
	lsn_t next_lsn_ = 1;
	lsn_t flushed_lsn_ = 0;
	std::unordered_map<txn_id_t, lsn_t> last_lsn_;  // txn_id -> last LSN
	std::vector<uint8_t> log_buffer_;
};

} // namespace minidb
