#pragma once

#include <cstddef>
#include <functional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

namespace minidb {

// ============================================================
// DataType
// ============================================================
enum class DataType {
	INTEGER,
	FLOAT,
	STRING,
	BOOLEAN,
	VECTOR,
};

inline std::string DataTypeToString(DataType type) {
	switch (type) {
		case DataType::INTEGER: return "INTEGER";
		case DataType::FLOAT:   return "FLOAT";
		case DataType::STRING:  return "STRING";
		case DataType::BOOLEAN: return "BOOLEAN";
		case DataType::VECTOR:  return "VECTOR";
	}
	return "UNKNOWN";
}

// ============================================================
// Value
// ============================================================
class Value {
public:
	using Variant = std::variant<int, double, std::string, bool>;

	Value() : data_(0) {}
	explicit Value(int v) : data_(v) {}
	explicit Value(double v) : data_(v) {}
	explicit Value(std::string v) : data_(std::move(v)) {}
	explicit Value(bool v) : data_(v) {}

	DataType GetType() const {
		return std::visit([](auto&& arg) -> DataType {
			using T = std::decay_t<decltype(arg)>;
			if constexpr (std::is_same_v<T, int>)         return DataType::INTEGER;
			if constexpr (std::is_same_v<T, double>)      return DataType::FLOAT;
			if constexpr (std::is_same_v<T, std::string>) return DataType::STRING;
			if constexpr (std::is_same_v<T, bool>)        return DataType::BOOLEAN;
		}, data_);
	}

	int AsInt() const { return std::get<int>(data_); }
	double AsFloat() const { return std::get<double>(data_); }
	const std::string& AsString() const { return std::get<std::string>(data_); }
	bool AsBool() const { return std::get<bool>(data_); }

	const Variant& GetVariant() const { return data_; }

	std::string ToString() const {
		return std::visit([](auto&& arg) -> std::string {
			using T = std::decay_t<decltype(arg)>;
			if constexpr (std::is_same_v<T, int>)         return std::to_string(arg);
			if constexpr (std::is_same_v<T, double>)      return std::to_string(arg);
			if constexpr (std::is_same_v<T, std::string>) return arg;
			if constexpr (std::is_same_v<T, bool>)        return arg ? "TRUE" : "FALSE";
		}, data_);
	}

	bool operator==(const Value& other) const { return data_ == other.data_; }
	bool operator!=(const Value& other) const { return data_ != other.data_; }
	bool operator<(const Value& other) const { return data_ < other.data_; }
	bool operator>(const Value& other) const { return data_ > other.data_; }
	bool operator<=(const Value& other) const { return data_ <= other.data_; }
	bool operator>=(const Value& other) const { return data_ >= other.data_; }

	struct Hash {
		std::size_t operator()(const Value& v) const {
			return std::visit([](auto&& arg) -> std::size_t {
				using T = std::decay_t<decltype(arg)>;
				return std::hash<T>{}(arg);
			}, v.data_);
		}
	};

private:
	Variant data_;
};

// Row type: column_name -> Value
using Row = std::unordered_map<std::string, Value>;

// ============================================================
// RecordID: page + slot within that page
// ============================================================
struct RecordID {
	uint32_t page_id;
	uint16_t slot_id;

	bool operator==(const RecordID& other) const {
		return page_id == other.page_id && slot_id == other.slot_id;
	}
};

// ============================================================
// Column & Schema
// ============================================================
class Column {
public:
	Column(std::string name, DataType type)
		: name_(std::move(name)), type_(type) {}

	const std::string& GetName() const { return name_; }
	DataType GetType() const { return type_; }

	std::string ToString() const {
		return name_ + " " + DataTypeToString(type_);
	}

private:
	std::string name_;
	DataType type_;
};

class Schema {
public:
	Schema() = default;
	explicit Schema(std::vector<Column> columns)
		: columns_(std::move(columns)) {}

	const std::vector<Column>& GetColumns() const { return columns_; }

	bool HasColumn(const std::string& name) const {
		for (const auto& col : columns_) {
			if (col.GetName() == name) return true;
		}
		return false;
	}

	const Column& GetColumn(const std::string& name) const {
		for (const auto& col : columns_) {
			if (col.GetName() == name) return col;
		}
		throw std::runtime_error("Column not found: " + name);
	}

	size_t GetColumnIndex(const std::string& name) const {
		for (size_t i = 0; i < columns_.size(); ++i) {
			if (columns_[i].GetName() == name) return i;
		}
		throw std::runtime_error("Column not found: " + name);
	}

	std::string ToString() const {
		std::ostringstream oss;
		oss << "Schema(";
		for (size_t i = 0; i < columns_.size(); ++i) {
			if (i > 0) oss << ", ";
			oss << columns_[i].ToString();
		}
		oss << ")";
		return oss.str();
	}

	friend std::ostream& operator<<(std::ostream& os, const Schema& schema) {
		os << schema.ToString();
		return os;
	}

private:
	std::vector<Column> columns_;
};

// ============================================================
// Statistics
// ============================================================
struct ColumnStats {
	Value min_val;
	Value max_val;
	size_t num_distinct = 0;
	size_t row_count = 0;
};

class TableStats {
public:
	void SetColumnStats(const std::string& col_name, ColumnStats stats) {
		stats_[col_name] = std::move(stats);
	}

	const ColumnStats& GetColumnStats(const std::string& col_name) const {
		auto it = stats_.find(col_name);
		if (it == stats_.end()) {
			throw std::runtime_error("No stats for column: " + col_name);
		}
		return it->second;
	}

	bool HasColumnStats(const std::string& col_name) const {
		return stats_.count(col_name) > 0;
	}

private:
	std::unordered_map<std::string, ColumnStats> stats_;
};

} // namespace minidb
