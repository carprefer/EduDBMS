#pragma once

#include <cstdint>
#include <limits>

namespace minidb {

// Page and buffer configuration
static constexpr uint32_t DB_PAGE_SIZE = 4096;
static constexpr uint32_t DEFAULT_BUFFER_POOL_SIZE = 16;
static constexpr uint32_t INVALID_PAGE_ID = std::numeric_limits<uint32_t>::max();
static constexpr uint16_t INVALID_SLOT_ID = std::numeric_limits<uint16_t>::max();

// Type aliases
using page_id_t = uint32_t;
using frame_id_t = uint32_t;
using slot_id_t = uint16_t;
using lsn_t = uint64_t;
using txn_id_t = uint32_t;

static constexpr lsn_t INVALID_LSN = 0;
static constexpr txn_id_t INVALID_TXN_ID = 0;

} // namespace minidb
