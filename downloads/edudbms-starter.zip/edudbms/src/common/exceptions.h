#pragma once

#include <stdexcept>
#include <string>

namespace minidb {

class TypeMismatchException : public std::runtime_error {
public:
	explicit TypeMismatchException(const std::string& msg)
		: std::runtime_error(msg) {}
};

class NotImplementedException : public std::runtime_error {
public:
	explicit NotImplementedException(const std::string& msg)
		: std::runtime_error("Not implemented: " + msg) {}
};

class BufferFullException : public std::runtime_error {
public:
	explicit BufferFullException(const std::string& msg)
		: std::runtime_error("Buffer full: " + msg) {}
};

class PageNotFoundException : public std::runtime_error {
public:
	explicit PageNotFoundException(const std::string& msg)
		: std::runtime_error("Page not found: " + msg) {}
};

class RecordNotFoundException : public std::runtime_error {
public:
	explicit RecordNotFoundException(const std::string& msg)
		: std::runtime_error("Record not found: " + msg) {}
};

class IndexException : public std::runtime_error {
public:
	explicit IndexException(const std::string& msg)
		: std::runtime_error("Index error: " + msg) {}
};

class ParseException : public std::runtime_error {
public:
	explicit ParseException(const std::string& msg)
		: std::runtime_error("Parse error: " + msg) {}
};

} // namespace minidb
