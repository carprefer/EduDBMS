#include "planner/planner.h"

#include <stdexcept>

namespace minidb {

Planner::Planner(const Catalog& catalog) : catalog_(catalog) {}

std::unique_ptr<LogicalPlanNode> Planner::Plan(const Statement& stmt) {
	auto* select = dynamic_cast<const SelectStatement*>(&stmt);
	if (!select) throw std::runtime_error("Only SELECT statements are supported");
	return PlanSelect(*select);
}

std::unique_ptr<LogicalPlanNode> Planner::PlanSelect(const SelectStatement& stmt) {
	const auto& from_tables = stmt.GetFromTables();
	const auto& joins = stmt.GetJoins();

	for (const auto& t : from_tables) {
		if (!catalog_.HasTable(t)) throw std::runtime_error("Table not found: " + t);
	}
	for (const auto& j : joins) {
		if (!catalog_.HasTable(j.table_name)) throw std::runtime_error("Table not found: " + j.table_name);
	}

	std::vector<std::string> all_tables = from_tables;
	for (const auto& j : joins) all_tables.push_back(j.table_name);

	// Check for vector similarity query first
	auto vector_plan = TryPlanVectorScan(stmt);
	if (vector_plan) {
		// Wrap with projection
		std::vector<std::unique_ptr<Expression>> proj_cols;
		if (!stmt.IsSelectAll()) {
			for (const auto& expr : stmt.GetSelectList()) {
				proj_cols.push_back(CloneExpression(expr.get()));
			}
		}
		return std::make_unique<LogicalProject>(
			std::move(proj_cols), stmt.IsSelectAll(), std::move(vector_plan));
	}

	std::unique_ptr<LogicalPlanNode> plan;
	bool is_multi = all_tables.size() > 1;

	if (is_multi) {
		std::unique_ptr<Expression> remaining_filter;
		plan = BuildNaryJoin(stmt, all_tables, remaining_filter);
		if (remaining_filter) {
			plan = std::make_unique<LogicalFilter>(std::move(remaining_filter), std::move(plan));
		}
	} else {
		plan = std::make_unique<LogicalScan>(from_tables[0]);
		if (stmt.GetWhere()) {
			plan = std::make_unique<LogicalFilter>(CloneExpression(stmt.GetWhere()), std::move(plan));
		}
	}

	// Aggregate (Project #4 TODO)
	plan = PlanAggregate(stmt, std::move(plan));

	// Sort (Project #4 TODO)
	plan = PlanSort(stmt, std::move(plan));

	// Projection
	std::vector<std::unique_ptr<Expression>> proj_cols;
	if (!stmt.IsSelectAll()) {
		for (const auto& expr : stmt.GetSelectList()) {
			proj_cols.push_back(CloneExpression(expr.get()));
		}
	}
	plan = std::make_unique<LogicalProject>(std::move(proj_cols), stmt.IsSelectAll(), std::move(plan));

	return plan;
}

std::unique_ptr<LogicalPlanNode> Planner::BuildNaryJoin(
		const SelectStatement& stmt,
		const std::vector<std::string>& all_tables,
		std::unique_ptr<Expression>& remaining_filter) {
	auto join_node = std::make_unique<LogicalJoin>();
	for (const auto& t : all_tables) {
		join_node->AddChild(std::make_unique<LogicalScan>(t));
	}
	for (const auto& jc : stmt.GetJoins()) {
		if (jc.condition) join_node->AddCondition(CloneExpression(jc.condition.get()));
	}
	if (stmt.GetWhere()) {
		std::vector<std::unique_ptr<Expression>> filter_parts;
		ExtractConditions(stmt.GetWhere(), *join_node, all_tables, filter_parts);
		remaining_filter = CombineWithAnd(filter_parts);
	}
	return join_node;
}

void Planner::ExtractConditions(const Expression* expr, LogicalJoin& join_node,
                                const std::vector<std::string>& tables,
                                std::vector<std::unique_ptr<Expression>>& filter_parts) {
	auto* binop = dynamic_cast<const BinaryOp*>(expr);
	if (!binop) { filter_parts.push_back(CloneExpression(expr)); return; }
	if (binop->GetOp() == BinaryOpType::AND) {
		ExtractConditions(binop->GetLeft(), join_node, tables, filter_parts);
		ExtractConditions(binop->GetRight(), join_node, tables, filter_parts);
	} else {
		std::set<std::string> refs;
		CollectTableRefs(expr, refs);
		if (refs.size() >= 2) {
			join_node.AddCondition(CloneExpression(expr));
		} else {
			filter_parts.push_back(CloneExpression(expr));
		}
	}
}

std::unique_ptr<Expression> Planner::CombineWithAnd(std::vector<std::unique_ptr<Expression>>& parts) {
	if (parts.empty()) return nullptr;
	auto result = std::move(parts[0]);
	for (size_t i = 1; i < parts.size(); ++i) {
		result = std::make_unique<BinaryOp>(BinaryOpType::AND, std::move(result), std::move(parts[i]));
	}
	return result;
}

void Planner::CollectTableRefs(const Expression* expr, std::set<std::string>& tables) {
	if (auto* col = dynamic_cast<const ColumnRef*>(expr)) {
		if (!col->GetTableName().empty()) tables.insert(col->GetTableName());
	} else if (auto* binop = dynamic_cast<const BinaryOp*>(expr)) {
		CollectTableRefs(binop->GetLeft(), tables);
		CollectTableRefs(binop->GetRight(), tables);
	}
}

std::unique_ptr<Expression> Planner::CloneExpression(const Expression* expr) {
	if (!expr) return nullptr;
	if (auto* col = dynamic_cast<const ColumnRef*>(expr)) {
		return std::make_unique<ColumnRef>(col->GetColumnName(), col->GetTableName());
	}
	if (auto* lit = dynamic_cast<const Literal*>(expr)) {
		return std::make_unique<Literal>(lit->GetLiteralType(), lit->GetValue());
	}
	if (auto* binop = dynamic_cast<const BinaryOp*>(expr)) {
		return std::make_unique<BinaryOp>(binop->GetOp(),
			CloneExpression(binop->GetLeft()), CloneExpression(binop->GetRight()));
	}
	if (auto* agg = dynamic_cast<const AggregateExpr*>(expr)) {
		return std::make_unique<AggregateExpr>(agg->GetFunc(),
			CloneExpression(agg->GetArgument()), agg->IsCountStar());
	}
	if (auto* dist = dynamic_cast<const DistanceExpr*>(expr)) {
		return std::make_unique<DistanceExpr>(
			CloneExpression(dist->GetColumn()),
			CloneExpression(dist->GetTarget()));
	}
	if (auto* vec = dynamic_cast<const VectorLiteral*>(expr)) {
		return std::make_unique<VectorLiteral>(vec->GetValue());
	}
	throw std::runtime_error("Unknown expression type in clone");
}

// ============================================================
// [Project #4 TODO] PlanAggregate and PlanSort
// ============================================================

#ifndef REFERENCE_IMPL

std::unique_ptr<LogicalPlanNode> Planner::TryPlanVectorScan(const SelectStatement& stmt) {
	// TODO: If ORDER BY has DistanceExpr and LIMIT is set, create LogicalVectorScan.
	(void)stmt;
	return nullptr;
}

std::unique_ptr<LogicalPlanNode> Planner::PlanAggregate(const SelectStatement& stmt,
                                                        std::unique_ptr<LogicalPlanNode> child) {
	// TODO: If stmt has GROUP BY or aggregate functions, create LogicalAggregate.
	(void)stmt;
	return child;
}

std::unique_ptr<LogicalPlanNode> Planner::PlanSort(const SelectStatement& stmt,
                                                   std::unique_ptr<LogicalPlanNode> child) {
	// TODO: If stmt has ORDER BY, create LogicalSort.
	(void)stmt;
	return child;
}

#endif // REFERENCE_IMPL

} // namespace minidb
