#pragma once

#include <memory>
#include <set>

#include "catalog/catalog.h"
#include "parser/ast.h"
#include "planner/logical_plan.h"

namespace minidb {

class Planner {
public:
	explicit Planner(const Catalog& catalog);

	std::unique_ptr<LogicalPlanNode> Plan(const Statement& stmt);

private:
	std::unique_ptr<LogicalPlanNode> PlanSelect(const SelectStatement& stmt);

	std::unique_ptr<LogicalPlanNode> BuildNaryJoin(
		const SelectStatement& stmt,
		const std::vector<std::string>& all_tables,
		std::unique_ptr<Expression>& remaining_filter);

	void ExtractConditions(const Expression* expr, LogicalJoin& join_node,
	                       const std::vector<std::string>& tables,
	                       std::vector<std::unique_ptr<Expression>>& filter_parts);

	std::unique_ptr<Expression> CombineWithAnd(std::vector<std::unique_ptr<Expression>>& parts);
	void CollectTableRefs(const Expression* expr, std::set<std::string>& tables);
	std::unique_ptr<Expression> CloneExpression(const Expression* expr);

	/**
	 * [Project #4 TODO] Create a LogicalAggregate node from the SELECT statement.
	 *
	 * @param stmt   The SELECT statement with GROUP BY and aggregate expressions.
	 * @param child  The child plan node (scan/filter/join).
	 * @return LogicalAggregate wrapping the child, or just child if no aggregation.
	 *
	 * Hints:
	 *   - Clone group-by expressions from stmt.GetGroupBy().
	 *   - Find AggregateExpr nodes in stmt.GetSelectList() and clone them.
	 *   - Create a LogicalAggregate with these.
	 *
	 * Expected: ~20 lines
	 */
	std::unique_ptr<LogicalPlanNode> PlanAggregate(const SelectStatement& stmt,
	                                               std::unique_ptr<LogicalPlanNode> child);

	/**
	 * [Project #4 TODO] Create a LogicalSort node from the SELECT statement.
	 *
	 * @param stmt   The SELECT statement with ORDER BY.
	 * @param child  The child plan node.
	 * @return LogicalSort wrapping the child, or just child if no ORDER BY.
	 *
	 * Hints:
	 *   - Clone each OrderByItem expression.
	 *   - Collect ascending flags.
	 *   - Create a LogicalSort.
	 *
	 * Expected: ~15 lines
	 */
	std::unique_ptr<LogicalPlanNode> PlanSort(const SelectStatement& stmt,
	                                          std::unique_ptr<LogicalPlanNode> child);

	/**
	 * [Project #7 TODO] Detect vector similarity query and create LogicalVectorScan.
	 *
	 * If ORDER BY contains a DistanceExpr and LIMIT is set, replace the
	 * normal Scan → Sort → Project plan with LogicalVectorScan → Project.
	 *
	 * @param stmt  The SELECT statement.
	 * @return LogicalVectorScan if applicable, nullptr otherwise.
	 *
	 * Hints:
	 *   - Check stmt.HasOrderBy() && stmt.HasLimit()
	 *   - Check if ORDER BY expr is a DistanceExpr
	 *   - Extract table name, column name, target vector, and limit
	 *
	 * Expected: ~20 lines
	 */
	std::unique_ptr<LogicalPlanNode> TryPlanVectorScan(const SelectStatement& stmt);

	const Catalog& catalog_;
};

} // namespace minidb
