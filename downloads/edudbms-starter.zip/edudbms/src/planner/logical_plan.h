#pragma once

#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "parser/ast.h"

namespace minidb {

class LogicalPlanNode {
public:
	virtual ~LogicalPlanNode() = default;
	virtual std::string ToString(int indent = 0) const = 0;
	virtual std::string NodeName() const = 0;
protected:
	static std::string Indent(int level) { return std::string(level * 2, ' '); }
};

class LogicalScan : public LogicalPlanNode {
public:
	explicit LogicalScan(std::string table_name) : table_name_(std::move(table_name)) {}
	const std::string& GetTableName() const { return table_name_; }
	std::string NodeName() const override { return "LogicalScan"; }
	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "LogicalScan(" + table_name_ + ")";
	}
private:
	std::string table_name_;
};

class LogicalFilter : public LogicalPlanNode {
public:
	LogicalFilter(std::unique_ptr<Expression> predicate, std::unique_ptr<LogicalPlanNode> child)
		: predicate_(std::move(predicate)), child_(std::move(child)) {}
	Expression* GetPredicate() const { return predicate_.get(); }
	LogicalPlanNode* GetChild() const { return child_.get(); }
	std::unique_ptr<LogicalPlanNode> TakeChild() { return std::move(child_); }
	std::unique_ptr<Expression> TakePredicate() { return std::move(predicate_); }
	std::string NodeName() const override { return "LogicalFilter"; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "LogicalFilter(" << (predicate_ ? predicate_->ToString() : "") << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}
private:
	std::unique_ptr<Expression> predicate_;
	std::unique_ptr<LogicalPlanNode> child_;
};

class LogicalProject : public LogicalPlanNode {
public:
	LogicalProject(std::vector<std::unique_ptr<Expression>> columns, bool select_all,
	               std::unique_ptr<LogicalPlanNode> child)
		: columns_(std::move(columns)), select_all_(select_all), child_(std::move(child)) {}
	const std::vector<std::unique_ptr<Expression>>& GetColumns() const { return columns_; }
	bool IsSelectAll() const { return select_all_; }
	LogicalPlanNode* GetChild() const { return child_.get(); }
	std::unique_ptr<LogicalPlanNode> TakeChild() { return std::move(child_); }
	std::string NodeName() const override { return "LogicalProject"; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "LogicalProject(" << (select_all_ ? "*" : "...") << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}
private:
	std::vector<std::unique_ptr<Expression>> columns_;
	bool select_all_;
	std::unique_ptr<LogicalPlanNode> child_;
};

class LogicalJoin : public LogicalPlanNode {
public:
	void AddChild(std::unique_ptr<LogicalPlanNode> child) { children_.push_back(std::move(child)); }
	void AddCondition(std::unique_ptr<Expression> condition) { conditions_.push_back(std::move(condition)); }
	const std::vector<std::unique_ptr<LogicalPlanNode>>& GetChildren() const { return children_; }
	const std::vector<std::unique_ptr<Expression>>& GetConditions() const { return conditions_; }
	std::vector<std::unique_ptr<LogicalPlanNode>> TakeChildren() { return std::move(children_); }
	std::vector<std::unique_ptr<Expression>> TakeConditions() { return std::move(conditions_); }
	std::string NodeName() const override { return "LogicalJoin"; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "LogicalJoin(...)";
		for (const auto& c : children_) oss << "\n" << c->ToString(indent + 1);
		return oss.str();
	}
private:
	std::vector<std::unique_ptr<LogicalPlanNode>> children_;
	std::vector<std::unique_ptr<Expression>> conditions_;
};

class LogicalAggregate : public LogicalPlanNode {
public:
	LogicalAggregate(std::vector<std::unique_ptr<Expression>> group_by_keys,
	                 std::vector<std::unique_ptr<Expression>> aggregate_exprs,
	                 std::unique_ptr<LogicalPlanNode> child)
		: group_by_keys_(std::move(group_by_keys)),
		  aggregate_exprs_(std::move(aggregate_exprs)),
		  child_(std::move(child)) {}
	const std::vector<std::unique_ptr<Expression>>& GetGroupByKeys() const { return group_by_keys_; }
	const std::vector<std::unique_ptr<Expression>>& GetAggregateExprs() const { return aggregate_exprs_; }
	LogicalPlanNode* GetChild() const { return child_.get(); }
	std::unique_ptr<LogicalPlanNode> TakeChild() { return std::move(child_); }
	std::string NodeName() const override { return "LogicalAggregate"; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "LogicalAggregate(groups=" << group_by_keys_.size()
		    << ", aggs=" << aggregate_exprs_.size() << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}
private:
	std::vector<std::unique_ptr<Expression>> group_by_keys_;
	std::vector<std::unique_ptr<Expression>> aggregate_exprs_;
	std::unique_ptr<LogicalPlanNode> child_;
};

class LogicalSort : public LogicalPlanNode {
public:
	LogicalSort(std::vector<std::unique_ptr<Expression>> sort_keys,
	            std::vector<bool> ascending,
	            std::unique_ptr<LogicalPlanNode> child)
		: sort_keys_(std::move(sort_keys)),
		  ascending_(std::move(ascending)),
		  child_(std::move(child)) {}
	const std::vector<std::unique_ptr<Expression>>& GetSortKeys() const { return sort_keys_; }
	const std::vector<bool>& GetAscending() const { return ascending_; }
	LogicalPlanNode* GetChild() const { return child_.get(); }
	std::unique_ptr<LogicalPlanNode> TakeChild() { return std::move(child_); }
	std::string NodeName() const override { return "LogicalSort"; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "LogicalSort(keys=" << sort_keys_.size() << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}
private:
	std::vector<std::unique_ptr<Expression>> sort_keys_;
	std::vector<bool> ascending_;
	std::unique_ptr<LogicalPlanNode> child_;
};

// ============================================================
// Vector Similarity: LogicalVectorScan
// ============================================================

class LogicalVectorScan : public LogicalPlanNode {
public:
	LogicalVectorScan(std::string table_name, std::string column_name,
	                  std::unique_ptr<Expression> target_vector, int limit)
		: table_name_(std::move(table_name)),
		  column_name_(std::move(column_name)),
		  target_vector_(std::move(target_vector)),
		  limit_(limit) {}

	const std::string& GetTableName() const { return table_name_; }
	const std::string& GetColumnName() const { return column_name_; }
	Expression* GetTargetVector() const { return target_vector_.get(); }
	int GetLimit() const { return limit_; }
	std::string NodeName() const override { return "LogicalVectorScan"; }
	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "LogicalVectorScan(" + table_name_ + "." +
		       column_name_ + ", limit=" + std::to_string(limit_) + ")";
	}

private:
	std::string table_name_;
	std::string column_name_;
	std::unique_ptr<Expression> target_vector_;
	int limit_;
};

} // namespace minidb
