#pragma once

#include <memory>
#include <vector>

#include "parser/ast.h"
#include "parser/lexer.h"

namespace minidb {

class Parser {
public:
	explicit Parser(const std::string& sql);

	/** Parse a SELECT statement. Throws on unsupported DDL/DML. */
	std::unique_ptr<Statement> Parse();

	/** Extended parse for CLI: CREATE TABLE, INSERT, SELECT, EXPLAIN. */
	std::unique_ptr<Statement> ParseCLI();

private:
	// Statement parsers
	std::unique_ptr<SelectStatement> ParseSelect();
	std::unique_ptr<ExplainStatement> ParseExplain();
	std::unique_ptr<CreateTableStatement> ParseCreateTable();
	std::unique_ptr<InsertStatement> ParseInsert();

	void ParseJoinClause(SelectStatement& stmt);

	/**
	 * [Project #4 TODO] Parse GROUP BY clause.
	 * Called after WHERE. If next tokens are GROUP BY, parse comma-separated
	 * column references and add them to stmt via AddGroupByExpr().
	 *
	 * Grammar: GROUP BY expr (, expr)*
	 *
	 * Hints:
	 *   - Check for KW_GROUP, then expect KW_BY.
	 *   - Parse column references (same as ParsePrimary).
	 *   - Loop with COMMA.
	 *
	 * Expected: ~15 lines
	 */
	void ParseGroupBy(SelectStatement& stmt);

	/**
	 * [Project #4 TODO] Parse ORDER BY clause.
	 * Called after GROUP BY (or WHERE). If next tokens are ORDER BY,
	 * parse comma-separated sort keys with optional ASC/DESC.
	 *
	 * Grammar: ORDER BY expr [ASC|DESC] (, expr [ASC|DESC])*
	 *
	 * Hints:
	 *   - Check for KW_ORDER, then expect KW_BY.
	 *   - For each item: parse expression, then check for KW_ASC or KW_DESC.
	 *   - Default is ascending.
	 *   - Add to stmt via AddOrderByItem().
	 *
	 * Expected: ~20 lines
	 */
	void ParseOrderBy(SelectStatement& stmt);

	/**
	 * [Project #4 TODO] Parse an aggregate function expression.
	 * Called when ParsePrimary detects COUNT/SUM/AVG/MIN/MAX followed by '('.
	 *
	 * Grammar: FUNC_NAME '(' (expr | '*') ')'
	 *
	 * Hints:
	 *   - The function keyword has already been consumed. Receive func type as param.
	 *   - Expect LPAREN.
	 *   - If STAR, it's COUNT(*).
	 *   - Otherwise, parse the argument expression.
	 *   - Expect RPAREN.
	 *   - Return an AggregateExpr node.
	 *
	 * Expected: ~15 lines
	 */
	std::unique_ptr<AggregateExpr> ParseAggregateExpr(AggFunc func);

	/**
	 * [Project #7 TODO] Parse LIMIT clause.
	 * Called after ORDER BY. If next token is KW_LIMIT, consume it
	 * and parse the integer value.
	 *
	 * Grammar: LIMIT integer
	 *
	 * Expected: ~8 lines
	 */
	void ParseLimit(SelectStatement& stmt);

	/**
	 * [Project #7 TODO] Parse a distance expression: expr <-> expr
	 * Called from ParseComparison when OP_L2_DIST is detected.
	 *
	 * @param left  The already-parsed left expression (column reference).
	 * @return A DistanceExpr node wrapping left and the right operand.
	 *
	 * Expected: ~5 lines
	 */
	std::unique_ptr<Expression> ParseDistanceExpr(std::unique_ptr<Expression> left);

	// Expression parsers
	std::unique_ptr<Expression> ParseOrExpr();
	std::unique_ptr<Expression> ParseAndExpr();
	std::unique_ptr<Expression> ParseComparison();
	std::unique_ptr<Expression> ParsePrimary();

	// Token helpers
	bool IsComparisonOp() const;
	BinaryOpType ParseComparisonOp();
	bool IsAggregateKeyword() const;
	AggFunc GetAggFunc() const;
	const Token& Peek() const;
	bool Check(TokenType type) const;
	bool Match(TokenType type);
	Token Advance();
	void Expect(TokenType type);
	std::string ExpectIdentifier();

	std::vector<Token> tokens_;
	size_t pos_;
};

} // namespace minidb
