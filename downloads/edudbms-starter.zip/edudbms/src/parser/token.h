#pragma once

#include <string>

namespace minidb {

enum class TokenType {
	// Keywords
	KW_SELECT, KW_FROM, KW_WHERE, KW_AND, KW_OR,
	KW_JOIN, KW_INNER, KW_ON,
	KW_CREATE, KW_TABLE, KW_INSERT, KW_UPDATE, KW_DELETE,
	KW_EXPLAIN,
	KW_GROUP, KW_ORDER, KW_BY, KW_HAVING, KW_LIMIT,
	KW_LEFT, KW_RIGHT, KW_FULL, KW_OUTER,
	KW_AS, KW_IN, KW_EXISTS,
	KW_ASC, KW_DESC, KW_DROP,
	KW_INTO, KW_VALUES,

	// Aggregate function keywords
	KW_COUNT, KW_SUM, KW_AVG, KW_MIN, KW_MAX,

	// Vector
	KW_VECTOR,
	OP_L2_DIST,  // <->
	LIT_VECTOR,  // [1.0, 2.0, 3.0]

	// Identifiers & Literals
	IDENTIFIER, LIT_INTEGER, LIT_FLOAT, LIT_STRING, LIT_BOOLEAN,

	// Operators
	OP_EQ, OP_NE, OP_LT, OP_GT, OP_LE, OP_GE,

	// Punctuation
	COMMA, DOT, LPAREN, RPAREN, STAR, SEMICOLON,

	// Special
	END_OF_FILE,
};

struct Token {
	TokenType type;
	std::string value;
	size_t line = 1;
	size_t col = 1;

	Token() : type(TokenType::END_OF_FILE) {}
	Token(TokenType type, std::string value, size_t line = 1, size_t col = 1)
		: type(type), value(std::move(value)), line(line), col(col) {}
};

inline std::string TokenTypeToString(TokenType type) {
	switch (type) {
		case TokenType::KW_SELECT: return "SELECT";
		case TokenType::KW_FROM: return "FROM";
		case TokenType::KW_WHERE: return "WHERE";
		case TokenType::KW_AND: return "AND";
		case TokenType::KW_OR: return "OR";
		case TokenType::KW_JOIN: return "JOIN";
		case TokenType::KW_INNER: return "INNER";
		case TokenType::KW_ON: return "ON";
		case TokenType::KW_CREATE: return "CREATE";
		case TokenType::KW_TABLE: return "TABLE";
		case TokenType::KW_INSERT: return "INSERT";
		case TokenType::KW_UPDATE: return "UPDATE";
		case TokenType::KW_DELETE: return "DELETE";
		case TokenType::KW_EXPLAIN: return "EXPLAIN";
		case TokenType::KW_GROUP: return "GROUP";
		case TokenType::KW_ORDER: return "ORDER";
		case TokenType::KW_BY: return "BY";
		case TokenType::KW_HAVING: return "HAVING";
		case TokenType::KW_LIMIT: return "LIMIT";
		case TokenType::KW_LEFT: return "LEFT";
		case TokenType::KW_RIGHT: return "RIGHT";
		case TokenType::KW_FULL: return "FULL";
		case TokenType::KW_OUTER: return "OUTER";
		case TokenType::KW_AS: return "AS";
		case TokenType::KW_IN: return "IN";
		case TokenType::KW_EXISTS: return "EXISTS";
		case TokenType::KW_ASC: return "ASC";
		case TokenType::KW_DESC: return "DESC";
		case TokenType::KW_DROP: return "DROP";
		case TokenType::KW_INTO: return "INTO";
		case TokenType::KW_VALUES: return "VALUES";
		case TokenType::KW_COUNT: return "COUNT";
		case TokenType::KW_SUM: return "SUM";
		case TokenType::KW_AVG: return "AVG";
		case TokenType::KW_MIN: return "MIN";
		case TokenType::KW_MAX: return "MAX";
		case TokenType::IDENTIFIER: return "IDENTIFIER";
		case TokenType::LIT_INTEGER: return "INTEGER";
		case TokenType::LIT_FLOAT: return "FLOAT";
		case TokenType::LIT_STRING: return "STRING";
		case TokenType::LIT_BOOLEAN: return "BOOLEAN";
		case TokenType::OP_EQ: return "=";
		case TokenType::OP_NE: return "!=";
		case TokenType::OP_LT: return "<";
		case TokenType::OP_GT: return ">";
		case TokenType::OP_LE: return "<=";
		case TokenType::OP_GE: return ">=";
		case TokenType::COMMA: return ",";
		case TokenType::DOT: return ".";
		case TokenType::LPAREN: return "(";
		case TokenType::RPAREN: return ")";
		case TokenType::STAR: return "*";
		case TokenType::SEMICOLON: return ";";
		case TokenType::KW_VECTOR: return "VECTOR";
		case TokenType::OP_L2_DIST: return "<->";
		case TokenType::LIT_VECTOR: return "VECTOR_LITERAL";
		case TokenType::END_OF_FILE: return "EOF";
	}
	return "UNKNOWN";
}

} // namespace minidb
