#include "parser/parser.h"

#include <algorithm>
#include <stdexcept>

#include "common/exceptions.h"

namespace minidb {

Parser::Parser(const std::string& sql) : pos_(0) {
	Lexer lexer(sql);
	tokens_ = lexer.Tokenize();
}

std::unique_ptr<Statement> Parser::Parse() {
	if (Check(TokenType::KW_CREATE) || Check(TokenType::KW_INSERT) ||
	    Check(TokenType::KW_UPDATE) || Check(TokenType::KW_DELETE)) {
		throw NotImplementedException(Peek().value + " statement");
	}
	if (!Check(TokenType::KW_SELECT)) {
		throw std::runtime_error("Expected SELECT, got '" + Peek().value + "'");
	}
	return ParseSelect();
}

std::unique_ptr<Statement> Parser::ParseCLI() {
	if (Check(TokenType::KW_CREATE)) return ParseCreateTable();
	if (Check(TokenType::KW_INSERT)) return ParseInsert();
	if (Check(TokenType::KW_EXPLAIN)) return ParseExplain();
	if (Check(TokenType::KW_SELECT)) return ParseSelect();
	throw std::runtime_error("Unsupported statement: " + Peek().value);
}

// ============================================================
// Statement parsers (provided)
// ============================================================

std::unique_ptr<SelectStatement> Parser::ParseSelect() {
	Expect(TokenType::KW_SELECT);
	auto stmt = std::make_unique<SelectStatement>();

	// SELECT list
	if (Check(TokenType::STAR)) {
		Advance(); stmt->SetSelectAll(true);
	} else {
		stmt->AddSelectExpr(ParsePrimary());
		while (Match(TokenType::COMMA)) stmt->AddSelectExpr(ParsePrimary());
	}

	// FROM
	Expect(TokenType::KW_FROM);
	stmt->AddFromTable(ExpectIdentifier());
	while (Match(TokenType::COMMA)) stmt->AddFromTable(ExpectIdentifier());

	// JOINs
	while (Check(TokenType::KW_JOIN) || Check(TokenType::KW_INNER)) {
		ParseJoinClause(*stmt);
	}

	// WHERE
	if (Match(TokenType::KW_WHERE)) stmt->SetWhere(ParseOrExpr());

	// GROUP BY (Project #4 TODO)
	ParseGroupBy(*stmt);

	// ORDER BY (Project #4 TODO)
	ParseOrderBy(*stmt);

	// LIMIT (Project #7 TODO)
	ParseLimit(*stmt);

	Match(TokenType::SEMICOLON);
	return stmt;
}

std::unique_ptr<ExplainStatement> Parser::ParseExplain() {
	Expect(TokenType::KW_EXPLAIN);
	if (!Check(TokenType::KW_SELECT)) {
		throw std::runtime_error("EXPLAIN only supports SELECT");
	}
	auto select = ParseSelect();
	return std::make_unique<ExplainStatement>(std::move(select));
}

std::unique_ptr<CreateTableStatement> Parser::ParseCreateTable() {
	Expect(TokenType::KW_CREATE);
	Expect(TokenType::KW_TABLE);
	std::string name = ExpectIdentifier();
	Expect(TokenType::LPAREN);
	std::vector<ColumnDef> columns;
	do {
		std::string col_name = ExpectIdentifier();
		std::string type_name;
		if (Check(TokenType::KW_VECTOR)) {
			Advance();
			type_name = "VECTOR";
			// Parse optional dimension: VECTOR(128)
			if (Match(TokenType::LPAREN)) {
				if (Check(TokenType::LIT_INTEGER)) {
					type_name += "(" + Advance().value + ")";
				}
				Expect(TokenType::RPAREN);
			}
		} else {
			type_name = ExpectIdentifier();
			std::transform(type_name.begin(), type_name.end(), type_name.begin(), ::toupper);
		}
		columns.push_back({col_name, type_name});
	} while (Match(TokenType::COMMA));
	Expect(TokenType::RPAREN);
	Match(TokenType::SEMICOLON);
	return std::make_unique<CreateTableStatement>(name, columns);
}

std::unique_ptr<InsertStatement> Parser::ParseInsert() {
	Expect(TokenType::KW_INSERT);
	if (Check(TokenType::KW_INTO)) Advance();
	std::string table_name = ExpectIdentifier();

	std::vector<std::string> columns;
	if (Match(TokenType::LPAREN)) {
		do { columns.push_back(ExpectIdentifier()); } while (Match(TokenType::COMMA));
		Expect(TokenType::RPAREN);
	}

	if (Check(TokenType::KW_VALUES)) {
		Advance();
	} else {
		throw std::runtime_error("Expected VALUES");
	}

	Expect(TokenType::LPAREN);
	std::vector<std::unique_ptr<Expression>> values;
	do { values.push_back(ParsePrimary()); } while (Match(TokenType::COMMA));
	Expect(TokenType::RPAREN);
	Match(TokenType::SEMICOLON);

	return std::make_unique<InsertStatement>(table_name, columns, std::move(values));
}

void Parser::ParseJoinClause(SelectStatement& stmt) {
	if (Check(TokenType::KW_INNER)) Advance();
	Expect(TokenType::KW_JOIN);
	JoinClause join;
	join.table_name = ExpectIdentifier();
	Expect(TokenType::KW_ON);
	join.condition = ParseOrExpr();
	stmt.AddJoin(std::move(join));
}

// ============================================================
// [Project #4 TODO] ParseGroupBy, ParseOrderBy, ParseAggregateExpr
// ============================================================

// ============================================================
// [Project #7 TODO] ParseLimit, ParseDistanceExpr
// ============================================================

#ifndef REFERENCE_IMPL

void Parser::ParseLimit(SelectStatement& stmt) {
	// TODO: If next token is KW_LIMIT, consume it and parse integer.
	(void)stmt;
}

std::unique_ptr<Expression> Parser::ParseDistanceExpr(std::unique_ptr<Expression> left) {
	// TODO: Consume OP_L2_DIST, parse right expression, return DistanceExpr.
	(void)left;
	throw NotImplementedException("Distance operator <->");
}

#endif // Project #7 REFERENCE_IMPL

// ============================================================
// [Project #4 TODO] ParseGroupBy, ParseOrderBy, ParseAggregateExpr
// ============================================================

#ifndef REFERENCE_IMPL

void Parser::ParseGroupBy(SelectStatement& stmt) {
	// TODO: If next tokens are GROUP BY, parse comma-separated column refs.
	(void)stmt;
}

void Parser::ParseOrderBy(SelectStatement& stmt) {
	// TODO: If next tokens are ORDER BY, parse sort keys with ASC/DESC.
	(void)stmt;
}

std::unique_ptr<AggregateExpr> Parser::ParseAggregateExpr(AggFunc func) {
	// TODO: Parse aggregate function call: FUNC(expr) or FUNC(*).
	(void)func;
	throw NotImplementedException("Aggregate functions");
}

#endif // REFERENCE_IMPL

// ============================================================
// Expression parsers (provided)
// ============================================================

std::unique_ptr<Expression> Parser::ParseOrExpr() {
	auto left = ParseAndExpr();
	while (Check(TokenType::KW_OR)) {
		Advance();
		auto right = ParseAndExpr();
		left = std::make_unique<BinaryOp>(BinaryOpType::OR, std::move(left), std::move(right));
	}
	return left;
}

std::unique_ptr<Expression> Parser::ParseAndExpr() {
	auto left = ParseComparison();
	while (Check(TokenType::KW_AND)) {
		Advance();
		auto right = ParseComparison();
		left = std::make_unique<BinaryOp>(BinaryOpType::AND, std::move(left), std::move(right));
	}
	return left;
}

std::unique_ptr<Expression> Parser::ParseComparison() {
	auto left = ParsePrimary();
	if (Check(TokenType::OP_L2_DIST)) {
		return ParseDistanceExpr(std::move(left));
	}
	if (IsComparisonOp()) {
		BinaryOpType op = ParseComparisonOp();
		auto right = ParsePrimary();
		return std::make_unique<BinaryOp>(op, std::move(left), std::move(right));
	}
	return left;
}

std::unique_ptr<Expression> Parser::ParsePrimary() {
	if (Match(TokenType::LPAREN)) {
		auto expr = ParseOrExpr();
		Expect(TokenType::RPAREN);
		return expr;
	}
	if (Check(TokenType::LIT_INTEGER)) { auto t = Advance(); return std::make_unique<Literal>(Literal::LiteralType::INTEGER, t.value); }
	if (Check(TokenType::LIT_FLOAT)) { auto t = Advance(); return std::make_unique<Literal>(Literal::LiteralType::FLOAT, t.value); }
	if (Check(TokenType::LIT_STRING)) { auto t = Advance(); return std::make_unique<Literal>(Literal::LiteralType::STRING, t.value); }
	if (Check(TokenType::LIT_BOOLEAN)) { auto t = Advance(); return std::make_unique<Literal>(Literal::LiteralType::BOOLEAN, t.value); }

	// Vector literal: [1.0, 2.0, 3.0]
	if (Check(TokenType::LIT_VECTOR)) {
		auto t = Advance();
		return std::make_unique<VectorLiteral>(t.value);
	}

	// Aggregate function: COUNT/SUM/AVG/MIN/MAX followed by '('
	if (IsAggregateKeyword()) {
		AggFunc func = GetAggFunc();
		Advance();  // consume the keyword
		return ParseAggregateExpr(func);
	}

	if (Check(TokenType::IDENTIFIER)) {
		auto name = Advance().value;
		if (Match(TokenType::DOT)) {
			auto col_name = ExpectIdentifier();
			return std::make_unique<ColumnRef>(col_name, name);
		}
		return std::make_unique<ColumnRef>(name);
	}

	throw std::runtime_error("Unexpected token '" + Peek().value + "'");
}

// ============================================================
// Token helpers (provided)
// ============================================================

bool Parser::IsComparisonOp() const {
	TokenType t = Peek().type;
	return t == TokenType::OP_EQ || t == TokenType::OP_NE ||
	       t == TokenType::OP_LT || t == TokenType::OP_GT ||
	       t == TokenType::OP_LE || t == TokenType::OP_GE;
}

BinaryOpType Parser::ParseComparisonOp() {
	Token tok = Advance();
	switch (tok.type) {
		case TokenType::OP_EQ: return BinaryOpType::EQ;
		case TokenType::OP_NE: return BinaryOpType::NE;
		case TokenType::OP_LT: return BinaryOpType::LT;
		case TokenType::OP_GT: return BinaryOpType::GT;
		case TokenType::OP_LE: return BinaryOpType::LE;
		case TokenType::OP_GE: return BinaryOpType::GE;
		default: throw std::runtime_error("Expected comparison operator");
	}
}

bool Parser::IsAggregateKeyword() const {
	TokenType t = Peek().type;
	return t == TokenType::KW_COUNT || t == TokenType::KW_SUM ||
	       t == TokenType::KW_AVG || t == TokenType::KW_MIN || t == TokenType::KW_MAX;
}

AggFunc Parser::GetAggFunc() const {
	switch (Peek().type) {
		case TokenType::KW_COUNT: return AggFunc::COUNT;
		case TokenType::KW_SUM:   return AggFunc::SUM;
		case TokenType::KW_AVG:   return AggFunc::AVG;
		case TokenType::KW_MIN:   return AggFunc::MIN;
		case TokenType::KW_MAX:   return AggFunc::MAX;
		default: throw std::runtime_error("Not an aggregate function");
	}
}

const Token& Parser::Peek() const {
	static const Token eof_sentinel{TokenType::END_OF_FILE, ""};
	if (pos_ >= tokens_.size()) return eof_sentinel;
	return tokens_[pos_];
}
bool Parser::Check(TokenType type) const { return pos_ < tokens_.size() && tokens_[pos_].type == type; }
bool Parser::Match(TokenType type) { if (Check(type)) { ++pos_; return true; } return false; }
Token Parser::Advance() { Token tok = tokens_[pos_]; if (pos_ < tokens_.size()) ++pos_; return tok; }
void Parser::Expect(TokenType type) {
	if (!Check(type)) {
		throw std::runtime_error("Expected " + TokenTypeToString(type) + ", got '" + Peek().value + "'");
	}
	++pos_;
}
std::string Parser::ExpectIdentifier() {
	if (!Check(TokenType::IDENTIFIER)) {
		throw std::runtime_error("Expected identifier, got '" + Peek().value + "'");
	}
	return Advance().value;
}

} // namespace minidb
