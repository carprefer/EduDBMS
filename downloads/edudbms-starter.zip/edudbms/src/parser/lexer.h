#pragma once

#include <string>
#include <vector>

#include "parser/token.h"

namespace minidb {

class Lexer {
public:
	explicit Lexer(std::string input);
	std::vector<Token> Tokenize();

private:
	void Advance();
	void SkipWhitespace();
	Token ReadStringLiteral();
	Token ReadNumber();
	Token ReadIdentifierOrKeyword();

	std::string input_;
	size_t pos_;
	size_t line_;
	size_t col_;
};

} // namespace minidb
