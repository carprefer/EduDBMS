#include "parser/lexer.h"

#include <algorithm>
#include <cctype>
#include <stdexcept>
#include <unordered_map>

namespace minidb {

Lexer::Lexer(std::string input)
	: input_(std::move(input)), pos_(0), line_(1), col_(1) {}

std::vector<Token> Lexer::Tokenize() {
	std::vector<Token> tokens;

	while (pos_ < input_.size()) {
		SkipWhitespace();
		if (pos_ >= input_.size()) break;

		char c = input_[pos_];
		size_t start_col = col_;

		if (c == '\'') { tokens.push_back(ReadStringLiteral()); continue; }
		if (std::isdigit(c)) { tokens.push_back(ReadNumber()); continue; }
		if (std::isalpha(c) || c == '_') { tokens.push_back(ReadIdentifierOrKeyword()); continue; }

		switch (c) {
			case '=':
				tokens.emplace_back(TokenType::OP_EQ, "=", line_, col_); Advance(); break;
			case '!':
				Advance();
				if (pos_ < input_.size() && input_[pos_] == '=') {
					tokens.emplace_back(TokenType::OP_NE, "!=", line_, start_col); Advance();
				} else {
					throw std::runtime_error("Unexpected '!' at line " + std::to_string(line_));
				}
				break;
			case '<':
				Advance();
				if (pos_ < input_.size() && input_[pos_] == '=') {
					tokens.emplace_back(TokenType::OP_LE, "<=", line_, start_col); Advance();
				} else if (pos_ < input_.size() && input_[pos_] == '-' &&
				           pos_ + 1 < input_.size() && input_[pos_ + 1] == '>') {
					// <-> operator
					Advance(); Advance();
					tokens.emplace_back(TokenType::OP_L2_DIST, "<->", line_, start_col);
				} else {
					tokens.emplace_back(TokenType::OP_LT, "<", line_, start_col);
				}
				break;
			case '>':
				Advance();
				if (pos_ < input_.size() && input_[pos_] == '=') {
					tokens.emplace_back(TokenType::OP_GE, ">=", line_, start_col); Advance();
				} else {
					tokens.emplace_back(TokenType::OP_GT, ">", line_, start_col);
				}
				break;
			case ',': tokens.emplace_back(TokenType::COMMA, ",", line_, col_); Advance(); break;
			case '.': tokens.emplace_back(TokenType::DOT, ".", line_, col_); Advance(); break;
			case '(': tokens.emplace_back(TokenType::LPAREN, "(", line_, col_); Advance(); break;
			case ')': tokens.emplace_back(TokenType::RPAREN, ")", line_, col_); Advance(); break;
			case '*': tokens.emplace_back(TokenType::STAR, "*", line_, col_); Advance(); break;
			case ';': tokens.emplace_back(TokenType::SEMICOLON, ";", line_, col_); Advance(); break;
			case '[': {
				// Vector literal: [1.0, 2.0, 3.0]
				std::string val;
				val += input_[pos_]; Advance();
				while (pos_ < input_.size() && input_[pos_] != ']') {
					val += input_[pos_]; Advance();
				}
				if (pos_ < input_.size()) { val += input_[pos_]; Advance(); }
				tokens.emplace_back(TokenType::LIT_VECTOR, val, line_, start_col);
				break;
			}
			default:
				throw std::runtime_error(std::string("Unexpected character '") + c + "'");
		}
	}

	tokens.emplace_back(TokenType::END_OF_FILE, "", line_, col_);
	return tokens;
}

void Lexer::Advance() {
	if (pos_ < input_.size()) {
		if (input_[pos_] == '\n') { ++line_; col_ = 1; }
		else { ++col_; }
		++pos_;
	}
}

void Lexer::SkipWhitespace() {
	while (pos_ < input_.size() && std::isspace(input_[pos_])) Advance();
}

Token Lexer::ReadStringLiteral() {
	size_t start_col = col_;
	Advance();
	std::string value;
	while (pos_ < input_.size() && input_[pos_] != '\'') { value += input_[pos_]; Advance(); }
	if (pos_ >= input_.size()) throw std::runtime_error("Unterminated string literal");
	Advance();
	return Token(TokenType::LIT_STRING, value, line_, start_col);
}

Token Lexer::ReadNumber() {
	size_t start_col = col_;
	std::string value;
	bool has_dot = false;
	while (pos_ < input_.size() && (std::isdigit(input_[pos_]) || input_[pos_] == '.')) {
		if (input_[pos_] == '.') { if (has_dot) break; has_dot = true; }
		value += input_[pos_]; Advance();
	}
	return Token(has_dot ? TokenType::LIT_FLOAT : TokenType::LIT_INTEGER, value, line_, start_col);
}

Token Lexer::ReadIdentifierOrKeyword() {
	size_t start_col = col_;
	std::string value;
	while (pos_ < input_.size() && (std::isalnum(input_[pos_]) || input_[pos_] == '_')) {
		value += input_[pos_]; Advance();
	}

	std::string upper = value;
	std::transform(upper.begin(), upper.end(), upper.begin(), ::toupper);

	static const std::unordered_map<std::string, TokenType> keywords = {
		{"SELECT", TokenType::KW_SELECT}, {"FROM", TokenType::KW_FROM},
		{"WHERE", TokenType::KW_WHERE}, {"AND", TokenType::KW_AND}, {"OR", TokenType::KW_OR},
		{"JOIN", TokenType::KW_JOIN}, {"INNER", TokenType::KW_INNER}, {"ON", TokenType::KW_ON},
		{"TRUE", TokenType::LIT_BOOLEAN}, {"FALSE", TokenType::LIT_BOOLEAN},
		{"CREATE", TokenType::KW_CREATE}, {"TABLE", TokenType::KW_TABLE},
		{"INSERT", TokenType::KW_INSERT}, {"UPDATE", TokenType::KW_UPDATE},
		{"DELETE", TokenType::KW_DELETE}, {"EXPLAIN", TokenType::KW_EXPLAIN},
		{"GROUP", TokenType::KW_GROUP}, {"ORDER", TokenType::KW_ORDER}, {"BY", TokenType::KW_BY},
		{"HAVING", TokenType::KW_HAVING}, {"LIMIT", TokenType::KW_LIMIT},
		{"LEFT", TokenType::KW_LEFT}, {"RIGHT", TokenType::KW_RIGHT},
		{"FULL", TokenType::KW_FULL}, {"OUTER", TokenType::KW_OUTER},
		{"AS", TokenType::KW_AS}, {"IN", TokenType::KW_IN}, {"EXISTS", TokenType::KW_EXISTS},
		{"ASC", TokenType::KW_ASC}, {"DESC", TokenType::KW_DESC}, {"DROP", TokenType::KW_DROP},
		{"INTO", TokenType::KW_INTO}, {"VALUES", TokenType::KW_VALUES},
		{"COUNT", TokenType::KW_COUNT}, {"SUM", TokenType::KW_SUM},
		{"AVG", TokenType::KW_AVG}, {"MIN", TokenType::KW_MIN}, {"MAX", TokenType::KW_MAX},
		{"VECTOR", TokenType::KW_VECTOR},
	};

	auto it = keywords.find(upper);
	if (it != keywords.end()) {
		return Token(it->second, upper, line_, start_col);
	}
	return Token(TokenType::IDENTIFIER, value, line_, start_col);
}

} // namespace minidb
