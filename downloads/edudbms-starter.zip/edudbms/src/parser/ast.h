#pragma once

#include <memory>
#include <sstream>
#include <string>
#include <vector>

namespace minidb {

// ============================================================
// AST Node Base
// ============================================================

class ASTNode {
public:
	virtual ~ASTNode() = default;
	virtual std::string ToString(int indent = 0) const = 0;

	friend std::ostream& operator<<(std::ostream& os, const ASTNode& node) {
		os << node.ToString();
		return os;
	}

protected:
	static std::string Indent(int level) {
		return std::string(level * 2, ' ');
	}
};

// ============================================================
// Expression Nodes
// ============================================================

class Expression : public ASTNode {
public:
	virtual ~Expression() = default;
};

class ColumnRef : public Expression {
public:
	explicit ColumnRef(std::string column_name, std::string table_name = "")
		: table_name_(std::move(table_name)), column_name_(std::move(column_name)) {}

	const std::string& GetTableName() const { return table_name_; }
	const std::string& GetColumnName() const { return column_name_; }

	std::string ToString(int indent = 0) const override {
		if (table_name_.empty()) return Indent(indent) + column_name_;
		return Indent(indent) + table_name_ + "." + column_name_;
	}

private:
	std::string table_name_;
	std::string column_name_;
};

class Literal : public Expression {
public:
	enum class LiteralType { INTEGER, FLOAT, STRING, BOOLEAN };

	Literal(LiteralType type, std::string value)
		: lit_type_(type), value_(std::move(value)) {}

	LiteralType GetLiteralType() const { return lit_type_; }
	const std::string& GetValue() const { return value_; }

	std::string ToString(int indent = 0) const override {
		if (lit_type_ == LiteralType::STRING) return Indent(indent) + "'" + value_ + "'";
		return Indent(indent) + value_;
	}

private:
	LiteralType lit_type_;
	std::string value_;
};

enum class BinaryOpType { EQ, NE, LT, GT, LE, GE, AND, OR };

inline std::string BinaryOpTypeToString(BinaryOpType op) {
	switch (op) {
		case BinaryOpType::EQ: return "=";
		case BinaryOpType::NE: return "!=";
		case BinaryOpType::LT: return "<";
		case BinaryOpType::GT: return ">";
		case BinaryOpType::LE: return "<=";
		case BinaryOpType::GE: return ">=";
		case BinaryOpType::AND: return "AND";
		case BinaryOpType::OR: return "OR";
	}
	return "?";
}

class BinaryOp : public Expression {
public:
	BinaryOp(BinaryOpType op, std::unique_ptr<Expression> left,
	          std::unique_ptr<Expression> right)
		: op_(op), left_(std::move(left)), right_(std::move(right)) {}

	BinaryOpType GetOp() const { return op_; }
	Expression* GetLeft() const { return left_.get(); }
	Expression* GetRight() const { return right_.get(); }
	std::unique_ptr<Expression> TakeLeft() { return std::move(left_); }
	std::unique_ptr<Expression> TakeRight() { return std::move(right_); }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "(" << BinaryOpTypeToString(op_) << "\n";
		oss << left_->ToString(indent + 1) << "\n";
		oss << right_->ToString(indent + 1) << ")";
		return oss.str();
	}

private:
	BinaryOpType op_;
	std::unique_ptr<Expression> left_;
	std::unique_ptr<Expression> right_;
};

// ============================================================
// Aggregate Expression: COUNT(*), SUM(col), AVG(col), MIN(col), MAX(col)
// ============================================================

enum class AggFunc { COUNT, SUM, AVG, MIN, MAX };

inline std::string AggFuncToString(AggFunc func) {
	switch (func) {
		case AggFunc::COUNT: return "COUNT";
		case AggFunc::SUM: return "SUM";
		case AggFunc::AVG: return "AVG";
		case AggFunc::MIN: return "MIN";
		case AggFunc::MAX: return "MAX";
	}
	return "?";
}

class AggregateExpr : public Expression {
public:
	AggregateExpr(AggFunc func, std::unique_ptr<Expression> argument, bool is_count_star = false)
		: func_(func), argument_(std::move(argument)), is_count_star_(is_count_star) {}

	AggFunc GetFunc() const { return func_; }
	Expression* GetArgument() const { return argument_.get(); }
	bool IsCountStar() const { return is_count_star_; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << AggFuncToString(func_) << "(";
		if (is_count_star_) {
			oss << "*";
		} else if (argument_) {
			oss << argument_->ToString();
		}
		oss << ")";
		return oss.str();
	}

private:
	AggFunc func_;
	std::unique_ptr<Expression> argument_;
	bool is_count_star_;
};

// ============================================================
// Distance Expression: column <-> vector_literal
// ============================================================

class DistanceExpr : public Expression {
public:
	DistanceExpr(std::unique_ptr<Expression> column, std::unique_ptr<Expression> target)
		: column_(std::move(column)), target_(std::move(target)) {}

	Expression* GetColumn() const { return column_.get(); }
	Expression* GetTarget() const { return target_.get(); }

	std::string ToString(int indent = 0) const override {
		return Indent(indent) + column_->ToString() + " <-> " + target_->ToString();
	}

private:
	std::unique_ptr<Expression> column_;
	std::unique_ptr<Expression> target_;
};

// Vector literal expression
class VectorLiteral : public Expression {
public:
	explicit VectorLiteral(std::string value) : value_(std::move(value)) {}
	const std::string& GetValue() const { return value_; }

	std::string ToString(int indent = 0) const override {
		return Indent(indent) + value_;
	}

private:
	std::string value_;
};

// ============================================================
// ORDER BY item
// ============================================================

struct OrderByItem {
	std::unique_ptr<Expression> expr;
	bool ascending = true;

	std::string ToString() const {
		return expr->ToString() + (ascending ? " ASC" : " DESC");
	}
};

// ============================================================
// Statements
// ============================================================

class Statement : public ASTNode {
public:
	virtual ~Statement() = default;
};

struct JoinClause {
	std::string table_name;
	std::unique_ptr<Expression> condition;
};

class SelectStatement : public Statement {
public:
	void SetSelectAll(bool all) { select_all_ = all; }
	bool IsSelectAll() const { return select_all_; }

	void AddSelectExpr(std::unique_ptr<Expression> expr) { select_list_.push_back(std::move(expr)); }
	void AddFromTable(std::string table_name) { from_tables_.push_back(std::move(table_name)); }
	void SetWhere(std::unique_ptr<Expression> where) { where_ = std::move(where); }
	void AddJoin(JoinClause join) { joins_.push_back(std::move(join)); }

	void AddGroupByExpr(std::unique_ptr<Expression> expr) { group_by_.push_back(std::move(expr)); }
	void AddOrderByItem(OrderByItem item) { order_by_.push_back(std::move(item)); }
	void SetLimit(int limit) { limit_ = limit; }
	int GetLimit() const { return limit_; }
	bool HasLimit() const { return limit_ > 0; }

	const std::vector<std::unique_ptr<Expression>>& GetSelectList() const { return select_list_; }
	const std::vector<std::string>& GetFromTables() const { return from_tables_; }
	Expression* GetWhere() const { return where_.get(); }
	std::unique_ptr<Expression> TakeWhere() { return std::move(where_); }
	const std::vector<JoinClause>& GetJoins() const { return joins_; }
	std::vector<JoinClause>& GetJoins() { return joins_; }
	const std::vector<std::unique_ptr<Expression>>& GetGroupBy() const { return group_by_; }
	const std::vector<OrderByItem>& GetOrderBy() const { return order_by_; }
	bool HasGroupBy() const { return !group_by_.empty(); }
	bool HasOrderBy() const { return !order_by_.empty(); }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "SELECT ";
		if (select_all_) {
			oss << "*";
		} else {
			for (size_t i = 0; i < select_list_.size(); ++i) {
				if (i > 0) oss << ", ";
				oss << select_list_[i]->ToString();
			}
		}
		oss << "\n" << Indent(indent) << "FROM ";
		for (size_t i = 0; i < from_tables_.size(); ++i) {
			if (i > 0) oss << ", ";
			oss << from_tables_[i];
		}
		for (const auto& join : joins_) {
			oss << "\n" << Indent(indent + 1) << "JOIN " << join.table_name;
			if (join.condition) oss << " ON " << join.condition->ToString();
		}
		if (where_) oss << "\n" << Indent(indent) << "WHERE " << where_->ToString();
		if (!group_by_.empty()) {
			oss << "\n" << Indent(indent) << "GROUP BY ";
			for (size_t i = 0; i < group_by_.size(); ++i) {
				if (i > 0) oss << ", ";
				oss << group_by_[i]->ToString();
			}
		}
		if (!order_by_.empty()) {
			oss << "\n" << Indent(indent) << "ORDER BY ";
			for (size_t i = 0; i < order_by_.size(); ++i) {
				if (i > 0) oss << ", ";
				oss << order_by_[i].ToString();
			}
		}
		return oss.str();
	}

private:
	bool select_all_ = false;
	std::vector<std::unique_ptr<Expression>> select_list_;
	std::vector<std::string> from_tables_;
	std::unique_ptr<Expression> where_;
	std::vector<JoinClause> joins_;
	std::vector<std::unique_ptr<Expression>> group_by_;
	std::vector<OrderByItem> order_by_;
	int limit_ = -1;
};

struct ColumnDef {
	std::string name;
	std::string type_name;
};

class CreateTableStatement : public Statement {
public:
	CreateTableStatement(std::string table_name, std::vector<ColumnDef> columns)
		: table_name_(std::move(table_name)), columns_(std::move(columns)) {}
	const std::string& GetTableName() const { return table_name_; }
	const std::vector<ColumnDef>& GetColumnDefs() const { return columns_; }
	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "CREATE TABLE " << table_name_ << "(...)";
		return oss.str();
	}
private:
	std::string table_name_;
	std::vector<ColumnDef> columns_;
};

class InsertStatement : public Statement {
public:
	InsertStatement(std::string table_name, std::vector<std::string> columns,
	                std::vector<std::unique_ptr<Expression>> values)
		: table_name_(std::move(table_name)), columns_(std::move(columns)),
		  values_(std::move(values)) {}
	const std::string& GetTableName() const { return table_name_; }
	const std::vector<std::string>& GetColumns() const { return columns_; }
	const std::vector<std::unique_ptr<Expression>>& GetValues() const { return values_; }
	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "INSERT INTO " + table_name_ + " VALUES(...)";
	}
private:
	std::string table_name_;
	std::vector<std::string> columns_;
	std::vector<std::unique_ptr<Expression>> values_;
};

class ExplainStatement : public Statement {
public:
	explicit ExplainStatement(std::unique_ptr<SelectStatement> select)
		: select_(std::move(select)) {}
	const SelectStatement& GetSelect() const { return *select_; }
	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "EXPLAIN\n" + select_->ToString(indent + 1);
	}
private:
	std::unique_ptr<SelectStatement> select_;
};

} // namespace minidb
