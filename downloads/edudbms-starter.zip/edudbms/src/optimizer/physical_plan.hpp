#pragma once

#include <memory>
#include <string>
#include <vector>
#include <sstream>

#include "parser/ast.h"

namespace minidb {

// ============================================================
// Physical Plan Node Base
// ============================================================

class PhysicalPlanNode {
public:
	virtual ~PhysicalPlanNode() = default;
	virtual std::string ToString(int indent = 0) const = 0;
	virtual std::string NodeName() const = 0;
	virtual double GetEstimatedRows() const { return estimated_rows_; }
	void SetEstimatedRows(double rows) { estimated_rows_ = rows; }

	friend std::ostream& operator<<(std::ostream& os, const PhysicalPlanNode& node) {
		os << node.ToString();
		return os;
	}

protected:
	static std::string Indent(int level) {
		return std::string(level * 2, ' ');
	}

	double estimated_rows_ = 0;
};

// ============================================================
// PhysicalSeqScan
// ============================================================

class PhysicalSeqScan : public PhysicalPlanNode {
public:
	explicit PhysicalSeqScan(std::string table_name)
		: table_name_(std::move(table_name)) {}

	const std::string& GetTableName() const { return table_name_; }
	std::string NodeName() const override { return "PhysicalSeqScan"; }

	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "PhysicalSeqScan(" + table_name_ +
		       ", rows=" + std::to_string(static_cast<int>(estimated_rows_)) + ")";
	}

private:
	std::string table_name_;
};

// ============================================================
// PhysicalFilter
// ============================================================

class PhysicalFilter : public PhysicalPlanNode {
public:
	PhysicalFilter(std::unique_ptr<Expression> predicate,
	               std::unique_ptr<PhysicalPlanNode> child)
		: predicate_(std::move(predicate)), child_(std::move(child)) {}

	Expression* GetPredicate() const { return predicate_.get(); }
	PhysicalPlanNode* GetChild() const { return child_.get(); }
	std::string NodeName() const override { return "PhysicalFilter"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalFilter(";
		if (predicate_) oss << predicate_->ToString();
		oss << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::unique_ptr<Expression> predicate_;
	std::unique_ptr<PhysicalPlanNode> child_;
};

// ============================================================
// PhysicalProject
// ============================================================

class PhysicalProject : public PhysicalPlanNode {
public:
	PhysicalProject(std::vector<std::unique_ptr<Expression>> columns,
	                bool select_all,
	                std::unique_ptr<PhysicalPlanNode> child)
		: columns_(std::move(columns)),
		  select_all_(select_all),
		  child_(std::move(child)) {}

	const std::vector<std::unique_ptr<Expression>>& GetColumns() const { return columns_; }
	bool IsSelectAll() const { return select_all_; }
	PhysicalPlanNode* GetChild() const { return child_.get(); }
	std::string NodeName() const override { return "PhysicalProject"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalProject(";
		if (select_all_) {
			oss << "*";
		} else {
			for (size_t i = 0; i < columns_.size(); ++i) {
				if (i > 0) oss << ", ";
				oss << columns_[i]->ToString();
			}
		}
		oss << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::vector<std::unique_ptr<Expression>> columns_;
	bool select_all_;
	std::unique_ptr<PhysicalPlanNode> child_;
};

// ============================================================
// PhysicalHashJoin (equi-join)
// ============================================================

class PhysicalHashJoin : public PhysicalPlanNode {
public:
	PhysicalHashJoin(std::unique_ptr<Expression> condition,
	                 std::unique_ptr<PhysicalPlanNode> left,
	                 std::unique_ptr<PhysicalPlanNode> right)
		: condition_(std::move(condition)),
		  left_(std::move(left)),
		  right_(std::move(right)) {}

	Expression* GetCondition() const { return condition_.get(); }
	PhysicalPlanNode* GetLeft() const { return left_.get(); }
	PhysicalPlanNode* GetRight() const { return right_.get(); }
	std::string NodeName() const override { return "PhysicalHashJoin"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalHashJoin(";
		if (condition_) oss << condition_->ToString();
		oss << ", rows=" << static_cast<int>(estimated_rows_) << ")\n";
		oss << left_->ToString(indent + 1) << "\n";
		oss << right_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::unique_ptr<Expression> condition_;
	std::unique_ptr<PhysicalPlanNode> left_;
	std::unique_ptr<PhysicalPlanNode> right_;
};

// ============================================================
// PhysicalNestedLoopJoin (non-equi join)
// ============================================================

class PhysicalNestedLoopJoin : public PhysicalPlanNode {
public:
	PhysicalNestedLoopJoin(std::unique_ptr<Expression> condition,
	                       std::unique_ptr<PhysicalPlanNode> left,
	                       std::unique_ptr<PhysicalPlanNode> right)
		: condition_(std::move(condition)),
		  left_(std::move(left)),
		  right_(std::move(right)) {}

	Expression* GetCondition() const { return condition_.get(); }
	PhysicalPlanNode* GetLeft() const { return left_.get(); }
	PhysicalPlanNode* GetRight() const { return right_.get(); }
	std::string NodeName() const override { return "PhysicalNestedLoopJoin"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalNestedLoopJoin(";
		if (condition_) oss << condition_->ToString();
		oss << ", rows=" << static_cast<int>(estimated_rows_) << ")\n";
		oss << left_->ToString(indent + 1) << "\n";
		oss << right_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::unique_ptr<Expression> condition_;
	std::unique_ptr<PhysicalPlanNode> left_;
	std::unique_ptr<PhysicalPlanNode> right_;
};

// ============================================================
// PhysicalSort
// ============================================================

class PhysicalSort : public PhysicalPlanNode {
public:
	PhysicalSort(std::vector<std::unique_ptr<Expression>> sort_keys,
	             std::vector<bool> ascending,
	             std::unique_ptr<PhysicalPlanNode> child)
		: sort_keys_(std::move(sort_keys)),
		  ascending_(std::move(ascending)),
		  child_(std::move(child)) {}

	const std::vector<std::unique_ptr<Expression>>& GetSortKeys() const { return sort_keys_; }
	const std::vector<bool>& GetAscending() const { return ascending_; }
	PhysicalPlanNode* GetChild() const { return child_.get(); }
	std::string NodeName() const override { return "PhysicalSort"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalSort(keys=" << sort_keys_.size() << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::vector<std::unique_ptr<Expression>> sort_keys_;
	std::vector<bool> ascending_;
	std::unique_ptr<PhysicalPlanNode> child_;
};

// ============================================================
// PhysicalAggregate
// ============================================================

class PhysicalAggregate : public PhysicalPlanNode {
public:
	PhysicalAggregate(std::vector<std::unique_ptr<Expression>> group_by_keys,
	                  std::vector<std::unique_ptr<Expression>> aggregate_exprs,
	                  std::unique_ptr<PhysicalPlanNode> child)
		: group_by_keys_(std::move(group_by_keys)),
		  aggregate_exprs_(std::move(aggregate_exprs)),
		  child_(std::move(child)) {}

	const std::vector<std::unique_ptr<Expression>>& GetGroupByKeys() const { return group_by_keys_; }
	const std::vector<std::unique_ptr<Expression>>& GetAggregateExprs() const { return aggregate_exprs_; }
	PhysicalPlanNode* GetChild() const { return child_.get(); }
	std::string NodeName() const override { return "PhysicalAggregate"; }

	std::string ToString(int indent = 0) const override {
		std::ostringstream oss;
		oss << Indent(indent) << "PhysicalAggregate(groups=" << group_by_keys_.size()
		    << ", aggs=" << aggregate_exprs_.size() << ")\n";
		oss << child_->ToString(indent + 1);
		return oss.str();
	}

private:
	std::vector<std::unique_ptr<Expression>> group_by_keys_;
	std::vector<std::unique_ptr<Expression>> aggregate_exprs_;
	std::unique_ptr<PhysicalPlanNode> child_;
};

// ============================================================
// PhysicalVectorScan
// ============================================================

class PhysicalVectorScan : public PhysicalPlanNode {
public:
	PhysicalVectorScan(std::string table_name, std::string column_name,
	                   std::unique_ptr<Expression> target_vector, int limit)
		: table_name_(std::move(table_name)),
		  column_name_(std::move(column_name)),
		  target_vector_(std::move(target_vector)),
		  limit_(limit) {}

	const std::string& GetTableName() const { return table_name_; }
	const std::string& GetColumnName() const { return column_name_; }
	Expression* GetTargetVector() const { return target_vector_.get(); }
	int GetLimit() const { return limit_; }
	std::string NodeName() const override { return "PhysicalVectorScan"; }

	std::string ToString(int indent = 0) const override {
		return Indent(indent) + "PhysicalVectorScan(" + table_name_ + "." +
		       column_name_ + ", limit=" + std::to_string(limit_) + ")";
	}

private:
	std::string table_name_;
	std::string column_name_;
	std::unique_ptr<Expression> target_vector_;
	int limit_;
};

} // namespace minidb
