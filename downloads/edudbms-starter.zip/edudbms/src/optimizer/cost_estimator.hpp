#pragma once

#include <algorithm>
#include <cmath>

#include "parser/ast.h"
#include "common/types.h"

namespace minidb {

class CostEstimator {
public:
	// Selectivity estimation for a single predicate
	double EstimateSelectivity(BinaryOpType op, const ColumnStats& stats) const {
		if (stats.num_distinct == 0) return 1.0;

		switch (op) {
			case BinaryOpType::EQ:
				return 1.0 / static_cast<double>(stats.num_distinct);
			case BinaryOpType::NE:
				return 1.0 - (1.0 / static_cast<double>(stats.num_distinct));
			case BinaryOpType::GT:
			case BinaryOpType::LT:
			case BinaryOpType::GE:
			case BinaryOpType::LE:
				return 1.0 / 3.0;  // heuristic
			case BinaryOpType::AND:
			case BinaryOpType::OR:
				return 1.0;  // not applicable for logical ops at this level
		}
		return 1.0;
	}

	// Join cardinality estimation
	// |A ⋈ B| = |A| * |B| / max(V(A, col), V(B, col))
	double EstimateJoinCardinality(double left_rows, double right_rows,
	                               size_t left_distinct, size_t right_distinct) const {
		double max_distinct = static_cast<double>(std::max(left_distinct, right_distinct));
		if (max_distinct == 0) return left_rows * right_rows;
		return (left_rows * right_rows) / max_distinct;
	}

	// Cost of sequential scan
	double ScanCost(double row_count) const {
		return row_count;
	}

	// Cost of hash join = build + probe + output
	double HashJoinCost(double left_rows, double right_rows, double output_rows) const {
		return left_rows + right_rows + output_rows;
	}

	// Cost of nested loop join = |left| * |right|
	double NestedLoopJoinCost(double left_rows, double right_rows) const {
		return left_rows * right_rows;
	}
};

} // namespace minidb
