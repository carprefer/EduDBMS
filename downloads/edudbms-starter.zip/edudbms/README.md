# EduDBMS — Full Skeleton

CSED357 Database Systems, Fall 2026, POSTECH

## Build

CMake 3.14 or newer, a C++17 compiler, and — the first time — an internet
connection, because GoogleTest is downloaded during configuration.

**Works on macOS or Linux, on either Intel or ARM. On Windows, build inside WSL: a native Windows toolchain is refused, because the reference libraries these downloads carry are built for macOS and Linux only.**

```bash
cmake -B build
cmake --build build
```

## Run the tests

```bash
ctest --test-dir build --output-on-failure
```

Each test case runs in its own process, so an unimplemented function that
crashes does not stop the rest of the suite from reporting.

## What you implement

- `src/disk/disk_manager.cpp`
- `src/buffer/replacer.cpp`
- `src/buffer/buffer_manager.cpp`
- `src/object/object_manager.cpp`
- `src/index/bptree.cpp`
- `src/parser/parser.cpp`
- `src/planner/planner.cpp`
- `src/execution/sort_exec.cpp`
- `src/execution/aggregate_exec.cpp`
- `src/execution/index_scan_exec.cpp`
- `src/recovery/log_manager.cpp`
- `src/recovery/recovery_manager.cpp`
- `src/vector/diskann_index.cpp`
- `src/execution/vector_scan_exec.cpp`

Look for the `TODO` comments in those files. The headers carry `[Project #N TODO]` blocks
as well, but those are the spec for the function you are about to write —
hints, parameters, return values. Nothing outside the `.cpp` files listed
above needs editing.

## Scope

This is the whole project skeleton with every project stub and no reference
library: nothing is implemented for you. To work on one project with the
earlier ones already working, download that project instead.
