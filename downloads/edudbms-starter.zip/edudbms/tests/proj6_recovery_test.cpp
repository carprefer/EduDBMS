#include <gtest/gtest.h>

#include <cstring>
#include <filesystem>

#include "buffer/buffer_manager.h"
#include "disk/disk_manager.h"
#include "recovery/log_manager.h"
#include "recovery/recovery_manager.h"

using namespace minidb;

class RecoveryTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_recovery.db";
	std::string log_path_ = "test_recovery.log";

	void TearDown() override {
		std::filesystem::remove(db_path_);
		std::filesystem::remove(log_path_);
	}
};

// ============================================================
// LogManager Tests
// ============================================================

TEST_F(RecoveryTest, LogAppendAndRead) {
	LogManager lm(log_path_);

	LogRecord r1;
	r1.txn_id = 1;
	r1.type = LogRecordType::BEGIN;
	lsn_t lsn1 = lm.AppendLog(r1);
	EXPECT_EQ(lsn1, 1u);

	LogRecord r2;
	r2.txn_id = 1;
	r2.type = LogRecordType::UPDATE;
	r2.page_id = 0;
	r2.offset = 0;
	r2.length = 4;
	r2.before_image = {0, 0, 0, 0};
	r2.after_image = {1, 2, 3, 4};
	lsn_t lsn2 = lm.AppendLog(r2);
	EXPECT_EQ(lsn2, 2u);
	EXPECT_EQ(r2.prev_lsn, lsn1);

	LogRecord r3;
	r3.txn_id = 1;
	r3.type = LogRecordType::COMMIT;
	lm.AppendLog(r3);  // forces flush

	auto logs = lm.ReadAllLogs();
	ASSERT_EQ(logs.size(), 3u);
	EXPECT_EQ(logs[0].type, LogRecordType::BEGIN);
	EXPECT_EQ(logs[1].type, LogRecordType::UPDATE);
	EXPECT_EQ(logs[1].after_image, (std::vector<uint8_t>{1, 2, 3, 4}));
	EXPECT_EQ(logs[2].type, LogRecordType::COMMIT);
}

TEST_F(RecoveryTest, LogPrevLSNChain) {
	LogManager lm(log_path_);

	LogRecord r;
	r.txn_id = 1; r.type = LogRecordType::BEGIN;
	lm.AppendLog(r);  // LSN 1

	r.type = LogRecordType::UPDATE;
	r.page_id = 0; r.offset = 0; r.length = 1;
	r.before_image = {0}; r.after_image = {1};
	lm.AppendLog(r);  // LSN 2, prev=1

	r.after_image = {2};
	lm.AppendLog(r);  // LSN 3, prev=2

	r.type = LogRecordType::COMMIT;
	lm.AppendLog(r);  // LSN 4, prev=3

	auto logs = lm.ReadAllLogs();
	EXPECT_EQ(logs[0].prev_lsn, INVALID_LSN);
	EXPECT_EQ(logs[1].prev_lsn, 1u);
	EXPECT_EQ(logs[2].prev_lsn, 2u);
	EXPECT_EQ(logs[3].prev_lsn, 3u);
}

TEST_F(RecoveryTest, LogCheckpoint) {
	LogManager lm(log_path_);

	LogRecord ckpt;
	ckpt.type = LogRecordType::CHECKPOINT;
	ckpt.active_txns = {{1, 5}, {2, 8}};
	ckpt.dirty_pages = {{0, 3}, {1, 7}};
	lm.AppendLog(ckpt);

	auto logs = lm.ReadAllLogs();
	ASSERT_EQ(logs.size(), 1u);
	EXPECT_EQ(logs[0].type, LogRecordType::CHECKPOINT);
	EXPECT_EQ(logs[0].active_txns.size(), 2u);
	EXPECT_EQ(logs[0].dirty_pages.size(), 2u);
}

// ============================================================
// Recovery: Committed Transaction Survives Crash
// ============================================================

TEST_F(RecoveryTest, RedoCommittedTransaction) {
	// Phase 1: Run a transaction and commit
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		txn_id_t txn = rm.Begin();

		// Allocate and write a page
		Page* page = bm.NewPage();
		page_id_t pid = page->GetPageId();
		uint8_t before[4] = {0, 0, 0, 0};
		uint8_t after[4] = {10, 20, 30, 40};
		lsn_t lsn = rm.LogUpdate(txn, pid, 0, 4, before, after);
		std::memcpy(page->GetData(), after, 4);
		page->SetPageLSN(lsn);
		bm.UnpinPage(pid, true);

		rm.Commit(txn);
		// Simulate crash: don't flush pages to disk
		// (log is flushed because COMMIT forces it)
	}

	// Phase 2: Recovery — redo should restore the page
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		rm.Recover();

		// Verify the page has the committed data
		Page* page = bm.FetchPage(0);
		ASSERT_NE(page, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[0]), 10);
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[1]), 20);
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[2]), 30);
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[3]), 40);
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Recovery: Uncommitted Transaction is Undone
// ============================================================

TEST_F(RecoveryTest, UndoUncommittedTransaction) {
	// Phase 1: Run a transaction but DON'T commit
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		txn_id_t txn = rm.Begin();

		Page* page = bm.NewPage();
		page_id_t pid = page->GetPageId();

		// Write initial data to disk first
		uint8_t initial[4] = {0, 0, 0, 0};
		std::memcpy(page->GetData(), initial, 4);
		bm.UnpinPage(pid, true);
		bm.FlushPage(pid);

		// Now modify (this is the uncommitted change)
		page = bm.FetchPage(pid);
		uint8_t before[4] = {0, 0, 0, 0};
		uint8_t after[4] = {99, 99, 99, 99};
		lsn_t lsn = rm.LogUpdate(txn, pid, 0, 4, before, after);
		std::memcpy(page->GetData(), after, 4);
		page->SetPageLSN(lsn);
		bm.UnpinPage(pid, true);

		// Force log flush (simulate WAL protocol)
		lm.FlushLog(lsn);
		// Flush the dirty page too (worst case: dirty page on disk)
		bm.FlushPage(pid);

		// Crash! No commit.
	}

	// Phase 2: Recovery — undo should restore original data
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		rm.Recover();

		Page* page = bm.FetchPage(0);
		ASSERT_NE(page, nullptr);
		// Should be back to zeros (the before_image)
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[0]), 0);
		EXPECT_EQ(static_cast<uint8_t>(page->GetData()[1]), 0);
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Recovery: Multiple Transactions — Mixed Commit/Abort
// ============================================================

TEST_F(RecoveryTest, MixedCommitAndUncommitted) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		// Allocate 2 pages
		Page* p0 = bm.NewPage(); page_id_t pid0 = p0->GetPageId();
		Page* p1 = bm.NewPage(); page_id_t pid1 = p1->GetPageId();
		bm.UnpinPage(pid0, false);
		bm.UnpinPage(pid1, false);

		// Txn 1: committed — writes to page 0
		txn_id_t txn1 = rm.Begin();
		p0 = bm.FetchPage(pid0);
		uint8_t b1[4] = {0, 0, 0, 0}, a1[4] = {11, 22, 33, 44};
		lsn_t lsn1 = rm.LogUpdate(txn1, pid0, 0, 4, b1, a1);
		std::memcpy(p0->GetData(), a1, 4);
		p0->SetPageLSN(lsn1);
		bm.UnpinPage(pid0, true);
		rm.Commit(txn1);

		// Txn 2: NOT committed — writes to page 1
		txn_id_t txn2 = rm.Begin();
		p1 = bm.FetchPage(pid1);
		uint8_t b2[4] = {0, 0, 0, 0}, a2[4] = {55, 66, 77, 88};
		lsn_t lsn2 = rm.LogUpdate(txn2, pid1, 0, 4, b2, a2);
		std::memcpy(p1->GetData(), a2, 4);
		p1->SetPageLSN(lsn2);
		bm.UnpinPage(pid1, true);

		lm.FlushLog(lsn2);
		bm.FlushPage(pid0);
		bm.FlushPage(pid1);
		// Crash — txn2 not committed
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		rm.Recover();

		// Page 0: committed data should survive
		Page* p0 = bm.FetchPage(0);
		ASSERT_NE(p0, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p0->GetData()[0]), 11);
		EXPECT_EQ(static_cast<uint8_t>(p0->GetData()[3]), 44);
		bm.UnpinPage(0, false);

		// Page 1: uncommitted data should be undone (back to zeros)
		Page* p1 = bm.FetchPage(1);
		ASSERT_NE(p1, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p1->GetData()[0]), 0);
		EXPECT_EQ(static_cast<uint8_t>(p1->GetData()[3]), 0);
		bm.UnpinPage(1, false);
	}
}

// ============================================================
// Recovery: Checkpoint + Recovery
// ============================================================

TEST_F(RecoveryTest, CheckpointAndRecover) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		// Txn 1: committed before checkpoint
		txn_id_t txn1 = rm.Begin();
		Page* p = bm.NewPage();
		uint8_t b[2] = {0, 0}, a[2] = {1, 2};
		lsn_t l = rm.LogUpdate(txn1, p->GetPageId(), 0, 2, b, a);
		std::memcpy(p->GetData(), a, 2);
		p->SetPageLSN(l);
		bm.UnpinPage(p->GetPageId(), true);
		rm.Commit(txn1);

		// Checkpoint
		rm.Checkpoint();

		// Txn 2: committed after checkpoint
		txn_id_t txn2 = rm.Begin();
		Page* p2 = bm.NewPage();
		uint8_t b2[2] = {0, 0}, a2[2] = {3, 4};
		lsn_t l2 = rm.LogUpdate(txn2, p2->GetPageId(), 0, 2, b2, a2);
		std::memcpy(p2->GetData(), a2, 2);
		p2->SetPageLSN(l2);
		bm.UnpinPage(p2->GetPageId(), true);
		rm.Commit(txn2);

		// Don't flush pages — simulate crash
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		rm.Recover();

		Page* p0 = bm.FetchPage(0);
		ASSERT_NE(p0, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p0->GetData()[0]), 1);
		bm.UnpinPage(0, false);

		Page* p1 = bm.FetchPage(1);
		ASSERT_NE(p1, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p1->GetData()[0]), 3);
		bm.UnpinPage(1, false);
	}
}

// ============================================================
// Recovery: Explicit Abort
// ============================================================

TEST_F(RecoveryTest, ExplicitAbort) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 16);
	LogManager lm(log_path_);
	RecoveryManager rm(&lm, &bm, &dm);

	Page* p = bm.NewPage();
	page_id_t pid = p->GetPageId();
	// Write initial value
	p->GetData()[0] = 42;
	bm.UnpinPage(pid, true);
	bm.FlushPage(pid);

	// Start txn, modify, then abort
	txn_id_t txn = rm.Begin();
	p = bm.FetchPage(pid);
	uint8_t before[1] = {42}, after[1] = {99};
	lsn_t lsn = rm.LogUpdate(txn, pid, 0, 1, before, after);
	p->GetData()[0] = 99;
	p->SetPageLSN(lsn);
	bm.UnpinPage(pid, true);

	rm.Abort(txn);

	// Value should be restored to 42
	p = bm.FetchPage(pid);
	EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 42);
	bm.UnpinPage(pid, false);
}

// ============================================================
// Recovery: Multiple Updates Same Page
// ============================================================

// ============================================================
// Empty / No-op Recovery
// ============================================================

TEST_F(RecoveryTest, RecoverEmptyLog) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 16);
	LogManager lm(log_path_);
	RecoveryManager rm(&lm, &bm, &dm);
	// Should be a no-op, no crash
	rm.Recover();
}

// ============================================================
// Abort Mid-Transaction, Then Crash, Then Recover
// ============================================================

TEST_F(RecoveryTest, AbortThenCrashThenRecover) {
	// Phase 1: txn1 modifies page, aborts explicitly, then system crashes
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		// Initial page with known data
		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();
		p->GetData()[0] = 42;
		bm.UnpinPage(pid, true);
		bm.FlushPage(pid);

		// Txn1: modify then abort
		txn_id_t txn1 = rm.Begin();
		p = bm.FetchPage(pid);
		uint8_t b[1] = {42}, a[1] = {99};
		lsn_t l = rm.LogUpdate(txn1, pid, 0, 1, b, a);
		p->GetData()[0] = 99;
		p->SetPageLSN(l);
		bm.UnpinPage(pid, true);

		rm.Abort(txn1);  // undo → writes CLR, restores to 42

		// Txn2: committed change after the abort
		txn_id_t txn2 = rm.Begin();
		p = bm.FetchPage(pid);
		uint8_t b2[1] = {42}, a2[1] = {77};
		lsn_t l2 = rm.LogUpdate(txn2, pid, 0, 1, b2, a2);
		p->GetData()[0] = 77;
		p->SetPageLSN(l2);
		bm.UnpinPage(pid, true);
		rm.Commit(txn2);

		// Crash! Pages not flushed to disk.
	}

	// Phase 2: Recovery
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		// txn1 aborted (42→99 undone), txn2 committed (42→77), so should be 77
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 77);
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Idempotent Recovery: Recover twice → same result
// ============================================================

TEST_F(RecoveryTest, RecoverTwiceIsIdempotent) {
	// Phase 1: committed txn, crash without flushing pages
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		txn_id_t txn = rm.Begin();
		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();
		uint8_t b[4] = {0, 0, 0, 0}, a[4] = {1, 2, 3, 4};
		lsn_t l = rm.LogUpdate(txn, pid, 0, 4, b, a);
		std::memcpy(p->GetData(), a, 4);
		p->SetPageLSN(l);
		bm.UnpinPage(pid, true);
		rm.Commit(txn);
	}

	// Phase 2: First recovery
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 1);
		bm.UnpinPage(0, false);
		// Flush so pages are on disk
		bm.FlushPage(0);
	}

	// Phase 3: Second recovery (simulating crash during first recovery)
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		// Same result as first recovery
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 1);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[1]), 2);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[2]), 3);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[3]), 4);
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Interleaved Multi-Txn: some committed, some not
// ============================================================

TEST_F(RecoveryTest, InterleavedThreeTransactions) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		// Allocate 3 pages
		for (int i = 0; i < 3; ++i) {
			Page* p = bm.NewPage();
			bm.UnpinPage(p->GetPageId(), false);
		}

		// T1: committed, writes page 0
		txn_id_t t1 = rm.Begin();
		// T2: uncommitted, writes page 1
		txn_id_t t2 = rm.Begin();
		// T3: committed, writes page 2
		txn_id_t t3 = rm.Begin();

		// Interleaved writes
		{
			Page* p = bm.FetchPage(0);
			uint8_t b[1] = {0}, a[1] = {11};
			lsn_t l = rm.LogUpdate(t1, 0, 0, 1, b, a);
			p->GetData()[0] = 11; p->SetPageLSN(l);
			bm.UnpinPage(0, true);
		}
		{
			Page* p = bm.FetchPage(1);
			uint8_t b[1] = {0}, a[1] = {22};
			lsn_t l = rm.LogUpdate(t2, 1, 0, 1, b, a);
			p->GetData()[0] = 22; p->SetPageLSN(l);
			bm.UnpinPage(1, true);
		}
		{
			Page* p = bm.FetchPage(2);
			uint8_t b[1] = {0}, a[1] = {33};
			lsn_t l = rm.LogUpdate(t3, 2, 0, 1, b, a);
			p->GetData()[0] = 33; p->SetPageLSN(l);
			bm.UnpinPage(2, true);
		}

		// T2 does another write to page 1
		{
			Page* p = bm.FetchPage(1);
			uint8_t b[1] = {22}, a[1] = {55};
			lsn_t l = rm.LogUpdate(t2, 1, 0, 1, b, a);
			p->GetData()[0] = 55; p->SetPageLSN(l);
			bm.UnpinPage(1, true);
		}

		rm.Commit(t1);
		rm.Commit(t3);
		// T2 NOT committed

		// Flush all pages and log
		lm.FlushLog(lm.GetNextLSN() - 1);
		bm.FlushPage(0);
		bm.FlushPage(1);
		bm.FlushPage(2);
		// Crash!
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p0 = bm.FetchPage(0);
		EXPECT_EQ(static_cast<uint8_t>(p0->GetData()[0]), 11);  // T1 committed
		bm.UnpinPage(0, false);

		Page* p1 = bm.FetchPage(1);
		EXPECT_EQ(static_cast<uint8_t>(p1->GetData()[0]), 0);   // T2 undone (back to 0)
		bm.UnpinPage(1, false);

		Page* p2 = bm.FetchPage(2);
		EXPECT_EQ(static_cast<uint8_t>(p2->GetData()[0]), 33);  // T3 committed
		bm.UnpinPage(2, false);
	}
}

// ============================================================
// Same page modified by multiple txns
// ============================================================

TEST_F(RecoveryTest, SamePageMultipleTxns) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();
		bm.UnpinPage(pid, false);

		// T1 committed: writes byte 0
		txn_id_t t1 = rm.Begin();
		p = bm.FetchPage(pid);
		uint8_t b1[1] = {0}, a1[1] = {10};
		lsn_t l1 = rm.LogUpdate(t1, pid, 0, 1, b1, a1);
		p->GetData()[0] = 10; p->SetPageLSN(l1);
		bm.UnpinPage(pid, true);
		rm.Commit(t1);

		// T2 uncommitted: writes byte 1
		txn_id_t t2 = rm.Begin();
		p = bm.FetchPage(pid);
		uint8_t b2[1] = {0}, a2[1] = {20};
		lsn_t l2 = rm.LogUpdate(t2, pid, 1, 1, b2, a2);
		p->GetData()[1] = 20; p->SetPageLSN(l2);
		bm.UnpinPage(pid, true);

		// T3 committed: writes byte 2
		txn_id_t t3 = rm.Begin();
		p = bm.FetchPage(pid);
		uint8_t b3[1] = {0}, a3[1] = {30};
		lsn_t l3 = rm.LogUpdate(t3, pid, 2, 1, b3, a3);
		p->GetData()[2] = 30; p->SetPageLSN(l3);
		bm.UnpinPage(pid, true);
		rm.Commit(t3);

		// Crash, all flushed
		lm.FlushLog(lm.GetNextLSN() - 1);
		bm.FlushPage(pid);
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 10);  // T1 committed
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[1]), 0);   // T2 undone
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[2]), 30);  // T3 committed
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Long txn chain (10+ updates)
// ============================================================

TEST_F(RecoveryTest, LongTxnChainUndo) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();
		bm.UnpinPage(pid, false);

		// Uncommitted txn with 15 sequential updates to different offsets
		txn_id_t txn = rm.Begin();
		for (int i = 0; i < 15; ++i) {
			p = bm.FetchPage(pid);
			uint8_t b[1] = {0}, a[1] = {static_cast<uint8_t>(i + 1)};
			if (i > 0) b[0] = 0;  // each writes to different offset
			lsn_t l = rm.LogUpdate(txn, pid, static_cast<uint16_t>(i), 1, b, a);
			p->GetData()[i] = static_cast<char>(i + 1);
			p->SetPageLSN(l);
			bm.UnpinPage(pid, true);
		}

		// NOT committed — crash with everything flushed
		lm.FlushLog(lm.GetNextLSN() - 1);
		bm.FlushPage(pid);
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		// All 15 updates should be undone (back to 0)
		for (int i = 0; i < 15; ++i) {
			EXPECT_EQ(static_cast<uint8_t>(p->GetData()[i]), 0)
				<< "Byte " << i << " not undone";
		}
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Partial flush: some pages flushed, some not
// ============================================================

TEST_F(RecoveryTest, PartialPageFlush) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		Page* p0 = bm.NewPage(); page_id_t pid0 = p0->GetPageId();
		Page* p1 = bm.NewPage(); page_id_t pid1 = p1->GetPageId();
		bm.UnpinPage(pid0, false);
		bm.UnpinPage(pid1, false);

		txn_id_t txn = rm.Begin();

		// Write to page 0
		{
			Page* p = bm.FetchPage(pid0);
			uint8_t b[1] = {0}, a[1] = {10};
			lsn_t l = rm.LogUpdate(txn, pid0, 0, 1, b, a);
			p->GetData()[0] = 10; p->SetPageLSN(l);
			bm.UnpinPage(pid0, true);
		}
		// Write to page 1
		{
			Page* p = bm.FetchPage(pid1);
			uint8_t b[1] = {0}, a[1] = {20};
			lsn_t l = rm.LogUpdate(txn, pid1, 0, 1, b, a);
			p->GetData()[0] = 20; p->SetPageLSN(l);
			bm.UnpinPage(pid1, true);
		}

		rm.Commit(txn);

		// Only flush page 0, page 1 stays dirty in buffer (lost on crash)
		bm.FlushPage(pid0);
		// Page 1 NOT flushed — redo must restore it
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p0 = bm.FetchPage(0);
		EXPECT_EQ(static_cast<uint8_t>(p0->GetData()[0]), 10);  // was flushed
		bm.UnpinPage(0, false);

		Page* p1 = bm.FetchPage(1);
		EXPECT_EQ(static_cast<uint8_t>(p1->GetData()[0]), 20);  // redo'd
		bm.UnpinPage(1, false);
	}
}

// ============================================================
// Checkpoint between commits
// ============================================================

TEST_F(RecoveryTest, CheckpointBetweenActiveTransactions) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();
		bm.UnpinPage(pid, false);

		// T1 begins, writes, does NOT commit yet
		txn_id_t t1 = rm.Begin();
		{
			Page* pp = bm.FetchPage(pid);
			uint8_t b[1] = {0}, a[1] = {11};
			lsn_t l = rm.LogUpdate(t1, pid, 0, 1, b, a);
			pp->GetData()[0] = 11; pp->SetPageLSN(l);
			bm.UnpinPage(pid, true);
		}

		// Checkpoint while T1 is active
		rm.Checkpoint();

		// T1 does more work after checkpoint
		{
			Page* pp = bm.FetchPage(pid);
			uint8_t b[1] = {11}, a[1] = {22};
			lsn_t l = rm.LogUpdate(t1, pid, 0, 1, b, a);
			pp->GetData()[0] = 22; pp->SetPageLSN(l);
			bm.UnpinPage(pid, true);
		}

		// T1 still NOT committed — crash
		lm.FlushLog(lm.GetNextLSN() - 1);
		bm.FlushPage(pid);
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		// T1 was active at checkpoint and never committed → full undo
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 0);
		bm.UnpinPage(0, false);
	}
}

// ============================================================
// Original test (kept for backward compat)
// ============================================================

TEST_F(RecoveryTest, MultipleUpdatesSamePage) {
	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);

		txn_id_t txn = rm.Begin();
		Page* p = bm.NewPage();
		page_id_t pid = p->GetPageId();

		// Update 1: byte 0
		uint8_t b1[1] = {0}, a1[1] = {10};
		lsn_t l1 = rm.LogUpdate(txn, pid, 0, 1, b1, a1);
		p->GetData()[0] = 10;
		p->SetPageLSN(l1);

		// Update 2: byte 1
		uint8_t b2[1] = {0}, a2[1] = {20};
		lsn_t l2 = rm.LogUpdate(txn, pid, 1, 1, b2, a2);
		p->GetData()[1] = 20;
		p->SetPageLSN(l2);

		// Update 3: byte 2
		uint8_t b3[1] = {0}, a3[1] = {30};
		lsn_t l3 = rm.LogUpdate(txn, pid, 2, 1, b3, a3);
		p->GetData()[2] = 30;
		p->SetPageLSN(l3);

		bm.UnpinPage(pid, true);
		rm.Commit(txn);
	}

	{
		DiskManager dm(db_path_);
		BufferManager bm(&dm, 16);
		LogManager lm(log_path_);
		RecoveryManager rm(&lm, &bm, &dm);
		rm.Recover();

		Page* p = bm.FetchPage(0);
		ASSERT_NE(p, nullptr);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[0]), 10);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[1]), 20);
		EXPECT_EQ(static_cast<uint8_t>(p->GetData()[2]), 30);
		bm.UnpinPage(0, false);
	}
}
