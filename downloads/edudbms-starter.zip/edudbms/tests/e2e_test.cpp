#include <gtest/gtest.h>

#include <filesystem>

#include "engine/engine.h"

using namespace minidb;

class E2ETest : public ::testing::Test {
protected:
	std::string db_path_ = "test_e2e.db";

	void TearDown() override {
		std::filesystem::remove(db_path_);
	}
};

TEST_F(E2ETest, CreateInsertSelectRoundtrip) {
	Engine engine(db_path_);
	engine.CreateTable("users", Schema({
		Column("id", DataType::INTEGER),
		Column("name", DataType::STRING),
	}));

	Row r1; r1["id"] = Value(1); r1["name"] = Value(std::string("Alice"));
	Row r2; r2["id"] = Value(2); r2["name"] = Value(std::string("Bob"));
	engine.Insert("users", r1);
	engine.Insert("users", r2);

	auto results = engine.Execute("SELECT * FROM users");
	ASSERT_EQ(results.size(), 2u);
}

TEST_F(E2ETest, SelectWithWhereFilter) {
	Engine engine(db_path_);
	engine.CreateTable("items", Schema({
		Column("id", DataType::INTEGER),
		Column("price", DataType::FLOAT),
	}));

	for (int i = 1; i <= 5; ++i) {
		Row r;
		r["id"] = Value(i);
		r["price"] = Value(static_cast<double>(i * 100));
		engine.Insert("items", r);
	}

	auto results = engine.Execute("SELECT * FROM items WHERE price > 300.0");
	EXPECT_EQ(results.size(), 2u);  // price 400 and 500
}

TEST_F(E2ETest, JoinTwoTables) {
	Engine engine(db_path_);
	engine.CreateTable("users", Schema({
		Column("id", DataType::INTEGER),
		Column("name", DataType::STRING),
	}));
	engine.CreateTable("orders", Schema({
		Column("id", DataType::INTEGER),
		Column("user_id", DataType::INTEGER),
		Column("amount", DataType::FLOAT),
	}));

	Row u1; u1["id"] = Value(1); u1["name"] = Value(std::string("Alice"));
	Row u2; u2["id"] = Value(2); u2["name"] = Value(std::string("Bob"));
	engine.Insert("users", u1);
	engine.Insert("users", u2);

	Row o1; o1["id"] = Value(1); o1["user_id"] = Value(1); o1["amount"] = Value(100.0);
	Row o2; o2["id"] = Value(2); o2["user_id"] = Value(1); o2["amount"] = Value(200.0);
	Row o3; o3["id"] = Value(3); o3["user_id"] = Value(2); o3["amount"] = Value(50.0);
	engine.Insert("orders", o1);
	engine.Insert("orders", o2);
	engine.Insert("orders", o3);

	auto results = engine.Execute(
		"SELECT * FROM users JOIN orders ON users.id = orders.user_id");
	EXPECT_EQ(results.size(), 3u);
}

TEST_F(E2ETest, OrderBy) {
	Engine engine(db_path_);
	engine.CreateTable("nums", Schema({
		Column("val", DataType::INTEGER),
	}));

	for (int v : {3, 1, 4, 1, 5}) {
		Row r; r["val"] = Value(v);
		engine.Insert("nums", r);
	}

	auto results = engine.Execute("SELECT * FROM nums ORDER BY val");
	ASSERT_EQ(results.size(), 5u);
	EXPECT_EQ(results[0].at("val").AsInt(), 1);
	EXPECT_EQ(results[4].at("val").AsInt(), 5);
}

TEST_F(E2ETest, GroupByWithCount) {
	Engine engine(db_path_);
	engine.CreateTable("employees", Schema({
		Column("dept", DataType::STRING),
		Column("name", DataType::STRING),
	}));

	Row e1; e1["dept"] = Value(std::string("eng")); e1["name"] = Value(std::string("A"));
	Row e2; e2["dept"] = Value(std::string("eng")); e2["name"] = Value(std::string("B"));
	Row e3; e3["dept"] = Value(std::string("sales")); e3["name"] = Value(std::string("C"));
	engine.Insert("employees", e1);
	engine.Insert("employees", e2);
	engine.Insert("employees", e3);

	auto results = engine.Execute(
		"SELECT dept, COUNT(*) FROM employees GROUP BY dept");
	ASSERT_EQ(results.size(), 2u);
}

TEST_F(E2ETest, GroupByWithSum) {
	Engine engine(db_path_);
	engine.CreateTable("sales", Schema({
		Column("region", DataType::STRING),
		Column("amount", DataType::FLOAT),
	}));

	Row s1; s1["region"] = Value(std::string("east")); s1["amount"] = Value(100.0);
	Row s2; s2["region"] = Value(std::string("east")); s2["amount"] = Value(200.0);
	Row s3; s3["region"] = Value(std::string("west")); s3["amount"] = Value(50.0);
	engine.Insert("sales", s1);
	engine.Insert("sales", s2);
	engine.Insert("sales", s3);

	auto results = engine.Execute(
		"SELECT region, SUM(amount) FROM sales GROUP BY region");
	ASSERT_EQ(results.size(), 2u);

	for (const auto& row : results) {
		if (row.at("region").AsString() == "east") {
			// Find the SUM output column (name depends on AggregateExpr::ToString())
			bool found = false;
			for (const auto& [k, v] : row) {
				if (k.find("SUM") != std::string::npos) {
					EXPECT_DOUBLE_EQ(v.AsFloat(), 300.0);
					found = true;
				}
			}
			EXPECT_TRUE(found) << "SUM aggregate column not found in result";
		}
	}
}

TEST_F(E2ETest, Explain) {
	Engine engine(db_path_);
	engine.CreateTable("t", Schema({Column("x", DataType::INTEGER)}));

	auto plan_str = engine.Explain("SELECT * FROM t ORDER BY x");
	EXPECT_FALSE(plan_str.empty());
	EXPECT_NE(plan_str.find("Sort"), std::string::npos);
}
