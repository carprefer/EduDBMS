#include <gtest/gtest.h>

#include <cstring>
#include <filesystem>
#include <string>

#include "buffer/buffer_manager.h"
#include "buffer/replacer.h"
#include "common/config.h"
#include "disk/disk_manager.h"

using namespace minidb;

// Helper: create a temporary db file path and clean up after test
class DiskManagerTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_disk_manager.db";

	void TearDown() override {
		std::filesystem::remove(db_path_);
	}
};

class BufferManagerTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_buffer_manager.db";

	void TearDown() override {
		std::filesystem::remove(db_path_);
	}
};

// ============================================================
// DiskManager Tests
// ============================================================

TEST_F(DiskManagerTest, AllocatePages) {
	DiskManager dm(db_path_);
	EXPECT_EQ(dm.AllocatePage(), 0u);
	EXPECT_EQ(dm.AllocatePage(), 1u);
	EXPECT_EQ(dm.AllocatePage(), 2u);
	EXPECT_EQ(dm.GetNumPages(), 3u);
}

TEST_F(DiskManagerTest, WriteAndReadPage) {
	DiskManager dm(db_path_);
	page_id_t pid = dm.AllocatePage();

	// Write a page with known pattern
	char write_buf[DB_PAGE_SIZE];
	std::memset(write_buf, 0, DB_PAGE_SIZE);
	std::string msg = "Hello, DiskManager!";
	std::memcpy(write_buf, msg.c_str(), msg.size());
	dm.WritePage(pid, write_buf);

	// Read it back
	char read_buf[DB_PAGE_SIZE];
	dm.ReadPage(pid, read_buf);
	EXPECT_EQ(std::memcmp(write_buf, read_buf, DB_PAGE_SIZE), 0);
}

TEST_F(DiskManagerTest, ReadBeyondAllocated) {
	DiskManager dm(db_path_);
	// Reading a page that was never allocated should zero-fill
	char read_buf[DB_PAGE_SIZE];
	std::memset(read_buf, 0xFF, DB_PAGE_SIZE);
	dm.ReadPage(999, read_buf);

	char zero_buf[DB_PAGE_SIZE];
	std::memset(zero_buf, 0, DB_PAGE_SIZE);
	EXPECT_EQ(std::memcmp(read_buf, zero_buf, DB_PAGE_SIZE), 0);
}

TEST_F(DiskManagerTest, WriteMultiplePages) {
	DiskManager dm(db_path_);

	for (int i = 0; i < 5; ++i) {
		page_id_t pid = dm.AllocatePage();
		char buf[DB_PAGE_SIZE];
		std::memset(buf, 0, DB_PAGE_SIZE);
		buf[0] = static_cast<char>(i + 1);
		dm.WritePage(pid, buf);
	}

	// Read back and verify each page
	for (int i = 0; i < 5; ++i) {
		char buf[DB_PAGE_SIZE];
		dm.ReadPage(static_cast<page_id_t>(i), buf);
		EXPECT_EQ(buf[0], static_cast<char>(i + 1));
	}
}

TEST_F(DiskManagerTest, PersistenceAcrossInstances) {
	// Write with one DiskManager
	{
		DiskManager dm(db_path_);
		page_id_t pid = dm.AllocatePage();
		char buf[DB_PAGE_SIZE];
		std::memset(buf, 0, DB_PAGE_SIZE);
		buf[0] = 42;
		dm.WritePage(pid, buf);
	}

	// Read with a new DiskManager instance
	{
		DiskManager dm(db_path_);
		EXPECT_EQ(dm.GetNumPages(), 1u);
		char buf[DB_PAGE_SIZE];
		dm.ReadPage(0, buf);
		EXPECT_EQ(buf[0], 42);
	}
}

// ============================================================
// LRUReplacer Tests
// ============================================================

TEST(LRUReplacerTest, BasicVictim) {
	LRUReplacer replacer(3);
	replacer.Unpin(0);
	replacer.Unpin(1);
	replacer.Unpin(2);

	frame_id_t victim;
	EXPECT_TRUE(replacer.Victim(&victim));
	EXPECT_EQ(victim, 0u);  // LRU = first unpinned
	EXPECT_TRUE(replacer.Victim(&victim));
	EXPECT_EQ(victim, 1u);
}

TEST(LRUReplacerTest, EmptyVictim) {
	LRUReplacer replacer(3);
	frame_id_t victim;
	EXPECT_FALSE(replacer.Victim(&victim));
}

TEST(LRUReplacerTest, PinRemovesFromReplacer) {
	LRUReplacer replacer(3);
	replacer.Unpin(0);
	replacer.Unpin(1);
	replacer.Unpin(2);

	// Pin frame 1 — it should be skipped during victim selection
	replacer.Pin(1);
	EXPECT_EQ(replacer.Size(), 2u);

	frame_id_t victim;
	EXPECT_TRUE(replacer.Victim(&victim));
	EXPECT_EQ(victim, 0u);
	EXPECT_TRUE(replacer.Victim(&victim));
	EXPECT_EQ(victim, 2u);  // frame 1 was pinned, so skipped
	EXPECT_FALSE(replacer.Victim(&victim));
}

TEST(LRUReplacerTest, UnpinIdempotent) {
	LRUReplacer replacer(3);
	replacer.Unpin(0);
	replacer.Unpin(0);  // should not add twice
	EXPECT_EQ(replacer.Size(), 1u);
}

TEST(LRUReplacerTest, PinNonExistent) {
	LRUReplacer replacer(3);
	// Pinning a frame not in the replacer should be a no-op
	replacer.Pin(99);
	EXPECT_EQ(replacer.Size(), 0u);
}

// ============================================================
// BufferManager Tests
// ============================================================

TEST_F(BufferManagerTest, NewPageAndFetch) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 4);

	Page* page = bm.NewPage();
	ASSERT_NE(page, nullptr);
	page_id_t pid = page->GetPageId();
	EXPECT_EQ(pid, 0u);
	EXPECT_EQ(page->GetPinCount(), 1);

	// Write data
	std::memcpy(page->GetData(), "test", 4);
	bm.UnpinPage(pid, true);

	// Fetch it back
	Page* fetched = bm.FetchPage(pid);
	ASSERT_NE(fetched, nullptr);
	EXPECT_EQ(std::memcmp(fetched->GetData(), "test", 4), 0);
	bm.UnpinPage(pid, false);
}

TEST_F(BufferManagerTest, CacheHitReturnsSamePage) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 4);

	Page* p1 = bm.NewPage();
	ASSERT_NE(p1, nullptr);
	page_id_t pid = p1->GetPageId();
	bm.UnpinPage(pid, false);

	Page* p2 = bm.FetchPage(pid);
	EXPECT_EQ(p1, p2);  // same frame, same pointer
	bm.UnpinPage(pid, false);
}

TEST_F(BufferManagerTest, EvictionOnFullPool) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 2);  // only 2 frames

	Page* p0 = bm.NewPage();  // frame 0
	Page* p1 = bm.NewPage();  // frame 1
	ASSERT_NE(p0, nullptr);
	ASSERT_NE(p1, nullptr);

	page_id_t pid0 = p0->GetPageId();
	page_id_t pid1 = p1->GetPageId();

	// Unpin both — they become evictable
	bm.UnpinPage(pid0, false);
	bm.UnpinPage(pid1, false);

	// Allocate a third page — should evict p0 (LRU)
	Page* p2 = bm.NewPage();
	ASSERT_NE(p2, nullptr);
	EXPECT_EQ(p2->GetPageId(), 2u);
	bm.UnpinPage(p2->GetPageId(), false);
}

TEST_F(BufferManagerTest, AllPinnedReturnsNull) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 2);

	Page* p0 = bm.NewPage();
	Page* p1 = bm.NewPage();
	ASSERT_NE(p0, nullptr);
	ASSERT_NE(p1, nullptr);
	// Both pinned (pin_count = 1), no free frames

	Page* p2 = bm.NewPage();
	EXPECT_EQ(p2, nullptr);  // should fail

	bm.UnpinPage(p0->GetPageId(), false);
	bm.UnpinPage(p1->GetPageId(), false);
}

TEST_F(BufferManagerTest, DirtyPageFlushedOnEviction) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 1);  // single frame

	// Create page 0, write data, mark dirty, unpin
	Page* p0 = bm.NewPage();
	ASSERT_NE(p0, nullptr);
	page_id_t pid0 = p0->GetPageId();
	std::memcpy(p0->GetData(), "dirty_data", 10);
	bm.UnpinPage(pid0, true);

	// Create page 1 — this evicts page 0 (dirty flush)
	Page* p1 = bm.NewPage();
	ASSERT_NE(p1, nullptr);
	bm.UnpinPage(p1->GetPageId(), false);

	// Fetch page 0 back — it should have been flushed to disk
	Page* p0_again = bm.FetchPage(pid0);
	ASSERT_NE(p0_again, nullptr);
	EXPECT_EQ(std::memcmp(p0_again->GetData(), "dirty_data", 10), 0);
	bm.UnpinPage(pid0, false);
}

TEST_F(BufferManagerTest, FlushPage) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 4);

	Page* page = bm.NewPage();
	ASSERT_NE(page, nullptr);
	page_id_t pid = page->GetPageId();
	std::memcpy(page->GetData(), "flush_me", 8);
	page->SetDirty(true);

	EXPECT_TRUE(bm.FlushPage(pid));
	EXPECT_FALSE(page->IsDirty());  // dirty flag cleared after flush

	bm.UnpinPage(pid, false);
}

TEST_F(BufferManagerTest, UnpinAlreadyUnpinned) {
	DiskManager dm(db_path_);
	BufferManager bm(&dm, 4);

	Page* page = bm.NewPage();
	ASSERT_NE(page, nullptr);
	page_id_t pid = page->GetPageId();

	EXPECT_TRUE(bm.UnpinPage(pid, false));   // pin_count 1 -> 0
	EXPECT_FALSE(bm.UnpinPage(pid, false));  // already 0
}
