#include <gtest/gtest.h>

#include <algorithm>
#include <filesystem>
#include <numeric>
#include <random>
#include <vector>

#include "buffer/buffer_manager.h"
#include "common/config.h"
#include "disk/disk_manager.h"
#include "index/bptree.h"

using namespace minidb;

class BPTreeTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_bptree.db";
	DiskManager* dm_;
	BufferManager* bm_;

	void SetUp() override {
		dm_ = new DiskManager(db_path_);
		bm_ = new BufferManager(dm_, 64);  // larger pool for tree operations
	}

	void TearDown() override {
		delete bm_;
		delete dm_;
		std::filesystem::remove(db_path_);
	}

	// Helper: create a fresh B+-Tree with an empty root leaf
	BPTree CreateTree() {
		Page* root_page = bm_->NewPage();
		page_id_t root_pid = root_page->GetPageId();

		// Initialize as empty leaf
		BPTreeNode root;
		root.is_leaf = true;
		BPTree::SerializeNode(root_page->GetData(), root);
		bm_->UnpinPage(root_pid, true);

		return BPTree(bm_, root_pid);
	}
};

// ============================================================
// Search Tests
// ============================================================

TEST_F(BPTreeTest, SearchEmptyTree) {
	BPTree tree = CreateTree();
	EXPECT_EQ(tree.Search(42), std::nullopt);
}

TEST_F(BPTreeTest, InsertAndSearchSingle) {
	BPTree tree = CreateTree();
	tree.Insert(10, 100);

	auto result = tree.Search(10);
	ASSERT_TRUE(result.has_value());
	EXPECT_EQ(result.value(), 100u);
}

TEST_F(BPTreeTest, SearchNonExistentKey) {
	BPTree tree = CreateTree();
	tree.Insert(10, 100);
	tree.Insert(20, 200);

	EXPECT_EQ(tree.Search(15), std::nullopt);
}

// ============================================================
// Insert Tests
// ============================================================

TEST_F(BPTreeTest, InsertMultipleInOrder) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 20; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i * 10));
	}

	for (int i = 1; i <= 20; ++i) {
		auto result = tree.Search(i);
		ASSERT_TRUE(result.has_value()) << "Key " << i << " not found";
		EXPECT_EQ(result.value(), static_cast<page_id_t>(i * 10));
	}
}

TEST_F(BPTreeTest, InsertReverseOrder) {
	BPTree tree = CreateTree();
	for (int i = 20; i >= 1; --i) {
		tree.Insert(i, static_cast<page_id_t>(i * 10));
	}

	for (int i = 1; i <= 20; ++i) {
		auto result = tree.Search(i);
		ASSERT_TRUE(result.has_value()) << "Key " << i << " not found";
		EXPECT_EQ(result.value(), static_cast<page_id_t>(i * 10));
	}
}

TEST_F(BPTreeTest, InsertDuplicateKeyUpdates) {
	BPTree tree = CreateTree();
	tree.Insert(10, 100);
	tree.Insert(10, 999);  // update

	auto result = tree.Search(10);
	ASSERT_TRUE(result.has_value());
	EXPECT_EQ(result.value(), 999u);
}

TEST_F(BPTreeTest, InsertTriggersLeafSplit) {
	BPTree tree = CreateTree();

	// Insert enough keys to force at least one leaf split
	// BPTREE_LEAF_MAX_KEYS is about 510, but let's use a manageable number
	// and verify the tree still works correctly
	int count = static_cast<int>(BPTREE_LEAF_MAX_KEYS + 5);
	for (int i = 1; i <= count; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	// Verify all keys are still searchable
	for (int i = 1; i <= count; ++i) {
		auto result = tree.Search(i);
		ASSERT_TRUE(result.has_value()) << "Key " << i << " not found after split";
		EXPECT_EQ(result.value(), static_cast<page_id_t>(i));
	}
}

TEST_F(BPTreeTest, LargeInsertionMultipleLeaves) {
	BPTree tree = CreateTree();

	int count = 2000;
	for (int i = 1; i <= count; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	for (int i = 1; i <= count; ++i) {
		auto result = tree.Search(i);
		ASSERT_TRUE(result.has_value()) << "Key " << i << " not found";
	}
}

TEST_F(BPTreeTest, InsertRandomOrder) {
	BPTree tree = CreateTree();

	std::vector<int> keys(500);
	std::iota(keys.begin(), keys.end(), 1);
	std::mt19937 rng(42);
	std::shuffle(keys.begin(), keys.end(), rng);

	for (int k : keys) {
		tree.Insert(k, static_cast<page_id_t>(k * 10));
	}

	for (int k : keys) {
		auto result = tree.Search(k);
		ASSERT_TRUE(result.has_value()) << "Key " << k << " not found";
		EXPECT_EQ(result.value(), static_cast<page_id_t>(k * 10));
	}
}

// ============================================================
// Range Scan Tests
// ============================================================

TEST_F(BPTreeTest, RangeScanFullRange) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 10; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i * 100));
	}

	auto results = tree.RangeScan(1, 10);
	ASSERT_EQ(results.size(), 10u);
	for (int i = 0; i < 10; ++i) {
		EXPECT_EQ(results[i].first, i + 1);
		EXPECT_EQ(results[i].second, static_cast<page_id_t>((i + 1) * 100));
	}
}

TEST_F(BPTreeTest, RangeScanPartialRange) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 20; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	auto results = tree.RangeScan(5, 15);
	ASSERT_EQ(results.size(), 11u);  // 5,6,...,15
	EXPECT_EQ(results.front().first, 5);
	EXPECT_EQ(results.back().first, 15);
}

TEST_F(BPTreeTest, RangeScanEmpty) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 10; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	auto results = tree.RangeScan(50, 100);
	EXPECT_TRUE(results.empty());
}

TEST_F(BPTreeTest, RangeScanSingleKey) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 10; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	auto results = tree.RangeScan(5, 5);
	ASSERT_EQ(results.size(), 1u);
	EXPECT_EQ(results[0].first, 5);
}

TEST_F(BPTreeTest, RangeScanAcrossLeaves) {
	BPTree tree = CreateTree();

	// Insert enough to span multiple leaves
	int count = static_cast<int>(BPTREE_LEAF_MAX_KEYS + 10);
	for (int i = 1; i <= count; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	// Scan across the leaf boundary
	auto results = tree.RangeScan(1, count);
	ASSERT_EQ(results.size(), static_cast<size_t>(count));

	// Verify order
	for (int i = 0; i < count; ++i) {
		EXPECT_EQ(results[i].first, i + 1);
	}
}

// ============================================================
// Delete Tests
// ============================================================

TEST_F(BPTreeTest, DeleteSingleKey) {
	BPTree tree = CreateTree();
	tree.Insert(10, 100);
	EXPECT_TRUE(tree.Delete(10));
	EXPECT_EQ(tree.Search(10), std::nullopt);
}

TEST_F(BPTreeTest, DeleteNonExistentKey) {
	BPTree tree = CreateTree();
	tree.Insert(10, 100);
	EXPECT_FALSE(tree.Delete(99));
	EXPECT_TRUE(tree.Search(10).has_value());
}

TEST_F(BPTreeTest, DeleteFromEmpty) {
	BPTree tree = CreateTree();
	EXPECT_FALSE(tree.Delete(42));
}

TEST_F(BPTreeTest, DeletePreservesOtherKeys) {
	BPTree tree = CreateTree();
	for (int i = 1; i <= 10; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i * 10));
	}

	EXPECT_TRUE(tree.Delete(5));
	EXPECT_EQ(tree.Search(5), std::nullopt);

	// All other keys still present
	for (int i = 1; i <= 10; ++i) {
		if (i == 5) continue;
		EXPECT_TRUE(tree.Search(i).has_value()) << "Key " << i << " missing after deleting 5";
	}
}

TEST_F(BPTreeTest, InsertDeleteInsertSameKey) {
	BPTree tree = CreateTree();
	tree.Insert(42, 100);
	EXPECT_TRUE(tree.Delete(42));
	EXPECT_EQ(tree.Search(42), std::nullopt);

	tree.Insert(42, 200);
	auto result = tree.Search(42);
	ASSERT_TRUE(result.has_value());
	EXPECT_EQ(result.value(), 200u);
}

// ============================================================
// Systematic 30+ Key Tests
// ============================================================

TEST_F(BPTreeTest, Systematic30InsertSearchDelete) {
	BPTree tree = CreateTree();
	const int N = 50;

	// Phase 1: Insert 50 keys
	for (int i = 1; i <= N; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i * 100));
	}

	// Phase 2: Verify all 50 present
	for (int i = 1; i <= N; ++i) {
		auto r = tree.Search(i);
		ASSERT_TRUE(r.has_value()) << "Key " << i << " not found after insertion";
		EXPECT_EQ(r.value(), static_cast<page_id_t>(i * 100));
	}

	// Phase 3: Delete even keys (25 deletions)
	for (int i = 2; i <= N; i += 2) {
		EXPECT_TRUE(tree.Delete(i)) << "Failed to delete key " << i;
	}

	// Phase 4: Verify even keys gone, odd keys still present
	for (int i = 1; i <= N; ++i) {
		auto r = tree.Search(i);
		if (i % 2 == 0) {
			EXPECT_FALSE(r.has_value()) << "Deleted key " << i << " still found";
		} else {
			ASSERT_TRUE(r.has_value()) << "Key " << i << " missing after deleting evens";
			EXPECT_EQ(r.value(), static_cast<page_id_t>(i * 100));
		}
	}

	// Phase 5: Range scan should return only odd keys
	auto results = tree.RangeScan(1, N);
	EXPECT_EQ(results.size(), 25u);
	for (const auto& [k, v] : results) {
		EXPECT_EQ(k % 2, 1) << "Even key " << k << " found in range scan after deletion";
	}
}

TEST_F(BPTreeTest, Systematic30RandomInsertDelete) {
	BPTree tree = CreateTree();

	// Insert 40 random keys
	std::mt19937 rng(123);
	std::vector<int> keys(40);
	std::iota(keys.begin(), keys.end(), 1);
	std::shuffle(keys.begin(), keys.end(), rng);

	for (int k : keys) {
		tree.Insert(k, static_cast<page_id_t>(k));
	}

	// Verify all present
	for (int k : keys) {
		ASSERT_TRUE(tree.Search(k).has_value()) << "Key " << k << " not found";
	}

	// Delete first 20 in random order
	std::vector<int> to_delete(keys.begin(), keys.begin() + 20);
	std::set<int> deleted_set(to_delete.begin(), to_delete.end());

	for (int k : to_delete) {
		EXPECT_TRUE(tree.Delete(k)) << "Failed to delete " << k;
	}

	// Verify deleted keys gone, remaining keys present
	for (int k : keys) {
		auto r = tree.Search(k);
		if (deleted_set.count(k)) {
			EXPECT_FALSE(r.has_value()) << "Deleted key " << k << " still found";
		} else {
			EXPECT_TRUE(r.has_value()) << "Key " << k << " missing after partial delete";
		}
	}

	// Re-insert deleted keys with new values
	for (int k : to_delete) {
		tree.Insert(k, static_cast<page_id_t>(k + 1000));
	}

	// Verify all present with correct values
	for (int k : keys) {
		auto r = tree.Search(k);
		ASSERT_TRUE(r.has_value()) << "Key " << k << " not found after re-insert";
		if (deleted_set.count(k)) {
			EXPECT_EQ(r.value(), static_cast<page_id_t>(k + 1000));
		} else {
			EXPECT_EQ(r.value(), static_cast<page_id_t>(k));
		}
	}
}

TEST_F(BPTreeTest, Systematic30DeleteAllThenReinsert) {
	BPTree tree = CreateTree();
	const int N = 35;

	// Insert all
	for (int i = 1; i <= N; ++i) tree.Insert(i, static_cast<page_id_t>(i));

	// Delete all
	for (int i = 1; i <= N; ++i) {
		EXPECT_TRUE(tree.Delete(i)) << "Failed to delete " << i;
	}

	// Verify empty
	for (int i = 1; i <= N; ++i) {
		EXPECT_FALSE(tree.Search(i).has_value()) << "Key " << i << " found after full delete";
	}
	EXPECT_TRUE(tree.RangeScan(1, N).empty());

	// Re-insert in reverse
	for (int i = N; i >= 1; --i) {
		tree.Insert(i, static_cast<page_id_t>(i * 10));
	}

	// Verify all present
	for (int i = 1; i <= N; ++i) {
		auto r = tree.Search(i);
		ASSERT_TRUE(r.has_value()) << "Key " << i << " not found after re-insert";
		EXPECT_EQ(r.value(), static_cast<page_id_t>(i * 10));
	}

	// Range scan should return all in order
	auto results = tree.RangeScan(1, N);
	ASSERT_EQ(results.size(), static_cast<size_t>(N));
	for (int i = 0; i < N; ++i) {
		EXPECT_EQ(results[i].first, i + 1);
	}
}

TEST_F(BPTreeTest, Systematic30InterleavedInsertDelete) {
	BPTree tree = CreateTree();

	// Alternating insert and delete pattern
	// Insert 1..10, delete 1..5, insert 11..20, delete 6..10, etc.
	for (int batch = 0; batch < 4; ++batch) {
		int insert_start = batch * 10 + 1;
		int insert_end = insert_start + 9;

		for (int i = insert_start; i <= insert_end; ++i) {
			tree.Insert(i, static_cast<page_id_t>(i));
		}

		if (batch > 0) {
			int del_start = (batch - 1) * 10 + 6;
			int del_end = del_start + 4;
			for (int i = del_start; i <= del_end; ++i) {
				EXPECT_TRUE(tree.Delete(i)) << "Failed to delete " << i;
			}
		}
	}

	// After 4 batches: inserted 1..40, deleted 6..10, 16..20, 26..30
	std::set<int> deleted = {};
	for (int b = 0; b < 3; ++b) {
		for (int i = b * 10 + 6; i <= b * 10 + 10; ++i) {
			deleted.insert(i);
		}
	}

	for (int i = 1; i <= 40; ++i) {
		auto r = tree.Search(i);
		if (deleted.count(i)) {
			EXPECT_FALSE(r.has_value()) << "Deleted key " << i << " found";
		} else {
			EXPECT_TRUE(r.has_value()) << "Key " << i << " missing";
		}
	}
}

TEST_F(BPTreeTest, Systematic30RangeScanAfterDelete) {
	BPTree tree = CreateTree();

	for (int i = 1; i <= 50; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	// Delete keys 10..20
	for (int i = 10; i <= 20; ++i) tree.Delete(i);

	// Range scan 5..25 should skip 10..20
	auto results = tree.RangeScan(5, 25);
	std::set<int> result_keys;
	for (const auto& [k, v] : results) result_keys.insert(k);

	for (int i = 5; i <= 25; ++i) {
		if (i >= 10 && i <= 20) {
			EXPECT_EQ(result_keys.count(i), 0u) << "Deleted key " << i << " in range scan";
		} else {
			EXPECT_EQ(result_keys.count(i), 1u) << "Key " << i << " missing from range scan";
		}
	}
}

// ============================================================
// Large Scale Tests
// ============================================================

TEST_F(BPTreeTest, LargeScaleInsertAndSearch) {
	BPTree tree = CreateTree();

	for (int i = 1; i <= 1000; ++i) {
		tree.Insert(i, static_cast<page_id_t>(i));
	}

	// Verify all
	for (int i = 1; i <= 1000; ++i) {
		auto result = tree.Search(i);
		ASSERT_TRUE(result.has_value()) << "Key " << i << " not found in 1000-key tree";
	}

	// Verify non-existent
	EXPECT_EQ(tree.Search(0), std::nullopt);
	EXPECT_EQ(tree.Search(1001), std::nullopt);
}
