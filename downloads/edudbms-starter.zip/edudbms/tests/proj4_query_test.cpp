#include <gtest/gtest.h>

#include "catalog/catalog.h"
#include "parser/parser.h"
#include "planner/planner.h"

using namespace minidb;

// ============================================================
// Parser: ORDER BY
// ============================================================

TEST(ParserOrderByTest, SimpleOrderBy) {
	Parser parser("SELECT * FROM users ORDER BY age");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasOrderBy());
	EXPECT_EQ(select->GetOrderBy().size(), 1u);
	EXPECT_TRUE(select->GetOrderBy()[0].ascending);
}

TEST(ParserOrderByTest, OrderByDesc) {
	Parser parser("SELECT * FROM users ORDER BY age DESC");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_FALSE(select->GetOrderBy()[0].ascending);
}

TEST(ParserOrderByTest, OrderByMultipleColumns) {
	Parser parser("SELECT * FROM users ORDER BY department, age DESC");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_EQ(select->GetOrderBy().size(), 2u);
	EXPECT_TRUE(select->GetOrderBy()[0].ascending);    // department ASC (default)
	EXPECT_FALSE(select->GetOrderBy()[1].ascending);   // age DESC
}

// ============================================================
// Parser: GROUP BY
// ============================================================

TEST(ParserGroupByTest, SimpleGroupBy) {
	Parser parser("SELECT department, COUNT(*) FROM employees GROUP BY department");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasGroupBy());
	EXPECT_EQ(select->GetGroupBy().size(), 1u);
}

TEST(ParserGroupByTest, GroupByMultipleColumns) {
	Parser parser("SELECT department, role, COUNT(*) FROM employees GROUP BY department, role");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_EQ(select->GetGroupBy().size(), 2u);
}

// ============================================================
// Parser: Aggregate Functions
// ============================================================

TEST(ParserAggregateTest, CountStar) {
	Parser parser("SELECT COUNT(*) FROM users");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_EQ(select->GetSelectList().size(), 1u);
	auto* agg = dynamic_cast<AggregateExpr*>(select->GetSelectList()[0].get());
	ASSERT_NE(agg, nullptr);
	EXPECT_EQ(agg->GetFunc(), AggFunc::COUNT);
	EXPECT_TRUE(agg->IsCountStar());
}

TEST(ParserAggregateTest, SumColumn) {
	Parser parser("SELECT SUM(salary) FROM employees");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	auto* agg = dynamic_cast<AggregateExpr*>(select->GetSelectList()[0].get());
	ASSERT_NE(agg, nullptr);
	EXPECT_EQ(agg->GetFunc(), AggFunc::SUM);
	EXPECT_FALSE(agg->IsCountStar());
}

TEST(ParserAggregateTest, MultipleAggregates) {
	Parser parser("SELECT AVG(salary), MIN(age), MAX(age) FROM employees");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_EQ(select->GetSelectList().size(), 3u);

	auto* avg = dynamic_cast<AggregateExpr*>(select->GetSelectList()[0].get());
	EXPECT_EQ(avg->GetFunc(), AggFunc::AVG);
	auto* min = dynamic_cast<AggregateExpr*>(select->GetSelectList()[1].get());
	EXPECT_EQ(min->GetFunc(), AggFunc::MIN);
	auto* max = dynamic_cast<AggregateExpr*>(select->GetSelectList()[2].get());
	EXPECT_EQ(max->GetFunc(), AggFunc::MAX);
}

// ============================================================
// Parser: Combined GROUP BY + ORDER BY
// ============================================================

TEST(ParserCombinedTest, GroupByAndOrderBy) {
	Parser parser("SELECT department, SUM(salary) FROM employees GROUP BY department ORDER BY department");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasGroupBy());
	EXPECT_TRUE(select->HasOrderBy());
	EXPECT_EQ(select->GetGroupBy().size(), 1u);
	EXPECT_EQ(select->GetOrderBy().size(), 1u);
}

// ============================================================
// Planner: LogicalSort
// ============================================================

TEST(PlannerSortTest, OrderByCreatesLogicalSort) {
	Catalog catalog;
	catalog.CreateTable("users", Schema({Column("id", DataType::INTEGER), Column("age", DataType::INTEGER)}));
	Planner planner(catalog);

	Parser parser("SELECT * FROM users ORDER BY age");
	auto stmt = parser.Parse();
	auto plan = planner.Plan(*stmt);

	// Plan tree: Project -> Sort -> Scan
	auto* project = dynamic_cast<LogicalProject*>(plan.get());
	ASSERT_NE(project, nullptr);
	auto* sort = dynamic_cast<LogicalSort*>(project->GetChild());
	ASSERT_NE(sort, nullptr);
	EXPECT_EQ(sort->GetSortKeys().size(), 1u);
	EXPECT_TRUE(sort->GetAscending()[0]);
}

// ============================================================
// Planner: LogicalAggregate
// ============================================================

TEST(PlannerAggregateTest, GroupByCreatesLogicalAggregate) {
	Catalog catalog;
	catalog.CreateTable("employees", Schema({
		Column("department", DataType::STRING),
		Column("salary", DataType::FLOAT),
	}));
	Planner planner(catalog);

	Parser parser("SELECT department, SUM(salary) FROM employees GROUP BY department");
	auto stmt = parser.Parse();
	auto plan = planner.Plan(*stmt);

	// Plan tree: Project -> Sort?(no) -> Aggregate -> Scan
	auto* project = dynamic_cast<LogicalProject*>(plan.get());
	ASSERT_NE(project, nullptr);
	auto* agg = dynamic_cast<LogicalAggregate*>(project->GetChild());
	ASSERT_NE(agg, nullptr);
	EXPECT_EQ(agg->GetGroupByKeys().size(), 1u);
	EXPECT_EQ(agg->GetAggregateExprs().size(), 1u);
}

// ============================================================
// Regression: existing queries still work
// ============================================================

TEST(RegressionTest, SimpleSelectStillWorks) {
	Catalog catalog;
	catalog.CreateTable("users", Schema({Column("id", DataType::INTEGER), Column("name", DataType::STRING)}));
	Planner planner(catalog);

	Parser parser("SELECT id, name FROM users WHERE id > 5");
	auto stmt = parser.Parse();
	auto plan = planner.Plan(*stmt);
	ASSERT_NE(plan, nullptr);

	auto* project = dynamic_cast<LogicalProject*>(plan.get());
	ASSERT_NE(project, nullptr);
	// No aggregate or sort — child should be filter
	auto* filter = dynamic_cast<LogicalFilter*>(project->GetChild());
	ASSERT_NE(filter, nullptr);
}
