#include <gtest/gtest.h>

#include <filesystem>

#include "buffer/buffer_manager.h"
#include "common/types.h"
#include "disk/disk_manager.h"
#include "execution/aggregate_exec.h"
#include "execution/executor.h"
#include "execution/index_scan_exec.h"
#include "execution/sort_exec.h"
#include "index/bptree.h"
#include "object/object_manager.h"

using namespace minidb;

// ============================================================
// Helpers
// ============================================================

static Row MakeRow(int id, const std::string& name, int age) {
	Row r;
	r["id"] = Value(id);
	r["name"] = Value(name);
	r["age"] = Value(age);
	return r;
}

static std::vector<Row> CollectAll(Executor& exec) {
	std::vector<Row> rows;
	exec.Open();
	while (auto row = exec.Next()) rows.push_back(*row);
	exec.Close();
	return rows;
}

// ============================================================
// SortExec Tests
// ============================================================

TEST(SortExecTest, SortIntegerAscending) {
	std::vector<Row> input = {
		MakeRow(3, "C", 30),
		MakeRow(1, "A", 10),
		MakeRow(2, "B", 20),
	};
	auto child = std::make_unique<MockExecutor>(input);
	SortExec sort({{"id", true}}, std::move(child));

	auto result = CollectAll(sort);
	ASSERT_EQ(result.size(), 3u);
	EXPECT_EQ(result[0]["id"].AsInt(), 1);
	EXPECT_EQ(result[1]["id"].AsInt(), 2);
	EXPECT_EQ(result[2]["id"].AsInt(), 3);
}

TEST(SortExecTest, SortIntegerDescending) {
	std::vector<Row> input = {
		MakeRow(1, "A", 10),
		MakeRow(3, "C", 30),
		MakeRow(2, "B", 20),
	};
	auto child = std::make_unique<MockExecutor>(input);
	SortExec sort({{"id", false}}, std::move(child));

	auto result = CollectAll(sort);
	ASSERT_EQ(result.size(), 3u);
	EXPECT_EQ(result[0]["id"].AsInt(), 3);
	EXPECT_EQ(result[2]["id"].AsInt(), 1);
}

TEST(SortExecTest, SortString) {
	std::vector<Row> input = {
		MakeRow(1, "Charlie", 30),
		MakeRow(2, "Alice", 25),
		MakeRow(3, "Bob", 28),
	};
	auto child = std::make_unique<MockExecutor>(input);
	SortExec sort({{"name", true}}, std::move(child));

	auto result = CollectAll(sort);
	ASSERT_EQ(result.size(), 3u);
	EXPECT_EQ(result[0]["name"].AsString(), "Alice");
	EXPECT_EQ(result[1]["name"].AsString(), "Bob");
	EXPECT_EQ(result[2]["name"].AsString(), "Charlie");
}

TEST(SortExecTest, MultiKeySort) {
	std::vector<Row> input = {
		MakeRow(1, "A", 30),
		MakeRow(2, "A", 20),
		MakeRow(3, "B", 20),
	};
	// Sort by name ASC, age DESC
	auto child = std::make_unique<MockExecutor>(input);
	SortExec sort({{"name", true}, {"age", false}}, std::move(child));

	auto result = CollectAll(sort);
	ASSERT_EQ(result.size(), 3u);
	// A,30 first (name=A, age higher)
	EXPECT_EQ(result[0]["id"].AsInt(), 1);
	EXPECT_EQ(result[1]["id"].AsInt(), 2);
	EXPECT_EQ(result[2]["id"].AsInt(), 3);
}

TEST(SortExecTest, EmptyInput) {
	auto child = std::make_unique<MockExecutor>(std::vector<Row>{});
	SortExec sort({{"id", true}}, std::move(child));
	auto result = CollectAll(sort);
	EXPECT_TRUE(result.empty());
}

// ============================================================
// AggregateExec Tests
// ============================================================

TEST(AggregateExecTest, CountStarWholeTable) {
	std::vector<Row> input = {
		MakeRow(1, "A", 10),
		MakeRow(2, "B", 20),
		MakeRow(3, "C", 30),
	};
	auto child = std::make_unique<MockExecutor>(input);

	std::vector<AggregateExec::AggregateSpec> specs = {
		{AggFunc::COUNT, "", "cnt", true}
	};
	AggregateExec agg({}, std::move(specs), std::move(child));

	auto result = CollectAll(agg);
	ASSERT_EQ(result.size(), 1u);
	EXPECT_EQ(result[0]["cnt"].AsInt(), 3);
}

TEST(AggregateExecTest, SumSingleGroup) {
	std::vector<Row> input;
	for (int i = 1; i <= 5; ++i) {
		Row r;
		r["dept"] = Value(std::string("sales"));
		r["salary"] = Value(static_cast<double>(i * 1000));
		input.push_back(r);
	}
	auto child = std::make_unique<MockExecutor>(input);

	std::vector<AggregateExec::AggregateSpec> specs = {
		{AggFunc::SUM, "salary", "total", false}
	};
	AggregateExec agg({"dept"}, std::move(specs), std::move(child));

	auto result = CollectAll(agg);
	ASSERT_EQ(result.size(), 1u);
	EXPECT_DOUBLE_EQ(result[0]["total"].AsFloat(), 15000.0);
	EXPECT_EQ(result[0]["dept"].AsString(), "sales");
}

TEST(AggregateExecTest, GroupByMultipleGroups) {
	std::vector<Row> input;
	for (int i = 0; i < 3; ++i) {
		Row r;
		r["dept"] = Value(std::string("sales"));
		r["salary"] = Value(static_cast<double>(100));
		input.push_back(r);
	}
	for (int i = 0; i < 2; ++i) {
		Row r;
		r["dept"] = Value(std::string("eng"));
		r["salary"] = Value(static_cast<double>(200));
		input.push_back(r);
	}
	auto child = std::make_unique<MockExecutor>(input);

	std::vector<AggregateExec::AggregateSpec> specs = {
		{AggFunc::COUNT, "", "cnt", true},
		{AggFunc::SUM, "salary", "total", false},
	};
	AggregateExec agg({"dept"}, std::move(specs), std::move(child));

	auto result = CollectAll(agg);
	ASSERT_EQ(result.size(), 2u);

	// Find each group
	for (const auto& row : result) {
		if (row.at("dept").AsString() == "sales") {
			EXPECT_EQ(row.at("cnt").AsInt(), 3);
			EXPECT_DOUBLE_EQ(row.at("total").AsFloat(), 300.0);
		} else if (row.at("dept").AsString() == "eng") {
			EXPECT_EQ(row.at("cnt").AsInt(), 2);
			EXPECT_DOUBLE_EQ(row.at("total").AsFloat(), 400.0);
		}
	}
}

TEST(AggregateExecTest, AvgMinMax) {
	std::vector<Row> input;
	for (int i = 1; i <= 5; ++i) {
		Row r;
		r["val"] = Value(i * 10);
		input.push_back(r);
	}
	auto child = std::make_unique<MockExecutor>(input);

	std::vector<AggregateExec::AggregateSpec> specs = {
		{AggFunc::AVG, "val", "a", false},
		{AggFunc::MIN, "val", "mn", false},
		{AggFunc::MAX, "val", "mx", false},
	};
	AggregateExec agg({}, std::move(specs), std::move(child));

	auto result = CollectAll(agg);
	ASSERT_EQ(result.size(), 1u);
	EXPECT_DOUBLE_EQ(result[0]["a"].AsFloat(), 30.0);
	EXPECT_EQ(result[0]["mn"].AsInt(), 10);
	EXPECT_EQ(result[0]["mx"].AsInt(), 50);
}

TEST(AggregateExecTest, EmptyInputCountZero) {
	auto child = std::make_unique<MockExecutor>(std::vector<Row>{});
	std::vector<AggregateExec::AggregateSpec> specs = {
		{AggFunc::COUNT, "", "cnt", true}
	};
	AggregateExec agg({}, std::move(specs), std::move(child));

	auto result = CollectAll(agg);
	ASSERT_EQ(result.size(), 1u);
	EXPECT_EQ(result[0]["cnt"].AsInt(), 0);
}

// ============================================================
// IndexScanExec Tests
// ============================================================

class IndexScanExecTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_index_scan.db";
	DiskManager* dm_;
	BufferManager* bm_;
	ObjectManager* om_;
	BPTree* tree_;
	page_id_t root_pid_;
	Schema schema_;

	void SetUp() override {
		dm_ = new DiskManager(db_path_);
		bm_ = new BufferManager(dm_, 64);
		om_ = new ObjectManager(bm_);

		schema_ = Schema({
			Column("id", DataType::INTEGER),
			Column("name", DataType::STRING),
		});

		// Create empty root for tree
		Page* root = bm_->NewPage();
		root_pid_ = root->GetPageId();
		BPTreeNode rn; rn.is_leaf = true;
		BPTree::SerializeNode(root->GetData(), rn);
		bm_->UnpinPage(root_pid_, true);

		tree_ = new BPTree(bm_, root_pid_);

		// Insert some records (each on its own page, slot 0)
		for (int i = 1; i <= 5; ++i) {
			Row row;
			row["id"] = Value(i);
			row["name"] = Value(std::string("row") + std::to_string(i));

			// Allocate a data page and insert the serialized row
			Page* data_page = bm_->NewPage();
			page_id_t data_pid = data_page->GetPageId();
			ObjectManager::InitPage(data_page);
			bm_->UnpinPage(data_pid, true);

			auto bytes = ObjectManager::SerializeRow(row, schema_);
			om_->InsertRecord(data_pid, bytes);

			// Add to index
			tree_->Insert(i, data_pid);
		}
	}

	void TearDown() override {
		delete tree_;
		delete om_;
		delete bm_;
		delete dm_;
		std::filesystem::remove(db_path_);
	}
};

TEST_F(IndexScanExecTest, PointLookup) {
	IndexScanExec exec(tree_, om_, 3, 3, schema_);
	auto result = CollectAll(exec);
	ASSERT_EQ(result.size(), 1u);
	EXPECT_EQ(result[0]["id"].AsInt(), 3);
	EXPECT_EQ(result[0]["name"].AsString(), "row3");
}

TEST_F(IndexScanExecTest, RangeScan) {
	IndexScanExec exec(tree_, om_, 2, 4, schema_);
	auto result = CollectAll(exec);
	ASSERT_EQ(result.size(), 3u);
	EXPECT_EQ(result[0]["id"].AsInt(), 2);
	EXPECT_EQ(result[1]["id"].AsInt(), 3);
	EXPECT_EQ(result[2]["id"].AsInt(), 4);
}

TEST_F(IndexScanExecTest, EmptyRange) {
	IndexScanExec exec(tree_, om_, 100, 200, schema_);
	auto result = CollectAll(exec);
	EXPECT_TRUE(result.empty());
}
