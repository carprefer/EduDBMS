#include <gtest/gtest.h>

#include <algorithm>
#include <cmath>
#include <numeric>
#include <random>

#include "execution/vector_scan_exec.h"
#include "parser/parser.h"
#include "vector/diskann_index.h"
#include "vector/vector_types.h"

using namespace minidb;

// ============================================================
// Helpers
// ============================================================

static Vector MakeVec(std::initializer_list<float> vals) {
	return Vector{std::vector<float>(vals)};
}

static std::vector<Vector> MakeGrid2D(int n) {
	// Create n*n vectors on a 2D grid: (0,0), (0,1), ..., (n-1, n-1)
	std::vector<Vector> vecs;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			vecs.push_back(MakeVec({static_cast<float>(i), static_cast<float>(j)}));
		}
	}
	return vecs;
}

static std::vector<Vector> MakeRandom(int n, int dim, int seed = 42) {
	std::mt19937 rng(seed);
	std::uniform_real_distribution<float> dist(0.0f, 100.0f);
	std::vector<Vector> vecs(n);
	for (auto& v : vecs) {
		v.data.resize(dim);
		for (auto& x : v.data) x = dist(rng);
	}
	return vecs;
}

// Brute force KNN for ground truth
static std::vector<std::pair<uint32_t, float>> BruteForceKNN(
		const std::vector<Vector>& dataset, const Vector& query, uint32_t k) {
	std::vector<std::pair<uint32_t, float>> dists;
	for (uint32_t i = 0; i < dataset.size(); ++i) {
		dists.push_back({i, L2Distance(query, dataset[i])});
	}
	std::sort(dists.begin(), dists.end(),
		[](const auto& a, const auto& b) { return a.second < b.second; });
	if (dists.size() > k) dists.resize(k);
	return dists;
}

// ============================================================
// L2 Distance Tests
// ============================================================

TEST(VectorTest, L2DistanceIdentical) {
	auto a = MakeVec({1.0f, 2.0f, 3.0f});
	EXPECT_FLOAT_EQ(L2Distance(a, a), 0.0f);
}

TEST(VectorTest, L2DistanceBasic) {
	auto a = MakeVec({0.0f, 0.0f});
	auto b = MakeVec({3.0f, 4.0f});
	EXPECT_FLOAT_EQ(L2Distance(a, b), 5.0f);
}

TEST(VectorTest, L2DistanceHighDim) {
	auto a = MakeVec({1.0f, 2.0f, 3.0f, 4.0f});
	auto b = MakeVec({5.0f, 6.0f, 7.0f, 8.0f});
	// sqrt((4^2)*4) = sqrt(64) = 8
	EXPECT_FLOAT_EQ(L2Distance(a, b), 8.0f);
}

// ============================================================
// DiskANN Build + Search Tests
// ============================================================

TEST(DiskANNTest, BuildAndSearchSmall) {
	auto vecs = MakeGrid2D(3);  // 9 vectors in 2D grid
	DiskANNIndex index(4, 8);
	index.Build(vecs);

	// Search for nearest to (0, 0) — should find itself
	auto results = index.Search(MakeVec({0.0f, 0.0f}), 1);
	ASSERT_GE(results.size(), 1u);
	EXPECT_FLOAT_EQ(results[0].second, 0.0f);
}

TEST(DiskANNTest, SearchReturnsKResults) {
	auto vecs = MakeGrid2D(5);  // 25 vectors
	DiskANNIndex index(8, 16);
	index.Build(vecs);

	auto results = index.Search(MakeVec({2.0f, 2.0f}), 5);
	EXPECT_EQ(results.size(), 5u);

	// Results should be sorted by distance
	for (size_t i = 1; i < results.size(); ++i) {
		EXPECT_LE(results[i - 1].second, results[i].second);
	}
}

TEST(DiskANNTest, SearchExactMatch) {
	auto vecs = MakeGrid2D(4);  // 16 vectors
	DiskANNIndex index(6, 12);
	index.Build(vecs);

	// Query is exactly a point in the dataset
	auto results = index.Search(MakeVec({2.0f, 3.0f}), 1);
	ASSERT_GE(results.size(), 1u);
	EXPECT_NEAR(results[0].second, 0.0f, 1e-5f);
}

TEST(DiskANNTest, SearchNonExactQuery) {
	auto vecs = MakeGrid2D(5);  // 25 vectors
	DiskANNIndex index(8, 16);
	index.Build(vecs);

	// Query is between grid points
	auto query = MakeVec({1.5f, 1.5f});
	auto results = index.Search(query, 4);
	ASSERT_EQ(results.size(), 4u);

	// 4 nearest should be (1,1), (1,2), (2,1), (2,2) — all at distance sqrt(0.5)
	for (const auto& [id, dist] : results) {
		EXPECT_NEAR(dist, std::sqrt(0.5f), 1e-5f);
	}
}

TEST(DiskANNTest, RecallOn100Vectors) {
	auto vecs = MakeRandom(100, 8);
	DiskANNIndex index(16, 32);
	index.Build(vecs);

	int total_recall = 0;
	int queries = 10;
	int k = 5;

	std::mt19937 rng(99);
	for (int q = 0; q < queries; ++q) {
		Vector query;
		query.data.resize(8);
		std::uniform_real_distribution<float> dist(0.0f, 100.0f);
		for (auto& x : query.data) x = dist(rng);

		auto ann_results = index.Search(query, k);
		auto gt_results = BruteForceKNN(vecs, query, k);

		// Count how many of the true top-k are in the ANN results
		std::set<uint32_t> ann_ids;
		for (const auto& [id, d] : ann_results) ann_ids.insert(id);

		for (const auto& [id, d] : gt_results) {
			if (ann_ids.count(id)) ++total_recall;
		}
	}

	double recall = static_cast<double>(total_recall) / (queries * k);
	EXPECT_GT(recall, 0.5) << "Recall@" << k << " = " << recall << " (expected > 0.5)";
}

TEST(DiskANNTest, RecallOn500Vectors) {
	auto vecs = MakeRandom(500, 16);
	DiskANNIndex index(32, 64);
	index.Build(vecs);

	int total_recall = 0;
	int queries = 20;
	int k = 10;

	std::mt19937 rng(77);
	for (int q = 0; q < queries; ++q) {
		Vector query;
		query.data.resize(16);
		std::uniform_real_distribution<float> dist(0.0f, 100.0f);
		for (auto& x : query.data) x = dist(rng);

		auto ann_results = index.Search(query, k);
		auto gt_results = BruteForceKNN(vecs, query, k);

		std::set<uint32_t> ann_ids;
		for (const auto& [id, d] : ann_results) ann_ids.insert(id);

		for (const auto& [id, d] : gt_results) {
			if (ann_ids.count(id)) ++total_recall;
		}
	}

	double recall = static_cast<double>(total_recall) / (queries * k);
	EXPECT_GT(recall, 0.4) << "Recall@" << k << " = " << recall << " (expected > 0.4)";
}

// ============================================================
// Robust Prune Tests
// ============================================================

TEST(DiskANNTest, PruneRespectsDegree) {
	auto vecs = MakeGrid2D(5);
	DiskANNIndex index(4, 16);  // max_degree = 4
	index.Build(vecs);

	// After build, no node should have more than max_degree neighbors
	// (We can't directly inspect adjacency_, but search should work)
	auto results = index.Search(MakeVec({0.0f, 0.0f}), 3);
	ASSERT_GE(results.size(), 1u);
}

// ============================================================
// Edge Cases
// ============================================================

TEST(DiskANNTest, SingleVector) {
	std::vector<Vector> vecs = {MakeVec({1.0f, 2.0f})};
	DiskANNIndex index(4, 8);
	index.Build(vecs);

	auto results = index.Search(MakeVec({5.0f, 5.0f}), 1);
	ASSERT_EQ(results.size(), 1u);
	EXPECT_EQ(results[0].first, 0u);
}

TEST(DiskANNTest, TwoVectors) {
	std::vector<Vector> vecs = {MakeVec({0.0f, 0.0f}), MakeVec({10.0f, 10.0f})};
	DiskANNIndex index(4, 8);
	index.Build(vecs);

	// Closer to first
	auto r1 = index.Search(MakeVec({1.0f, 1.0f}), 1);
	EXPECT_EQ(r1[0].first, 0u);

	// Closer to second
	auto r2 = index.Search(MakeVec({9.0f, 9.0f}), 1);
	EXPECT_EQ(r2[0].first, 1u);
}

// ============================================================
// SQL Parsing Tests
// ============================================================

TEST(VectorSQLTest, ParseVectorColumnType) {
	Parser parser("CREATE TABLE items (id INTEGER, embedding VECTOR(3))");
	auto stmt = parser.ParseCLI();
	auto* create = dynamic_cast<CreateTableStatement*>(stmt.get());
	ASSERT_NE(create, nullptr);
	EXPECT_EQ(create->GetColumnDefs().size(), 2u);
	EXPECT_EQ(create->GetColumnDefs()[1].type_name, "VECTOR(3)");
}

TEST(VectorSQLTest, ParseDistanceOperator) {
	Parser parser("SELECT * FROM items ORDER BY embedding <-> [1.0, 2.0, 3.0]");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasOrderBy());
	auto* dist = dynamic_cast<const DistanceExpr*>(select->GetOrderBy()[0].expr.get());
	ASSERT_NE(dist, nullptr);
}

TEST(VectorSQLTest, ParseLimitClause) {
	Parser parser("SELECT * FROM items ORDER BY id LIMIT 10");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasLimit());
	EXPECT_EQ(select->GetLimit(), 10);
}

TEST(VectorSQLTest, ParseFullVectorQuery) {
	Parser parser("SELECT * FROM items ORDER BY embedding <-> [1.0, 2.0] LIMIT 5");
	auto stmt = parser.Parse();
	auto* select = dynamic_cast<SelectStatement*>(stmt.get());
	ASSERT_NE(select, nullptr);
	EXPECT_TRUE(select->HasOrderBy());
	EXPECT_TRUE(select->HasLimit());
	EXPECT_EQ(select->GetLimit(), 5);
	auto* dist = dynamic_cast<const DistanceExpr*>(select->GetOrderBy()[0].expr.get());
	ASSERT_NE(dist, nullptr);
	auto* vec = dynamic_cast<const VectorLiteral*>(dist->GetTarget());
	ASSERT_NE(vec, nullptr);
}

// ============================================================
// VectorScanExec Tests
// ============================================================

TEST(VectorScanExecTest, BasicSearch) {
	// Build index with 2D vectors
	std::vector<Vector> vecs = {
		MakeVec({0.0f, 0.0f}),
		MakeVec({1.0f, 1.0f}),
		MakeVec({2.0f, 2.0f}),
		MakeVec({10.0f, 10.0f}),
		MakeVec({11.0f, 11.0f}),
	};
	DiskANNIndex index(4, 8);
	index.Build(vecs);

	// Create table rows matching the vectors
	std::vector<Row> rows;
	for (size_t i = 0; i < vecs.size(); ++i) {
		Row r;
		r["id"] = Value(static_cast<int>(i));
		r["name"] = Value(std::string("item") + std::to_string(i));
		rows.push_back(r);
	}

	// Query near (1, 1) — should return items 0, 1, 2 as top 3
	VectorScanExec exec(&index, &rows, MakeVec({1.0f, 1.0f}), 3);
	exec.Open();

	std::vector<Row> results;
	while (auto row = exec.Next()) results.push_back(*row);
	exec.Close();

	ASSERT_EQ(results.size(), 3u);
	// First result should be id=1 (exact match)
	EXPECT_EQ(results[0]["id"].AsInt(), 1);
}

// ============================================================
// Utility Tests
// ============================================================

TEST(DiskANNTest, ParseVectorLiteral) {
	auto v = ParseVectorLiteral("[1.5, 2.5, 3.5]");
	ASSERT_EQ(v.Dim(), 3u);
	EXPECT_FLOAT_EQ(v.data[0], 1.5f);
	EXPECT_FLOAT_EQ(v.data[1], 2.5f);
	EXPECT_FLOAT_EQ(v.data[2], 3.5f);
}
