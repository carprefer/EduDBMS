#include <gtest/gtest.h>

#include <cstring>
#include <filesystem>

#include "buffer/buffer_manager.h"
#include "common/config.h"
#include "common/exceptions.h"
#include "common/types.h"
#include "disk/disk_manager.h"
#include "object/object_manager.h"

using namespace minidb;

class ObjectManagerTest : public ::testing::Test {
protected:
	std::string db_path_ = "test_object_manager.db";
	DiskManager* dm_;
	BufferManager* bm_;
	ObjectManager* om_;

	void SetUp() override {
		dm_ = new DiskManager(db_path_);
		bm_ = new BufferManager(dm_, 16);
		om_ = new ObjectManager(bm_);
	}

	void TearDown() override {
		delete om_;
		delete bm_;
		delete dm_;
		std::filesystem::remove(db_path_);
	}

	// Helper: allocate a fresh slotted page
	page_id_t AllocateSlottedPage() {
		Page* page = bm_->NewPage();
		page_id_t pid = page->GetPageId();
		ObjectManager::InitPage(page);
		bm_->UnpinPage(pid, true);
		return pid;
	}
};

// ============================================================
// Record Insert / Get / Delete
// ============================================================

TEST_F(ObjectManagerTest, InsertAndGetSingleRecord) {
	page_id_t pid = AllocateSlottedPage();

	std::vector<uint8_t> record = {1, 2, 3, 4, 5};
	slot_id_t slot = om_->InsertRecord(pid, record);
	EXPECT_NE(slot, INVALID_SLOT_ID);

	auto retrieved = om_->GetRecord(pid, slot);
	EXPECT_EQ(retrieved, record);
}

TEST_F(ObjectManagerTest, InsertMultipleRecords) {
	page_id_t pid = AllocateSlottedPage();

	std::vector<uint8_t> r1 = {10, 20};
	std::vector<uint8_t> r2 = {30, 40, 50};
	std::vector<uint8_t> r3 = {60};

	slot_id_t s1 = om_->InsertRecord(pid, r1);
	slot_id_t s2 = om_->InsertRecord(pid, r2);
	slot_id_t s3 = om_->InsertRecord(pid, r3);

	EXPECT_EQ(s1, 0);
	EXPECT_EQ(s2, 1);
	EXPECT_EQ(s3, 2);

	EXPECT_EQ(om_->GetRecord(pid, s1), r1);
	EXPECT_EQ(om_->GetRecord(pid, s2), r2);
	EXPECT_EQ(om_->GetRecord(pid, s3), r3);
}

TEST_F(ObjectManagerTest, DeleteRecord) {
	page_id_t pid = AllocateSlottedPage();

	std::vector<uint8_t> record = {1, 2, 3};
	slot_id_t slot = om_->InsertRecord(pid, record);

	om_->DeleteRecord(pid, slot);
	EXPECT_THROW(om_->GetRecord(pid, slot), RecordNotFoundException);
}

TEST_F(ObjectManagerTest, DeleteDoesNotAffectOthers) {
	page_id_t pid = AllocateSlottedPage();

	std::vector<uint8_t> r1 = {10};
	std::vector<uint8_t> r2 = {20};
	std::vector<uint8_t> r3 = {30};

	slot_id_t s1 = om_->InsertRecord(pid, r1);
	slot_id_t s2 = om_->InsertRecord(pid, r2);
	slot_id_t s3 = om_->InsertRecord(pid, r3);

	om_->DeleteRecord(pid, s2);

	EXPECT_EQ(om_->GetRecord(pid, s1), r1);
	EXPECT_THROW(om_->GetRecord(pid, s2), RecordNotFoundException);
	EXPECT_EQ(om_->GetRecord(pid, s3), r3);
}

TEST_F(ObjectManagerTest, PageFullReturnsInvalidSlot) {
	page_id_t pid = AllocateSlottedPage();

	// Page layout: 4096 total
	//   - PageHeader: 4 bytes (num_slots + free_space_offset)
	//   - Each record uses: record_size + SlotInfo(4 bytes)
	// After 2 records of 2000 bytes:
	//   Used = 4 (header) + 2*4 (slots) + 2*2000 (records) = 4012
	//   Free = 4096 - 4012 = 84 bytes
	// A third 2000-byte record needs 2000 + 4 = 2004 bytes → won't fit
	std::vector<uint8_t> big_record(2000, 0xAB);
	slot_id_t s1 = om_->InsertRecord(pid, big_record);
	EXPECT_NE(s1, INVALID_SLOT_ID);

	slot_id_t s2 = om_->InsertRecord(pid, big_record);
	EXPECT_NE(s2, INVALID_SLOT_ID);

	std::vector<uint8_t> wont_fit(2000, 0xCD);
	slot_id_t s3 = om_->InsertRecord(pid, wont_fit);
	EXPECT_EQ(s3, INVALID_SLOT_ID);
}

TEST_F(ObjectManagerTest, GetInvalidSlotThrows) {
	page_id_t pid = AllocateSlottedPage();
	EXPECT_THROW(om_->GetRecord(pid, 999), RecordNotFoundException);
}

// ============================================================
// Serialization / Deserialization
// ============================================================

TEST_F(ObjectManagerTest, SerializeDeserializeInteger) {
	Schema schema({Column("id", DataType::INTEGER)});
	Row row;
	row["id"] = Value(42);

	auto bytes = ObjectManager::SerializeRow(row, schema);
	EXPECT_GT(bytes.size(), 0u);

	Row restored = ObjectManager::DeserializeRow(bytes, schema);
	EXPECT_EQ(restored["id"].AsInt(), 42);
}

TEST_F(ObjectManagerTest, SerializeDeserializeFloat) {
	Schema schema({Column("price", DataType::FLOAT)});
	Row row;
	row["price"] = Value(3.14);

	auto bytes = ObjectManager::SerializeRow(row, schema);
	Row restored = ObjectManager::DeserializeRow(bytes, schema);
	EXPECT_DOUBLE_EQ(restored["price"].AsFloat(), 3.14);
}

TEST_F(ObjectManagerTest, SerializeDeserializeString) {
	Schema schema({Column("name", DataType::STRING)});
	Row row;
	row["name"] = Value(std::string("Hello"));

	auto bytes = ObjectManager::SerializeRow(row, schema);
	Row restored = ObjectManager::DeserializeRow(bytes, schema);
	EXPECT_EQ(restored["name"].AsString(), "Hello");
}

TEST_F(ObjectManagerTest, SerializeDeserializeEmptyString) {
	Schema schema({Column("s", DataType::STRING)});
	Row row;
	row["s"] = Value(std::string(""));

	auto bytes = ObjectManager::SerializeRow(row, schema);
	Row restored = ObjectManager::DeserializeRow(bytes, schema);
	EXPECT_EQ(restored["s"].AsString(), "");
}

TEST_F(ObjectManagerTest, SerializeDeserializeMixedTypes) {
	Schema schema({
		Column("id", DataType::INTEGER),
		Column("name", DataType::STRING),
		Column("salary", DataType::FLOAT),
		Column("active", DataType::BOOLEAN),
	});

	Row row;
	row["id"] = Value(1);
	row["name"] = Value(std::string("Alice"));
	row["salary"] = Value(50000.0);
	row["active"] = Value(true);

	auto bytes = ObjectManager::SerializeRow(row, schema);
	Row restored = ObjectManager::DeserializeRow(bytes, schema);

	EXPECT_EQ(restored["id"].AsInt(), 1);
	EXPECT_EQ(restored["name"].AsString(), "Alice");
	EXPECT_DOUBLE_EQ(restored["salary"].AsFloat(), 50000.0);
	EXPECT_EQ(restored["active"].AsBool(), true);
}

TEST_F(ObjectManagerTest, InsertAndGetSerializedRow) {
	page_id_t pid = AllocateSlottedPage();

	Schema schema({
		Column("id", DataType::INTEGER),
		Column("name", DataType::STRING),
	});

	Row row;
	row["id"] = Value(7);
	row["name"] = Value(std::string("Bob"));

	auto bytes = ObjectManager::SerializeRow(row, schema);
	slot_id_t slot = om_->InsertRecord(pid, bytes);
	EXPECT_NE(slot, INVALID_SLOT_ID);

	auto retrieved_bytes = om_->GetRecord(pid, slot);
	Row restored = ObjectManager::DeserializeRow(retrieved_bytes, schema);

	EXPECT_EQ(restored["id"].AsInt(), 7);
	EXPECT_EQ(restored["name"].AsString(), "Bob");
}
