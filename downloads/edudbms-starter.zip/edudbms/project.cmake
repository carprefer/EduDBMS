# Generated for the full skeleton download — do not edit.
set(EDUDBMS_PROJ starter)
set(EDUDBMS_SOURCES
	src/parser/lexer.cpp
	src/engine/engine.cpp
	src/recovery/log_record.cpp
	src/disk/disk_manager.cpp
	src/buffer/replacer.cpp
	src/buffer/buffer_manager.cpp
	src/object/object_manager.cpp
	src/index/bptree.cpp
	src/parser/parser.cpp
	src/planner/planner.cpp
	src/execution/sort_exec.cpp
	src/execution/aggregate_exec.cpp
	src/execution/index_scan_exec.cpp
	src/recovery/log_manager.cpp
	src/recovery/recovery_manager.cpp
	src/vector/diskann_index.cpp
	src/execution/vector_scan_exec.cpp
)
set(EDUDBMS_REF_LIB "")
