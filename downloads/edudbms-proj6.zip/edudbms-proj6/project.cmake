# Generated for the Project #6 download — do not edit.
set(EDUDBMS_PROJ proj6)
set(EDUDBMS_SOURCES
	src/parser/lexer.cpp
	src/engine/engine.cpp
	src/recovery/log_record.cpp
	src/recovery/log_manager.cpp
	src/recovery/recovery_manager.cpp
)
set(EDUDBMS_REF_LIB libref_upto_proj5.a)
