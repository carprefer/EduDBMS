include(FetchContent)
FetchContent_Declare(
	googletest
	GIT_REPOSITORY https://github.com/google/googletest.git
	GIT_TAG v1.14.0
)
FetchContent_MakeAvailable(googletest)

include(GoogleTest)

# A starter download ships only its own test file, so each target is added
# only when its source is actually present.
function(edudbms_add_test target source)
	if(NOT EXISTS ${CMAKE_CURRENT_SOURCE_DIR}/${source})
		return()
	endif()
	add_executable(${target} ${source})
	target_link_libraries(${target} PRIVATE minidb GTest::gtest_main)
	gtest_discover_tests(${target})
endfunction()

edudbms_add_test(proj1_test proj1_disk_buffer_test.cpp)   # Disk Manager + Buffer Manager
edudbms_add_test(proj2_test proj2_object_test.cpp)        # Object Manager
edudbms_add_test(proj3_test proj3_bptree_test.cpp)        # B+-Tree
edudbms_add_test(proj4_test proj4_query_test.cpp)         # Parser + Planner
edudbms_add_test(proj5_test proj5_executor_test.cpp)      # Executor
edudbms_add_test(proj6_test proj6_recovery_test.cpp)      # ARIES Recovery
edudbms_add_test(proj7_test proj7_vector_test.cpp)        # Vector Similarity (DiskANN)
edudbms_add_test(e2e_test e2e_test.cpp)               # End-to-end integration
