# Generated for the Project #2 download — do not edit.
set(EDUDBMS_PROJ proj2)
set(EDUDBMS_SOURCES
	src/object/object_manager.cpp
)
set(EDUDBMS_REF_LIB libref_upto_proj1.a)
