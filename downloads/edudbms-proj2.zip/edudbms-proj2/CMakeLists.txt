cmake_minimum_required(VERSION 3.14)
project(minidb LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# ============================================================
# Student build
# ============================================================
# A starter download carries no ref/ sources — only a prebuilt reference
# library for the earlier projects — so the full build below cannot apply.
# project.cmake ships with the download and names what to compile.
if(NOT IS_DIRECTORY ${CMAKE_SOURCE_DIR}/ref AND EXISTS ${CMAKE_SOURCE_DIR}/project.cmake)
	include(${CMAKE_SOURCE_DIR}/project.cmake)
	message(STATUS "EduDBMS: building the ${EDUDBMS_PROJ} starter")

	# Checked for every download, not only the ones that carry a reference
	# library. Project #1 carries none, so a Windows student used to get it
	# configured, settle on a toolchain, and hit this wall at Project #2.
	if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
		set(EDUDBMS_OS macos)
	elseif(CMAKE_SYSTEM_NAME STREQUAL "Linux")
		set(EDUDBMS_OS linux)
	else()
		message(FATAL_ERROR
			"EduDBMS: ${CMAKE_SYSTEM_NAME} is not supported. Build on macOS or Linux.\n"
			"On Windows, use WSL — install it, open your Linux shell, and build there.\n"
			"The later projects ship reference libraries built only for macOS and Linux,\n"
			"so a native Windows toolchain cannot carry you past this project.")
	endif()

	if(CMAKE_SYSTEM_PROCESSOR MATCHES "arm64|aarch64")
		set(EDUDBMS_ARCH arm64)
	else()
		set(EDUDBMS_ARCH x86_64)
	endif()

	add_library(minidb STATIC ${EDUDBMS_SOURCES})
	target_include_directories(minidb PUBLIC ${CMAKE_SOURCE_DIR}/src)

	if(EDUDBMS_REF_LIB)
		set(EDUDBMS_LIB ${CMAKE_SOURCE_DIR}/lib/${EDUDBMS_OS}-${EDUDBMS_ARCH}/${EDUDBMS_REF_LIB})
		if(NOT EXISTS ${EDUDBMS_LIB})
			file(GLOB EDUDBMS_HAVE RELATIVE ${CMAKE_SOURCE_DIR}/lib ${CMAKE_SOURCE_DIR}/lib/*)
			message(FATAL_ERROR
				"EduDBMS: this download has no reference library for ${EDUDBMS_OS}-${EDUDBMS_ARCH}.\n"
				"Bundled platforms: ${EDUDBMS_HAVE}")
		endif()
		# The two archives need each other: minidb calls into the reference
		# library, and the reference library calls back out to the base sources
		# compiled here — parser_ref.cpp constructs a Lexer, for one. Apple's
		# linker rescans and never minded; GNU ld reads the command line once and
		# reported Lexer as undefined. Declaring the cycle is how CMake is told to
		# repeat both archives on the link line, and it needs no linker flags.
		add_library(edudbms_ref STATIC IMPORTED)
		set_target_properties(edudbms_ref PROPERTIES
			IMPORTED_LOCATION ${EDUDBMS_LIB}
			INTERFACE_LINK_LIBRARIES minidb)
		target_link_libraries(minidb PUBLIC edudbms_ref)
	endif()

	enable_testing()
	add_subdirectory(tests)
	return()
endif()

# ============================================================
# Build mode options
# ============================================================
option(REFERENCE "Use reference for all phases" OFF)
option(WASM "Build for WebAssembly (Emscripten)" OFF)
set(GRADING "" CACHE STRING "Which project is being graded (proj1..proj7). Others use reference.")

# WASM mode forces REFERENCE=ON
if(WASM)
	set(REFERENCE ON)
endif()

# ============================================================
# Per-phase source lists
# ============================================================
set(PROJ1_STUB src/disk/disk_manager.cpp src/buffer/replacer.cpp src/buffer/buffer_manager.cpp)
set(PROJ1_REF  ref/disk_manager_ref.cpp  ref/replacer_ref.cpp     ref/buffer_manager_ref.cpp)

set(PROJ2_STUB src/object/object_manager.cpp)
set(PROJ2_REF  ref/object_manager_ref.cpp)

set(PROJ3_STUB src/index/bptree.cpp)
set(PROJ3_REF  ref/bptree_ref.cpp)

set(PROJ4_STUB src/parser/parser.cpp src/planner/planner.cpp)
set(PROJ4_REF  ref/parser_ref.cpp    ref/planner_ref.cpp)

set(PROJ5_STUB src/execution/sort_exec.cpp src/execution/aggregate_exec.cpp src/execution/index_scan_exec.cpp)
set(PROJ5_REF  ref/sort_exec_ref.cpp       ref/aggregate_exec_ref.cpp       ref/index_scan_exec_ref.cpp)

set(PROJ6_STUB src/recovery/log_manager.cpp src/recovery/recovery_manager.cpp)
set(PROJ6_REF  ref/log_manager_ref.cpp      ref/recovery_manager_ref.cpp)

set(PROJ7_STUB src/vector/diskann_index.cpp src/execution/vector_scan_exec.cpp)
set(PROJ7_REF  ref/diskann_ref.cpp          ref/vector_scan_exec_ref.cpp)

# Always-included sources
set(BASE_SOURCES
	src/parser/lexer.cpp
	src/engine/engine.cpp
	src/recovery/log_record.cpp
)

# ============================================================
# Decide which phases use stubs vs ref
# ============================================================
set(STUB_PHASES proj1 proj2 proj3 proj4 proj5 proj6 proj7)

if(REFERENCE)
	set(STUB_PHASES "")
elseif(GRADING)
	set(STUB_PHASES ${GRADING})
endif()

# Build source list
set(MINIDB_SOURCES ${BASE_SOURCES})

foreach(phase IN ITEMS proj1 proj2 proj3 proj4 proj5 proj6 proj7)
	list(FIND STUB_PHASES ${phase} found)
	if(found GREATER -1)
		string(TOUPPER ${phase} PHASE_UPPER)
		list(APPEND MINIDB_SOURCES ${${PHASE_UPPER}_STUB})
	else()
		string(TOUPPER ${phase} PHASE_UPPER)
		list(APPEND MINIDB_SOURCES ${${PHASE_UPPER}_STUB})
		list(APPEND MINIDB_SOURCES ${${PHASE_UPPER}_REF})
	endif()
endforeach()

add_library(minidb STATIC ${MINIDB_SOURCES})
target_include_directories(minidb PUBLIC ${CMAKE_SOURCE_DIR}/src)

# Set REFERENCE_IMPL define on per-file basis for ref-mode files
foreach(phase IN ITEMS proj1 proj2 proj3 proj4 proj5 proj6 proj7)
	list(FIND STUB_PHASES ${phase} found)
	if(found EQUAL -1)
		string(TOUPPER ${phase} PHASE_UPPER)
		set_source_files_properties(${${PHASE_UPPER}_STUB} PROPERTIES
			COMPILE_DEFINITIONS REFERENCE_IMPL)
	endif()
endforeach()

# ============================================================
# WASM Target (Emscripten)
# ============================================================
if(WASM)
	add_executable(edudbms src/wasm/wasm_bridge.cpp)
	target_link_libraries(edudbms PRIVATE minidb)

	set_target_properties(edudbms PROPERTIES
		SUFFIX ".js"
		LINK_FLAGS "\
			-s EXPORTED_FUNCTIONS=['_edudbms_create','_edudbms_execute','_edudbms_execute_cli','_edudbms_error','_edudbms_free','_edudbms_destroy','_malloc','_free'] \
			-s EXPORTED_RUNTIME_METHODS=['ccall','cwrap','UTF8ToString','stringToUTF8','lengthBytesUTF8'] \
			-s ALLOW_MEMORY_GROWTH=1 \
			-s INITIAL_MEMORY=67108864 \
			-s MODULARIZE=1 \
			-s EXPORT_NAME='createEduDBMS' \
			-s ENVIRONMENT='web,node' \
			-s FORCE_FILESYSTEM=1 \
			-s NO_EXIT_RUNTIME=1 \
			-s DISABLE_EXCEPTION_CATCHING=0 \
			-O2"
	)
endif()

# ============================================================
# Tests (disabled for WASM builds)
# ============================================================
if(NOT WASM)
	enable_testing()
	add_subdirectory(tests)
endif()
