# Generated for the Project #5 download — do not edit.
set(EDUDBMS_PROJ proj5)
set(EDUDBMS_SOURCES
	src/parser/lexer.cpp
	src/engine/engine.cpp
	src/execution/sort_exec.cpp
	src/execution/aggregate_exec.cpp
	src/execution/index_scan_exec.cpp
)
set(EDUDBMS_REF_LIB libref_upto_proj4.a)
