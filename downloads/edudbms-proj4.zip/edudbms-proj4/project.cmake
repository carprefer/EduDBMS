# Generated for the Project #4 download — do not edit.
set(EDUDBMS_PROJ proj4)
set(EDUDBMS_SOURCES
	src/parser/lexer.cpp
	src/parser/parser.cpp
	src/planner/planner.cpp
)
set(EDUDBMS_REF_LIB libref_upto_proj3.a)
