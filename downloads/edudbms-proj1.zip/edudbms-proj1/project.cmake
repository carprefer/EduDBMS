# Generated for the Project #1 download — do not edit.
set(EDUDBMS_PROJ proj1)
set(EDUDBMS_SOURCES
	src/disk/disk_manager.cpp
	src/buffer/replacer.cpp
	src/buffer/buffer_manager.cpp
)
set(EDUDBMS_REF_LIB "")
