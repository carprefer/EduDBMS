# EduDBMS — Project #1 Starter — Disk Manager & Buffer Manager

CSED357 Database Systems, Fall 2026, POSTECH

## Build

CMake 3.14 or newer, a C++17 compiler, and — the first time — an internet
connection, because GoogleTest is downloaded during configuration.

**Works on macOS or Linux, on either Intel or ARM. On Windows, build inside WSL: a native Windows toolchain is refused, because the reference libraries these downloads carry are built for macOS and Linux only.**

```bash
cmake -B build
cmake --build build
```

## Run the tests

```bash
ctest --test-dir build --output-on-failure
```

Each test case runs in its own process, so an unimplemented function that
crashes does not stop the rest of the suite from reporting.

## What you implement

- `src/disk/disk_manager.cpp`
- `src/buffer/replacer.cpp`
- `src/buffer/buffer_manager.cpp`

Look for the `TODO` comments in those files. The headers carry `[Project #1 TODO]` blocks
as well, but those are the spec for the function you are about to write —
hints, parameters, return values. Nothing outside the `.cpp` files listed
above needs editing.

## What to submit

One archive, laid out like this:

```
<student id>_proj1.zip
├── src/disk/disk_manager.cpp
├── src/buffer/replacer.cpp
├── src/buffer/buffer_manager.cpp
├── result.txt
└── REPORT.md
```

- `result.txt` — Output of `ctest --test-dir build --output-on-failure > result.txt 2>&1`
- `REPORT.md` — Your report (see the sections below)

Keep the original directory layout inside the archive (src/…), so the files drop straight back into the project tree. Submit only the files you edited: no build/ directory, no compiled objects, no reference libraries.

The report is worth 45 of the 50 points. It has 4 sections, weighted as a share of the project:

- **Problem Analysis** (20%) — What each function you write has to solve, and what the given code it calls does for it. Only what your functions actually use — not every header in the download.
- **Design** (10%) — The algorithm you chose for each function, and why that one.
- **Mapping** (10%) — Which part of the design is which part of your code, by file and line.
- **Verification** (50%) — The argument that your code is right.
  1. (25%) **For each module below, write one expression that is always true of it** — true before any of its functions is called, and true again every time one of them returns. It may go false in the middle of a function; that is what makes it worth writing down.
       - `DiskManager`
       - `LRUReplacer`
       - `BufferManager`

     The expression is symbols, not words:

         gcd(num, den) = 1 and den > 0

     If something is hard to put in symbols, define it as a variable in words, then use the variable in the expression:

         P = the spaces with a car in them
         F = the spaces that are empty

         P union F = {0 .. total_spaces-1}
         |F| = free_count

     You can use a loop:

         for i in 0 .. total_spaces-1:  i in P or i in F

     A module holds several such expressions true at once. Pick one and get it right; you do not have to find them all.

  2. (25%) **For each function you wrote, show your expression is still true when it returns.** A line or two each, grouped by module.

     If a function cannot affect the expression, say so in one line. If it could, say which step keeps it true.

## Where to submit

Upload the archive to PLMS (https://plms.postech.ac.kr) under Project #1 before the deadline. Submissions sent by email, or left anywhere else, are not collected.

Due: September 25, 2026, 11:59 PM KST
